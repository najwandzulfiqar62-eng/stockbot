# Web App (Ranah Saham)

Antarmuka web di atas logika `core/` yang sudah ada. **Tidak ada logika
analisis baru** — endpoint hanya membungkus fungsi `core/`, jadi hasil web
identik dengan bot Telegram.

## Cara jalan (lokal)

```bash
pip install -r requirements.txt          # termasuk fastapi + uvicorn
uvicorn web.app:app --host 0.0.0.0 --port 8000
```

Buka http://localhost:8000

## Endpoint

| Method | Path | Hasil |
|---|---|---|
| GET | `/api/health` | cek status |
| GET | `/api/analyze/{kode}` | JSON: AI Score, indikator, SMC, insight |
| GET | `/api/ohlc/{kode}` | JSON candle+MA untuk chart interaktif (saham / `IHSG`) |
| GET | `/api/chart/{kode}` | PNG grafik (matplotlib) |
| GET | `/api/compare?kodes=BBCA,BMRI` | JSON banding beberapa saham (maks 5) |
| GET | `/api/screener` | JSON screener breakout bullish (saham likuid) |
| GET | `/api/universe` | JSON metrik ±45 saham (screener multi-filter + heatmap) |
| GET | `/api/report/{kode}` | PDF laporan saham |
| GET | `/api/news?kode=BBCA` | JSON berita + sinyal teknikal |
| GET | `/api/ihsg` | JSON analisis IHSG + edge backtest |
| GET | `/api/ihsg/report` | PDF laporan IHSG (dengan SMC) |
| GET | `/` | frontend SPA (web/static/index.html) |

## Frontend (web/static/index.html)

SPA satu file (tanpa framework) dengan 6 tab: **Analisis**, **IHSG**, **Screener**, **Heatmap**,
**Bandingkan**, **Berita**. Fitur:
- **Command palette** (Ctrl/Cmd + K) untuk cari saham cepat.
- **Chart candlestick interaktif** (TradingView lightweight-charts via CDN)
  dengan MA20/MA50 + volume — bisa zoom/geser. Bukan gambar statis.
- Animasi skor (count-up), confluence bar, skeleton loader, transisi tab.
- Banding beberapa saham berdampingan; feed berita; unduh laporan PDF.
- Identitas brand sama dengan laporan PDF (navy + emas); responsif; hormati
  `prefers-reduced-motion`.

## Yang SUDAH ada (fondasi)

- Cache TTL 5 menit per ticker → melindungi Yahoo Finance dari rentetan
  request publik.
- Rate limit per-IP sederhana (30 req / 60 dtk) di middleware.
- Semua data & perhitungan di server; frontend hanya menampilkan.

## Yang HARUS ditambah sebelum benar-benar publik (BELUM ada)

Ini fondasi, bukan produk publik final. Sebelum buka ke banyak user:

1. **Hosting 24/7** (mis. VPS, Railway, Fly.io, Render) + domain.
2. **Rate limit berbasis Redis** kalau jalan multi-instance (rate limit
   in-memory di sini reset tiap restart & tidak lintas-instance).
3. **Autentikasi** kalau mau fitur personal (watchlist, alert per-user).
   Versi ini read-only/anonim.
4. **HTTPS** (reverse proxy: Caddy/Nginx) — wajib untuk publik.
5. **Monitoring & logging** yang tidak membocorkan rahasia.
6. Pertimbangkan **lisensi data**: redistribusi data Yahoo Finance secara
   publik/komersial punya batasan ToS — cek sebelum monetisasi.

## Catatan keamanan

Token bot Telegram TIDAK dipakai di web app ini. Jangan pernah menaruh
token/kunci apa pun di `web/static/` (sisi browser) — semua rahasia tetap
di server.
