# =========================
# WEB API - FastAPI di atas core/
# =========================
# Lapisan web yang MEMBUNGKUS fungsi core/ yang sudah ada jadi HTTP API.
# TIDAK ada logika analisis baru di sini -- semua tetap di core/ (sumber
# kebenaran tunggal), jadi web & bot Telegram memberi hasil identik.
#
# PRINSIP KEAMANAN (penting untuk web publik):
# - Semua logika & data (yfinance, perhitungan) di SERVER. Frontend cuma
#   menampilkan. Tidak ada kunci/token di sisi browser.
# - Ada cache TTL untuk MELINDUNGI Yahoo Finance dari rentetan request
#   publik (kalau tidak, mudah kena rate-limit / IP diblokir).
# - Ada rate limit per-IP sederhana (in-memory). UNTUK PRODUKSI SKALA
#   BESAR ini perlu diganti rate-limit berbasis Redis + autentikasi;
#   versi ini fondasi, bukan benteng final. Lihat catatan di bawah.
#
# Jalankan:
#   pip install fastapi uvicorn
#   uvicorn web.app:app --host 0.0.0.0 --port 8000
# lalu buka http://localhost:8000

import os
import time
import asyncio
import tempfile
from collections import defaultdict

import pandas as pd
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from core.async_yf import async_download
from core.stock_data import fix_yf_columns
from core.ai_score import calculate_ai_score_from_df
from core.insight import _narrate_technical
from core.report import (
    build_smc_summary, build_report_data, build_ihsg_report_data,
)
from core.charts.advanced_chart import generate_advanced_chart
from core.smc import detect_bos_choch, detect_order_blocks, detect_fvg, detect_liquidity_pools
from core.charts.smc_chart import (
    generate_bos_chart, generate_orderblock_chart, generate_fvg_chart, generate_liquidity_chart,
)
from core.charts.report_pdf import generate_report_pdf, generate_ihsg_report_pdf
from core.news import fetch_news
from core.news_signal import enrich_news_with_signals
from core.ihsg.ihsg_analysis import analyze_ihsg_with_backtest
from core.wyckoff import detect_phases
from core.config import SAHAM_XLSX_PATH

# Peta sektor untuk universe likuid (akurat, IDX-IC). Data sektor penuh
# tidak tersedia dari yfinance, jadi dipetakan manual untuk universe ini.
SECTOR_MAP_UNIVERSE = {
    "BBCA": "Financials", "BBRI": "Financials", "BMRI": "Financials", "BBNI": "Financials",
    "BRIS": "Financials", "ARTO": "Financials",
    "TLKM": "Infrastructure", "EXCL": "Infrastructure", "ISAT": "Infrastructure",
    "TOWR": "Infrastructure", "TBIG": "Infrastructure", "JSMR": "Infrastructure",
    "ASII": "Industrials", "UNTR": "Industrials",
    "UNVR": "Consumer Non-Cyclical", "ICBP": "Consumer Non-Cyclical", "INDF": "Consumer Non-Cyclical",
    "GGRM": "Consumer Non-Cyclical", "HMSP": "Consumer Non-Cyclical", "CPIN": "Consumer Non-Cyclical",
    "JPFA": "Consumer Non-Cyclical", "AMRT": "Consumer Non-Cyclical",
    "KLBF": "Healthcare",
    "ADRO": "Energy", "PTBA": "Energy", "ITMG": "Energy", "MEDC": "Energy", "PGAS": "Energy",
    "BRMS": "Energy", "RAJA": "Energy", "AKRA": "Energy",
    "ANTM": "Basic Materials", "INCO": "Basic Materials", "MDKA": "Basic Materials",
    "TINS": "Basic Materials", "SMGR": "Basic Materials", "INTP": "Basic Materials",
    "BRPT": "Basic Materials", "TPIA": "Basic Materials",
    "MNCN": "Consumer Cyclical", "ACES": "Consumer Cyclical", "MAPI": "Consumer Cyclical",
    "ERAA": "Consumer Cyclical",
    "GOTO": "Technology", "BUKA": "Technology",
}

_SHARES = {}


def _load_shares():
    """Jumlah lembar saham per emiten dari saham.xlsx (untuk market cap)."""
    global _SHARES
    if _SHARES:
        return _SHARES
    try:
        df = pd.read_excel(SAHAM_XLSX_PATH)
        for _, r in df.iterrows():
            kode = str(r.get("Kode", "")).strip().upper()
            raw = str(r.get("Saham", "")).replace(".", "").replace(",", "").strip()
            if kode and raw.isdigit():
                _SHARES[kode] = int(raw)
    except Exception as e:
        print(f"⚠️ gagal load shares: {e}")
    return _SHARES

app = FastAPI(title="Ranah Saham API", version="1.0")

_BASE = os.path.dirname(os.path.abspath(__file__))
_STATIC = os.path.join(_BASE, "static")

# ---------- cache TTL sederhana (lindungi Yahoo Finance) ----------
_CACHE: dict[str, tuple[float, object]] = {}
_CACHE_TTL = 300  # detik


def _cache_get(key):
    v = _CACHE.get(key)
    if v and (time.time() - v[0]) < _CACHE_TTL:
        return v[1]
    return None


def _cache_set(key, val):
    _CACHE[key] = (time.time(), val)


# ---------- rate limit per-IP sederhana (in-memory) ----------
# CATATAN: cukup untuk 1 instance. Untuk multi-instance / skala besar,
# ganti dengan rate-limit berbasis Redis.
_HITS: dict[str, list] = defaultdict(list)
_RATE_MAX = 30        # request
_RATE_WINDOW = 60     # per 60 detik


@app.middleware("http")
async def rate_limit(request: Request, call_next):
    if request.url.path.startswith("/api/"):
        ip = request.client.host if request.client else "unknown"
        now = time.time()
        _HITS[ip] = [t for t in _HITS[ip] if now - t < _RATE_WINDOW]
        if len(_HITS[ip]) >= _RATE_MAX:
            return JSONResponse(
                {"error": "Terlalu banyak permintaan. Coba lagi sebentar."},
                status_code=429)
        _HITS[ip].append(now)
    return await call_next(request)


# ---------- helper ----------
async def _clean(ticker: str, period: str = "1y", interval: str = "1d"):
    key = f"df:{ticker}:{period}:{interval}"
    cached = _cache_get(key)
    if cached is not None:
        return cached
    df = await async_download(ticker, period=period, interval=interval, progress=False)
    df = fix_yf_columns(df).apply(pd.to_numeric, errors="coerce").dropna()
    _cache_set(key, df)
    return df


def _py(o):
    """Konversi tipe numpy (bool_/integer/floating) jadi tipe Python native
    supaya bisa di-serialize JSON oleh FastAPI. Rekursif untuk dict/list."""
    import numpy as np
    if isinstance(o, dict):
        return {k: _py(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_py(x) for x in o]
    if isinstance(o, np.bool_):
        return bool(o)
    if isinstance(o, np.integer):
        return int(o)
    if isinstance(o, np.floating):
        return float(o)
    return o


def _norm_kode(kode: str) -> str:
    return kode.strip().upper().replace(".JK", "")


_IHSG_ALIASES = {"IHSG", "JKSE", "^JKSE", "COMPOSITE"}


def _resolve_ticker(kode: str) -> str:
    """Kembalikan ticker Yahoo yang benar: IHSG -> ^JKSE (tanpa .JK),
    saham biasa -> KODE.JK."""
    k = _norm_kode(kode).replace("^", "")
    if k in _IHSG_ALIASES or kode.strip().upper() in _IHSG_ALIASES:
        return "^JKSE"
    return k + ".JK"


# ---------- endpoints ----------
@app.get("/api/health")
async def health():
    return {"status": "ok"}


def _vwap_fair_value(df, lookback: int = 44) -> dict:
    """Nilai wajar berbasis VWAP (mirip kartu 'VWAP Fair Value' ARTHARA).
    MURNI dari OHLCV: VWAP = Σ(harga tipikal × volume) / Σ volume atas
    `lookback` hari terakhir. Deviasi harga vs VWAP dilaporkan dalam %
    dan z-score (dislokasi). Label klasifikasi diskon/premium."""
    d = df.tail(lookback)
    tp = (d["High"] + d["Low"] + d["Close"]) / 3.0
    volsum = float(d["Volume"].sum())
    if volsum <= 0:
        return None
    vwap = float((tp * d["Volume"]).sum() / volsum)
    price = float(df["Close"].iloc[-1])
    dev_pct = (price - vwap) / vwap * 100 if vwap else 0.0
    devs = (d["Close"] - vwap) / vwap
    sd = float(devs.std())
    z = round((dev_pct / 100) / sd, 2) if sd else 0.0
    if dev_pct <= -8:
        label = "Deep Discount"
    elif dev_pct <= -2:
        label = "Discount"
    elif dev_pct < 2:
        label = "Fair Value"
    elif dev_pct < 8:
        label = "Premium"
    else:
        label = "Deep Premium"
    return {"vwap": round(vwap, 2), "dev_pct": round(dev_pct, 2), "z": z, "label": label,
            "lookback": lookback}


async def _analyze_payload(kode: str):
    """Bangun payload analisis untuk satu kode (dipakai /api/analyze &
    /api/compare). Mengembalikan dict atau melempar HTTPException."""
    kode = _norm_kode(kode)
    cache_key = f"analyze:{kode}"
    cached = _cache_get(cache_key)
    if cached is not None:
        return cached
    try:
        df = await _clean(kode + ".JK")
    except Exception:
        raise HTTPException(502, "Gagal mengambil data harga. Coba lagi sebentar.")
    if df is None or len(df) < 50:
        raise HTTPException(404, f"Data {kode} tidak cukup untuk analisis (butuh ≥50 hari).")
    ai = calculate_ai_score_from_df(df)
    if ai is None:
        raise HTTPException(422, f"Gagal menganalisis {kode}.")
    smc = build_smc_summary(df)
    payload = {
        "kode": kode,
        "score": ai.get("score"), "rating": ai.get("rating"),
        "recommendation": ai.get("recommendation"), "signal": ai.get("signal"),
        "price": ai.get("price"), "change_1d": ai.get("change_1d"), "change_5d": ai.get("change_5d"),
        "rsi": ai.get("rsi"), "macd_bullish": ai.get("macd_bullish"),
        "vol_ratio": ai.get("vol_ratio"), "atr_pct": ai.get("atr_pct"),
        "ma20": ai.get("ma20"), "ma50": ai.get("ma50"), "ma200": ai.get("ma200"),
        "bullish_count": ai.get("bullish_count"), "bearish_count": ai.get("bearish_count"),
        "netral_count": ai.get("netral_count"),
        "insight": _narrate_technical(ai),
        "vwap_fv": _vwap_fair_value(df),
        "smc": None if not smc else {
            "narasi": smc.get("narasi"),
            "n_bos": smc.get("n_bos"), "n_choch": smc.get("n_choch"),
            "ob_bullish": smc.get("ob_bullish"), "ob_bearish": smc.get("ob_bearish"),
            "fvg_unfilled": smc.get("fvg_unfilled"),
            "liq_high": smc.get("liq_high"), "liq_low": smc.get("liq_low"),
        },
    }
    payload = _py(payload)
    _cache_set(cache_key, payload)
    return payload


@app.get("/api/analyze/{kode}")
async def analyze(kode: str):
    return await _analyze_payload(kode)


@app.get("/api/ohlc/{kode}")
async def ohlc(kode: str, days: int = 140):
    """Data candlestick + MA untuk chart interaktif (lightweight-charts)."""
    ticker = _resolve_ticker(kode)
    label = "IHSG" if ticker == "^JKSE" else _norm_kode(kode)
    try:
        df = await _clean(ticker)
    except Exception:
        raise HTTPException(502, "Gagal mengambil data harga.")
    if df is None or len(df) < 50:
        raise HTTPException(404, "Data tidak cukup.")
    df = df.tail(max(days, 60)).copy()
    ma20 = df["Close"].rolling(20).mean()
    ma50 = df["Close"].rolling(50).mean()
    candles, vol, m20, m50 = [], [], [], []
    for i in range(len(df)):
        t = df.index[i].strftime("%Y-%m-%d")
        o, h, l, c = (float(df["Open"].iloc[i]), float(df["High"].iloc[i]),
                      float(df["Low"].iloc[i]), float(df["Close"].iloc[i]))
        candles.append({"time": t, "open": o, "high": h, "low": l, "close": c})
        vol.append({"time": t, "value": float(df["Volume"].iloc[i]),
                    "color": "rgba(47,181,126,.5)" if c >= o else "rgba(224,86,107,.5)"})
        if not pd.isna(ma20.iloc[i]):
            m20.append({"time": t, "value": round(float(ma20.iloc[i]), 2)})
        if not pd.isna(ma50.iloc[i]):
            m50.append({"time": t, "value": round(float(ma50.iloc[i]), 2)})
    return {"kode": label, "candles": candles, "volume": vol, "ma20": m20, "ma50": m50,
            "phases": detect_phases(df)}


@app.get("/api/compare")
async def compare(kodes: str = ""):
    """Bandingkan beberapa saham (mis. ?kodes=BBCA,BMRI,TLKM)."""
    lst = [k for k in (kodes or "").split(",") if k.strip()][:5]
    if not lst:
        raise HTTPException(400, "Sertakan minimal 1 kode, mis. ?kodes=BBCA,BMRI")
    out = []
    for k in lst:
        try:
            p = await _analyze_payload(k)
            out.append({"kode": p["kode"], "score": p["score"], "rating": p["rating"],
                        "recommendation": p["recommendation"], "price": p["price"],
                        "change_1d": p["change_1d"], "change_5d": p["change_5d"],
                        "rsi": p["rsi"], "macd_bullish": p["macd_bullish"],
                        "bullish_count": p["bullish_count"], "bearish_count": p["bearish_count"]})
        except HTTPException as e:
            out.append({"kode": _norm_kode(k), "error": e.detail})
    return {"items": out}


@app.get("/api/chart/{kode}")
async def chart(kode: str):
    kode = _norm_kode(kode)
    try:
        df = await _clean(kode + ".JK")
    except Exception:
        raise HTTPException(502, "Gagal mengambil data harga.")
    if df is None or len(df) < 50:
        raise HTTPException(404, "Data tidak cukup.")
    path = await asyncio.to_thread(generate_advanced_chart, df, kode)
    if not path or not os.path.exists(path):
        raise HTTPException(500, "Gagal membuat chart.")
    return FileResponse(path, media_type="image/png", filename=f"{kode}_chart.png")


@app.get("/api/news")
async def news(kode: str = ""):
    kode = _norm_kode(kode) if kode else ""
    items = await fetch_news(keyword=kode or None, limit=8)
    if items is None:
        raise HTTPException(502, "Sumber berita tidak bisa diakses saat ini.")
    if kode and items:
        try:
            items = await enrich_news_with_signals(items)
        except Exception:
            pass
    out = [{
        "title": it.get("title"), "source": it.get("source"), "link": it.get("link"),
        "emiten": it.get("emiten") or [],
        "sinyal": {k: {"score": v["score"], "rating": v["rating"], "signal": v["signal"]}
                   for k, v in (it.get("sinyal") or {}).items()},
    } for it in (items or [])]
    return {"kode": kode, "items": out}


@app.get("/api/report/{kode}")
async def report(kode: str):
    kode = _norm_kode(kode)
    try:
        df = await _clean(kode + ".JK")
    except Exception:
        raise HTTPException(502, "Gagal mengambil data harga.")
    if df is None or len(df) < 50:
        raise HTTPException(404, "Data tidak cukup.")
    ai = calculate_ai_score_from_df(df)
    if ai is None:
        raise HTTPException(422, "Gagal menganalisis.")
    smc = build_smc_summary(df)
    chart_path = await asyncio.to_thread(generate_advanced_chart, df, kode)
    rd = build_report_data(kode, kode, ai, insight={"teknikal": _narrate_technical(ai)},
                           chart_path=chart_path, smc=smc)
    out = os.path.join(tempfile.gettempdir(), f"Laporan_{kode}.pdf")
    await asyncio.to_thread(generate_report_pdf, rd, out)
    return FileResponse(out, media_type="application/pdf", filename=f"Laporan_{kode}.pdf")


@app.get("/api/ihsg")
async def ihsg():
    cached = _cache_get("ihsg:analyze")
    if cached is not None:
        return cached
    try:
        dd = await _clean("^JKSE", period="3mo")
        dw = await _clean("^JKSE", period="1y", interval="1wk")
        dl = await _clean("^JKSE", period="2y")
    except Exception:
        raise HTTPException(502, "Gagal mengambil data IHSG.")
    analysis = analyze_ihsg_with_backtest(dd, dw, dl)
    if not analysis:
        raise HTTPException(422, "Gagal menganalisis IHSG.")
    bt = analysis.get("backtest_result") or {}
    smc = build_smc_summary(dd)
    payload = {
        "prediction": analysis.get("prediction"),
        "confidence": analysis.get("confidence"),
        "action": analysis.get("action"),
        "target_move": analysis.get("target_move"),
        "current_price": analysis.get("current_price"),
        "daily_change": analysis.get("daily_change"),
        "bullish_score": analysis.get("bullish_score"),
        "bearish_score": analysis.get("bearish_score"),
        "rsi": analysis.get("rsi"),
        "rsi_divergence": analysis.get("rsi_divergence"),
        "macd_signal": analysis.get("macd_signal"),
        "bb_position": analysis.get("bb_position"),
        "bb_squeeze": analysis.get("bb_squeeze"),
        "ma_trend": analysis.get("ma_trend"),
        "ma20": analysis.get("ma20"), "ma50": analysis.get("ma50"),
        "volume_trend": analysis.get("volume_trend"),
        "volume_ratio": analysis.get("volume_ratio"),
        "fib_position": analysis.get("fib_position"),
        "fib_382": analysis.get("fib_382"), "fib_500": analysis.get("fib_500"),
        "fib_618": analysis.get("fib_618"),
        "poc": analysis.get("poc"),
        "support_1": analysis.get("support_1"), "support_2": analysis.get("support_2"),
        "resistance_1": analysis.get("resistance_1"), "resistance_2": analysis.get("resistance_2"),
        "entry_zone": analysis.get("entry_zone"),
        "stop_loss": analysis.get("stop_loss"),
        "candle_patterns": analysis.get("candle_patterns"),
        "backtest": {"win_rate": bt.get("win_rate"), "base_rate": bt.get("base_rate"),
                     "edge": bt.get("edge"), "n": bt.get("n")} if bt else None,
        "smc": None if not smc else {
            "narasi": smc.get("narasi"), "n_bos": smc.get("n_bos"), "n_choch": smc.get("n_choch"),
            "ob_bullish": smc.get("ob_bullish"), "ob_bearish": smc.get("ob_bearish"),
            "fvg_unfilled": smc.get("fvg_unfilled"),
            "liq_high": smc.get("liq_high"), "liq_low": smc.get("liq_low"),
        },
    }
    payload = _py(payload)
    _cache_set("ihsg:analyze", payload)
    return payload


@app.get("/api/ihsg/report")
async def ihsg_report():
    try:
        dd = await _clean("^JKSE", period="3mo")
        dw = await _clean("^JKSE", period="1y", interval="1wk")
        dl = await _clean("^JKSE", period="2y")
    except Exception:
        raise HTTPException(502, "Gagal mengambil data IHSG.")
    analysis = analyze_ihsg_with_backtest(dd, dw, dl)
    if not analysis:
        raise HTTPException(422, "Gagal menganalisis IHSG.")
    smc = build_smc_summary(dd)
    chart_path = await asyncio.to_thread(generate_advanced_chart, dd, "IHSG")
    rd = build_ihsg_report_data(analysis, None, None, None, chart_path, smc=smc)
    out = os.path.join(tempfile.gettempdir(), "Laporan_IHSG.pdf")
    await asyncio.to_thread(generate_ihsg_report_pdf, rd, out)
    return FileResponse(out, media_type="application/pdf", filename="Laporan_IHSG.pdf")


# Universe likuid (≈45 saham besar) untuk screener web — dipilih supaya
# scan tetap cepat (full 900+ ticker terlalu lama untuk request web).
SCREENER_UNIVERSE = [
    "BBCA", "BBRI", "BMRI", "BBNI", "TLKM", "ASII", "UNVR", "ICBP", "INDF", "KLBF",
    "GGRM", "HMSP", "UNTR", "ADRO", "PTBA", "ITMG", "ANTM", "INCO", "MDKA", "TINS",
    "SMGR", "INTP", "CPIN", "JPFA", "AKRA", "EXCL", "ISAT", "TOWR", "TBIG", "MNCN",
    "ACES", "MAPI", "ERAA", "AMRT", "GOTO", "BUKA", "BRPT", "TPIA", "BRIS", "ARTO",
    "MEDC", "PGAS", "JSMR", "BRMS", "RAJA",
]


@app.get("/api/smc/{kode}/{kind}")
async def smc_chart(kode: str, kind: str):
    """Chart SMC per komponen (PNG). kind: bos | ob | fvg | liq. Mendukung
    saham maupun IHSG (kode=IHSG -> ^JKSE)."""
    ticker = _resolve_ticker(kode)
    label = "IHSG" if ticker == "^JKSE" else _norm_kode(kode)
    try:
        df = await _clean(ticker)
    except Exception:
        raise HTTPException(502, "Gagal mengambil data harga.")
    if df is None or len(df) < 50:
        raise HTTPException(404, "Data tidak cukup.")
    kind = kind.lower()
    mapping = {
        "bos": (generate_bos_chart, lambda: detect_bos_choch(df, 5, 5)),
        "ob": (generate_orderblock_chart, lambda: detect_order_blocks(df)),
        "fvg": (generate_fvg_chart, lambda: detect_fvg(df)),
        "liq": (generate_liquidity_chart, lambda: detect_liquidity_pools(df)),
    }
    if kind not in mapping:
        raise HTTPException(400, "kind harus salah satu: bos, ob, fvg, liq")
    gen, detect = mapping[kind]
    try:
        path = await asyncio.to_thread(gen, df, label, detect())
    except Exception:
        raise HTTPException(500, "Gagal membuat chart SMC.")
    if not path or not os.path.exists(path):
        raise HTTPException(500, "Gagal membuat chart SMC.")
    return FileResponse(path, media_type="image/png", filename=f"{label}_{kind}.png")


@app.get("/api/screenerpro")
async def screenerpro():
    """Screener gaya Minervini (8 kriteria trend template + RS vs IHSG +
    momentum). Skor ≥65 saja. Atas universe likuid, di-cache."""
    cached = _cache_get("screenerpro")
    if cached is not None:
        return cached
    from core.screening_pro import run_screenerpro
    try:
        ihsg_raw = await _clean("^JKSE", period="1y")
        market_close = ihsg_raw["Close"] if ihsg_raw is not None and len(ihsg_raw) else None
        res = await run_screenerpro([t + ".JK" for t in SCREENER_UNIVERSE], market_close=market_close)
    except Exception:
        raise HTTPException(502, "Gagal menjalankan screener pro.")
    payload = _py({"items": res or [], "universe": len(SCREENER_UNIVERSE)})
    _cache_set("screenerpro", payload)
    return payload


@app.get("/api/universe")
async def universe():
    """Pindai universe likuid sekali, hitung metrik per saham (untuk
    screener multi-filter & heatmap). Berat -> di-cache."""
    cached = _cache_get("universe")
    if cached is not None:
        return cached
    from core.async_yf import async_download_many
    shares = _load_shares()
    tickers = [t + ".JK" for t in SCREENER_UNIVERSE]
    try:
        data = await async_download_many(tickers, period="6mo", interval="1d")
    except Exception:
        raise HTTPException(502, "Gagal memuat data universe. Coba lagi sebentar.")

    items = []
    for t in tickers:
        kode = t.replace(".JK", "")
        df = data.get(t) if isinstance(data, dict) else None
        if df is None:
            continue
        try:
            df = fix_yf_columns(df).apply(pd.to_numeric, errors="coerce").dropna()
        except Exception:
            continue
        if df is None or len(df) < 50:
            continue
        try:
            ai = calculate_ai_score_from_df(df)
            if ai is None:
                continue
            price = float(df["Close"].iloc[-1])
            prev = float(df["Close"].iloc[-2]) if len(df) > 1 else price
            change_1d = (price / prev - 1) * 100 if prev else 0.0
            fv = _vwap_fair_value(df)
            ma20 = ai.get("ma20") or price
            firing = bool(ai.get("macd_bullish") and price > ma20 and (ai.get("rsi") or 0) > 50)
            mcap = (shares.get(kode, 0) * price) or None
            avg_val = float((df["Close"] * df["Volume"]).tail(20).mean())
            items.append({
                "kode": kode, "sector": SECTOR_MAP_UNIVERSE.get(kode, "Lainnya"),
                "price": round(price), "change_1d": round(change_1d, 2),
                "score": ai.get("score"), "rating": ai.get("rating"),
                "rsi": ai.get("rsi"), "macd_bullish": ai.get("macd_bullish"),
                "vwap_label": (fv or {}).get("label"), "vwap_dev": (fv or {}).get("dev_pct"),
                "firing": firing, "market_cap": mcap, "avg_value": avg_val,
            })
        except Exception:
            continue

    payload = {"items": items, "count": len(items),
               "as_of": (items and __import__("datetime").date.today().isoformat()) or None}
    payload = _py(payload)
    _cache_set("universe", payload)
    return payload


@app.get("/api/screener")
async def screener():
    """Screener breakout bullish (MA5>MA20 + lonjakan volume + likuid),
    memakai run_screener() yang SAMA dengan bot. Hasil di-cache (mahal)."""
    cached = _cache_get("screener")
    if cached is not None:
        return cached
    from core.screener import run_screener
    try:
        res = await run_screener([t + ".JK" for t in SCREENER_UNIVERSE])
    except Exception:
        raise HTTPException(502, "Gagal menjalankan screener. Coba lagi sebentar.")
    payload = {"items": res or [], "universe": len(SCREENER_UNIVERSE)}
    _cache_set("screener", payload)
    return payload


# ---------- frontend statis ----------
if os.path.isdir(_STATIC):
    app.mount("/", StaticFiles(directory=_STATIC, html=True), name="static")
