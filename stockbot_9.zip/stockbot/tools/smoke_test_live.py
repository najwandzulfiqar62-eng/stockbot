#!/usr/bin/env python3
# =========================
# SMOKE TEST LIVE - JALANKAN DI MESINMU
# =========================
# Menguji fitur baru dengan DATA SUNGGUHAN (yfinance + RSS). Ini yang
# TIDAK bisa diuji di lingkungan tanpa internet -- jadi jalankan ini di
# komputer/server tempat botmu jalan, SETELAH `pip install -r
# requirements.txt`.
#
# Cara jalan:
#   python tools/smoke_test_live.py          # pakai BBCA + IHSG
#   python tools/smoke_test_live.py TLKM     # pakai saham lain
#
# Skrip TIDAK mengirim apa pun ke Telegram. Ia hanya:
#   - menarik data live,
#   - menjalankan tiap fitur,
#   - menulis PDF contoh ke folder ./smoke_out/ supaya bisa kamu buka,
#   - mencetak PASS/FAIL + durasi per langkah.
#
# Kalau ada langkah FAIL, pesan errornya dicetak supaya gampang dilacak.

import os
import sys
import time
import asyncio

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import core.charts  # noqa  (filter warning chart)
import pandas as pd

OUT_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "smoke_out")
os.makedirs(OUT_DIR, exist_ok=True)

_results = []


def step(name):
    def deco(fn):
        async def wrap(*a, **k):
            t0 = time.time()
            try:
                r = await fn(*a, **k)
                dt = time.time() - t0
                print(f"  ✅ {name}  ({dt:.1f}s)")
                _results.append((name, True))
                return r
            except Exception as e:
                dt = time.time() - t0
                print(f"  ❌ {name}  ({dt:.1f}s) — {type(e).__name__}: {e}")
                _results.append((name, False))
                return None
        return wrap
    return deco


async def _clean(ticker, period="1y", interval="1d"):
    from core.async_yf import async_download
    from core.stock_data import fix_yf_columns
    df = await async_download(ticker, period=period, interval=interval, progress=False)
    df = fix_yf_columns(df).apply(pd.to_numeric, errors="coerce").dropna()
    return df


@step("Unduh data harga (live)")
async def t_download(ticker):
    df = await _clean(ticker + ".JK")
    assert df is not None and len(df) >= 50, f"data kurang ({0 if df is None else len(df)} baris)"
    return df


@step("Berita + filter kode (live RSS)")
async def t_news(kode):
    from core.news import fetch_news
    items = await fetch_news(keyword=kode, limit=8)
    assert items is not None, "fetch_news mengembalikan None (semua sumber gagal)"
    print(f"     → {len(items)} berita")
    return items


@step("Berita + sinyal teknikal (live)")
async def t_news_signal(kode):
    from core.news import fetch_news
    from core.news_signal import enrich_news_with_signals
    items = await fetch_news(keyword=kode, limit=8) or []
    items = await enrich_news_with_signals(items)
    tagged = sum(1 for it in items if it.get("sinyal"))
    print(f"     → {tagged} berita dapat sinyal")
    return items


@step("SMC summary (live)")
async def t_smc(df):
    from core.report import build_smc_summary
    smc = build_smc_summary(df)
    if smc:
        print(f"     → {smc['n_bos']} BOS / {smc['n_choch']} CHoCH, "
              f"OB {smc['ob_bullish']}/{smc['ob_bearish']}, "
              f"FVG {smc['fvg_unfilled']}, Liq {smc['liq_high']}/{smc['liq_low']}")
    return smc


@step("Laporan PDF saham (live)")
async def t_stock_pdf(kode, df):
    from core.ai_score import calculate_ai_score_from_df
    from core.insight import _narrate_technical
    from core.report import build_report_data, build_smc_summary
    from core.charts.report_pdf import generate_report_pdf
    from core.charts.advanced_chart import generate_advanced_chart
    from core.smc import detect_bos_choch, detect_order_blocks, detect_fvg, detect_liquidity_pools
    from core.charts.smc_chart import (generate_bos_chart, generate_orderblock_chart,
                                       generate_fvg_chart, generate_liquidity_chart)
    ai = calculate_ai_score_from_df(df)
    smc = build_smc_summary(df)
    charts = {}
    for label, gen, d in [("Struktur (BOS/CHoCH)", generate_bos_chart, detect_bos_choch(df, 5, 5)),
                          ("Order Block", generate_orderblock_chart, detect_order_blocks(df)),
                          ("Fair Value Gap", generate_fvg_chart, detect_fvg(df)),
                          ("Liquidity Pools", generate_liquidity_chart, detect_liquidity_pools(df))]:
        p = gen(df, kode, d)
        if p and os.path.exists(p):
            charts[label] = p
    adv = generate_advanced_chart(df, kode)
    rd = build_report_data(kode, kode, ai, insight={"teknikal": _narrate_technical(ai)},
                           chart_path=adv, smc=smc, smc_charts=charts)
    out = os.path.join(OUT_DIR, f"Laporan_{kode}.pdf")
    generate_report_pdf(rd, out)
    for p in (adv, *charts.values()):
        if p and os.path.exists(p):
            os.remove(p)
    assert os.path.getsize(out) > 50000
    print(f"     → {out}")


@step("Laporan PDF IHSG (live)")
async def t_ihsg_pdf():
    from core.ihsg.ihsg_analysis import analyze_ihsg_with_backtest
    from core.ihsg.ihsg_chart import generate_ihsg_advanced_chart
    from core.report import build_ihsg_report_data, build_smc_summary
    from core.charts.report_pdf import generate_ihsg_report_pdf
    from core.smc import detect_bos_choch, detect_order_blocks, detect_fvg, detect_liquidity_pools
    from core.charts.smc_chart import (generate_bos_chart, generate_orderblock_chart,
                                       generate_fvg_chart, generate_liquidity_chart)
    dd = await _clean("^JKSE", period="3mo")
    await asyncio.sleep(0.5)
    dw = await _clean("^JKSE", period="1y", interval="1wk")
    await asyncio.sleep(0.5)
    dl = await _clean("^JKSE", period="2y")
    analysis = analyze_ihsg_with_backtest(dd, dw, dl)
    assert analysis, "analisis IHSG kosong"
    chart = None
    try:
        chart = generate_ihsg_advanced_chart(dd)
    except Exception:
        pass
    smc = build_smc_summary(dd)
    smc_charts = {}
    for label, gen, d in [("Struktur (BOS/CHoCH)", generate_bos_chart, detect_bos_choch(dd, 5, 5)),
                          ("Order Block", generate_orderblock_chart, detect_order_blocks(dd)),
                          ("Fair Value Gap", generate_fvg_chart, detect_fvg(dd)),
                          ("Liquidity Pools", generate_liquidity_chart, detect_liquidity_pools(dd))]:
        try:
            p = gen(dd, "IHSG", d)
            if p and os.path.exists(p):
                smc_charts[label] = p
        except Exception:
            pass
    rd = build_ihsg_report_data(analysis, None, None, None, chart, smc=smc, smc_charts=smc_charts)
    out = os.path.join(OUT_DIR, "Laporan_IHSG.pdf")
    generate_ihsg_report_pdf(rd, out)
    for p in (chart, *smc_charts.values()):
        if p and os.path.exists(p):
            os.remove(p)
    assert os.path.getsize(out) > 20000
    print(f"     → {out}  (prediksi: {analysis.get('prediction')})")


async def main():
    kode = (sys.argv[1] if len(sys.argv) > 1 else "BBCA").upper().replace(".JK", "")
    print("=" * 55)
    print(f"SMOKE TEST LIVE — saham: {kode} + IHSG")
    print("=" * 55)

    print(f"\n[1] {kode} — data & analisis")
    df = await t_download(kode)
    await t_news(kode)
    await t_news_signal(kode)
    if df is not None:
        await t_smc(df)
        await t_stock_pdf(kode, df)

    print("\n[2] IHSG")
    await t_ihsg_pdf()

    total = len(_results)
    passed = sum(1 for _, ok in _results if ok)
    print("\n" + "=" * 55)
    print(f"HASIL: {passed}/{total} langkah berhasil")
    print(f"PDF contoh ada di: {OUT_DIR}/")
    print("=" * 55)
    return 0 if passed == total else 1


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
