# =========================
# AUTO NOTIFICATION JOBS
# =========================
# PERUBAHAN dari main.py lama:
# - check_watchlist_alerts() dulu loop SEQUENTIAL melalui SETIAP USER,
#   dan untuk setiap user loop SEQUENTIAL lagi melalui setiap ticker di
#   watchlist mereka, masing-masing yf.download satu per satu. Untuk N
#   user dengan M ticker masing-masing, itu N*M download sekuensial --
#   bug performa paling parah yang ditemukan di awal investigasi (job ini
#   jalan TIAP JAM untuk SEMUA user, jadi makin banyak user = makin lama
#   & makin besar risiko rate-limit). Sekarang: kumpulkan SEMUA ticker
#   unik dari SEMUA user dulu, download SEKALI secara paralel via
#   async_download_many, baru iterasi per-user-per-ticker memakai data
#   yang sudah di-cache di memory (tidak ada download berulang untuk
#   ticker yang sama meski dimiliki banyak user).
# - generate_morning_report() dan send_evening_summary() dulu download
#   index global (S&P500, Nasdaq, dst) SEQUENTIAL satu per satu. Sekarang
#   paralel via async_download_many.
# - check_price_alerts() BARU SAMA SEKALI -- job ini tidak ada di kode
#   lama karena /alert dulu memang fitur palsu yang tidak menyimpan
#   apapun (lihat catatan di handlers/market_handlers.py). Sekarang
#   /alert benar-benar tersimpan ke tabel price_alerts, jadi job ini
#   diperlukan untuk benar-benar memenuhi janji pesan "Bot akan cek
#   otomatis setiap jam" yang ditampilkan saat user membuat alert.

from datetime import datetime
import asyncio
import os

from core.database import (
    get_all_subscribed_users, get_user_watchlist_db, get_all_fixed_entries_for_user,
    check_alert_sent_db, save_alert_history_db, get_active_price_alerts_db,
    mark_price_alert_triggered_db,
)
from core.async_yf import async_download_many
from core.stock_data import fix_yf_columns, load_tickers
from core.screener import run_bsjp_screener
from core.messages import format_bsjp_screener_results, sanitize_for_markdown
from core.ihsg.ihsg_analysis import analyze_ihsg_with_backtest
from core.ihsg.ihsg_chart import generate_ihsg_advanced_chart
from core.sector_rotation import get_sector_performance
from core.ai_score import calculate_ai_score_from_df
from core.news import fetch_news
from core.news_signal import score_emiten

# Universe ticker untuk AI Score movers di evening report -- SENGAJA
# lebih kecil dari /airank interaktif (200) karena job ini SUDAH
# menggabungkan BANYAK komponen berat lain sekaligus (analisis IHSG 3x
# download, 11 ticker sektor, berita, watchlist semua user) -- 150
# kompromi wajar antara cakupan vs total durasi job terjadwal.
EVENING_AI_SCAN_LIMIT = 150

GLOBAL_INDICES = {
    "🇺🇸 S&P 500": "^GSPC",
    "🇺🇸 Nasdaq": "^IXIC",
    "🇯🇵 Nikkei": "^N225",
    "🇨🇳 Shanghai": "000001.SS",
}


async def check_watchlist_alerts(context):
    """Cek semua watchlist SEMUA user dan kirim notifikasi otomatis tiap
    jam. Lihat catatan performa di atas file ini untuk perubahan dari
    kode lama."""
    print(f"[{datetime.now()}] Running auto alert check...")

    all_users = get_all_subscribed_users()
    today = datetime.now().strftime("%Y-%m-%d")
    alerts_sent = []

    # Kumpulkan watchlist & fixed_entries SEMUA user dulu (operasi DB lokal,
    # cepat), supaya tahu ticker unik apa saja yang perlu didownload.
    user_data = {}
    all_tickers_needed = set()

    for user_id in all_users:
        watchlist = get_user_watchlist_db(user_id)
        if not watchlist:
            continue
        fixed_entries = get_all_fixed_entries_for_user(user_id)
        relevant = [item['ticker'] for item in watchlist if item['ticker'] in fixed_entries]
        if not relevant:
            continue
        user_data[user_id] = (relevant, fixed_entries)
        all_tickers_needed.update(relevant)

    if not all_tickers_needed:
        return

    # SATU download paralel untuk SEMUA ticker unik dari SEMUA user
    # (bukan N*M download sekuensial seperti kode lama)
    full_tickers = [t + ".JK" for t in all_tickers_needed]
    data_by_ticker = await async_download_many(full_tickers, period="2d", interval="1d")

    for user_id, (relevant_tickers, fixed_entries) in user_data.items():
        for ticker in relevant_tickers:
            full_ticker = ticker + ".JK"
            try:
                df = data_by_ticker.get(full_ticker)
                if df is None:
                    continue
                df = fix_yf_columns(df).dropna()
                if df.empty or len(df) < 2:
                    continue

                low_today = float(df["Low"].iloc[-1])
                high_today = float(df["High"].iloc[-1])
                current_price = float(df["Close"].iloc[-1])

                for key, scenario in fixed_entries[ticker]["scenarios"].items():
                    entry_price = scenario["entry"]
                    if low_today <= entry_price <= high_today:
                        if not check_alert_sent_db(user_id, ticker, key, today):
                            save_alert_history_db(user_id, ticker, key, today, "AUTO_ALERT")
                            msg = (
                                f"🎯 *AUTO-ALERT: {ticker}*\n\n"
                                f"✅ *{scenario['display_name']}* TERKENA!\n\n"
                                f"📊 Entry: Rp{entry_price:,.0f}\n"
                                f"💰 Harga sekarang: Rp{current_price:,.0f}\n"
                                f"🎯 TP1: Rp{scenario['tp1']:,.0f}\n"
                                f"🛑 SL: Rp{scenario['sl']:,.0f}\n\n"
                                f"⚠️ DYOR & manage risk!"
                            )
                            try:
                                await context.bot.send_message(
                                    chat_id=int(user_id), text=msg, parse_mode='Markdown'
                                )
                                alerts_sent.append(f"{ticker} -> {user_id}")
                            except Exception as e:
                                print(f"Gagal kirim alert ke {user_id}: {e}")
                            break

            except Exception as e:
                print(f"Error auto alert {ticker}: {e}")
                continue

    if alerts_sent:
        print(f"✅ Auto-alerts sent: {alerts_sent}")


async def check_price_alerts(context):
    """Cek semua price_alerts (dari /alert) yang belum triggered, dan
    kirim notifikasi + tandai triggered kalau target tercapai.

    BARU SAMA SEKALI -- lihat catatan di atas file ini. Dulu /alert
    cuma menampilkan pesan tanpa benar-benar memproses apapun."""
    print(f"[{datetime.now()}] Running price alert check...")

    active_alerts = get_active_price_alerts_db()  # semua user
    if not active_alerts:
        return

    unique_tickers = {a["ticker"] for a in active_alerts}
    full_tickers = [t + ".JK" for t in unique_tickers]
    data_by_ticker = await async_download_many(full_tickers, period="2d", interval="1d")

    triggered_count = 0
    for alert in active_alerts:
        ticker = alert["ticker"]
        full_ticker = ticker + ".JK"
        try:
            df = data_by_ticker.get(full_ticker)
            if df is None:
                continue
            df = fix_yf_columns(df).dropna()
            if df.empty:
                continue

            current_price = float(df["Close"].iloc[-1])
            target = alert["target_price"]
            direction = alert["direction"]

            hit = (direction == "above" and current_price >= target) or \
                  (direction == "below" and current_price <= target)

            if hit:
                mark_price_alert_triggered_db(alert["id"])
                triggered_count += 1
                arah_text = "naik melewati" if direction == "above" else "turun di bawah"
                msg = (
                    f"🔔 *PRICE ALERT TERKENA!*\n\n"
                    f"Saham : {ticker}\n"
                    f"Target : Rp{target:,.0f}\n"
                    f"Harga sekarang : Rp{current_price:,.0f}\n\n"
                    f"Harga {arah_text} target Anda.\n"
                    f"⚠️ DYOR sebelum mengambil keputusan!"
                )
                try:
                    await context.bot.send_message(
                        chat_id=int(alert["user_id"]), text=msg, parse_mode='Markdown'
                    )
                except Exception as e:
                    print(f"Gagal kirim price alert ke {alert['user_id']}: {e}")

        except Exception as e:
            print(f"Error price alert check {ticker}: {e}")
            continue

    if triggered_count:
        print(f"✅ Price alerts triggered: {triggered_count}")


async def _compute_evening_market_data() -> dict:
    """Hitung SEMUA komponen market-wide evening report SEKALI SAJA
    (BUKAN per-user) -- IHSG advanced analysis + chart, rotasi sektor,
    AI Score movers, berita. Konsisten dengan pola efisiensi yang sudah
    dipakai check_watchlist_alerts() (download sekali, dipakai semua
    user) -- job ini jalan otomatis untuk SEMUA subscriber, jadi
    komponen yang sama TIDAK BOLEH dihitung ulang per-user.

    Setiap komponen dibungkus try/except SENDIRI-SENDIRI -- kalau satu
    komponen gagal (mis. rate-limit Yahoo Finance untuk salah satu
    bagian), komponen lain TETAP ditampilkan, BUKAN seluruh report
    gagal total. Returns dict dengan key yang nilainya bisa None kalau
    komponen itu gagal -- caller (formatter) harus handle None per
    komponen."""
    result = {
        "ihsg_analysis": None, "ihsg_chart_path": None,
        "sector_data": None, "ai_movers": None, "news_items": None,
    }

    # ===== IHSG ADVANCED ANALYSIS + CHART =====
    # Sama persis dengan engine yang dipakai /ihsg (analyze_ihsg_with_
    # backtest) -- GANTI dari evening report lama yang pakai S/R PALSU
    # (current_price * 0.98 / 1.02, BUKAN kalkulasi sungguhan apapun).
    try:
        daily_data = await async_download_many(["^JKSE"], period="3mo", interval="1d")
        await asyncio.sleep(0.5)
        weekly_data = await async_download_many(["^JKSE"], period="1y", interval="1wk")
        await asyncio.sleep(0.5)
        longer_data = await async_download_many(["^JKSE"], period="2y", interval="1d")

        import pandas as pd
        df_daily = fix_yf_columns(daily_data["^JKSE"]).apply(pd.to_numeric, errors="coerce").dropna()
        df_weekly = fix_yf_columns(weekly_data["^JKSE"]).apply(pd.to_numeric, errors="coerce").dropna()
        df_longer = fix_yf_columns(longer_data["^JKSE"]).apply(pd.to_numeric, errors="coerce").dropna()

        if len(df_daily) >= 50:
            result["ihsg_analysis"] = analyze_ihsg_with_backtest(df_daily, df_weekly, df_longer)
            chart_path = await asyncio.to_thread(generate_ihsg_advanced_chart, df_daily)
            result["ihsg_chart_path"] = chart_path
    except Exception as e:
        print(f"⚠️ Evening report: gagal hitung analisis IHSG: {e}")

    # ===== ROTASI SEKTOR (1 hari) =====
    try:
        result["sector_data"] = await get_sector_performance(period_days=1)
    except Exception as e:
        print(f"⚠️ Evening report: gagal hitung rotasi sektor: {e}")

    # ===== AI SCORE MOVERS =====
    try:
        tickers = load_tickers(limit=EVENING_AI_SCAN_LIMIT)
        data_by_ticker = await async_download_many(tickers)
        movers = []
        for ticker, df in data_by_ticker.items():
            try:
                df_clean = fix_yf_columns(df).dropna()
                ai = calculate_ai_score_from_df(df_clean)
                if ai:
                    movers.append({"ticker": ticker.replace(".JK", ""), "score": ai["score"],
                                    "rating": ai["rating"], "signal": ai["signal"]})
            except Exception:
                continue
        movers.sort(key=lambda x: x["score"], reverse=True)
        result["ai_movers"] = movers[:5]
    except Exception as e:
        print(f"⚠️ Evening report: gagal hitung AI Score movers: {e}")

    # ===== BERITA =====
    try:
        result["news_items"] = await fetch_news(keyword=None, limit=3)
    except Exception as e:
        print(f"⚠️ Evening report: gagal ambil berita: {e}")

    return result


def _format_evening_market_section(market_data: dict) -> str:
    """Format komponen market-wide (SAMA untuk semua user) jadi teks
    pesan. Setiap bagian SELALU dicek None dulu -- kalau komponen gagal
    dihitung, bagian itu diganti pesan singkat 'tidak tersedia', BUKAN
    membuat seluruh pesan gagal."""
    sections = []

    # ----- IHSG -----
    ihsg = market_data.get("ihsg_analysis")
    if ihsg:
        backtest = ihsg.get("backtest_result")
        if backtest:
            backtest_text = (
                f"📈 Win rate historis kondisi serupa: {backtest['win_rate']}% "
                f"(dari {backtest['n']} kejadian historis, BUKAN jaminan masa depan)\n"
            )
        else:
            backtest_text = "📈 Validasi historis: tidak tersedia untuk kondisi saat ini (sideways/mixed)\n"

        sections.append(
            f"📊 *IHSG CLOSING ANALYSIS*\n"
            f"Harga: {ihsg['current_price']:,.0f} ({ihsg['daily_change']:+.2f}%)\n"
            f"Trend: {ihsg['ma_trend']} | RSI: {ihsg['rsi']} | MACD: {ihsg['macd_signal']}\n"
            f"Support: {ihsg['support_1']:,.0f} / {ihsg['support_2']:,.0f}\n"
            f"Resistance: {ihsg['resistance_1']:,.0f} / {ihsg['resistance_2']:,.0f}\n\n"
            f"🎯 Prediksi: *{ihsg['prediction']}* (confidence: {ihsg['confidence']})\n"
            f"{backtest_text}"
            f"Target pergerakan: {ihsg['target_move']}"
        )
    else:
        sections.append("📊 *IHSG CLOSING ANALYSIS*\nData tidak tersedia (gagal diambil, kemungkinan rate-limit Yahoo Finance).")

    # ----- SEKTOR -----
    sector_data = market_data.get("sector_data")
    if sector_data:
        leaders = sector_data[:3]
        laggards = sector_data[-3:][::-1]
        n_positive = sum(1 for s in sector_data if s["return_pct"] > 0)
        n_total = len(sector_data)
        leader_text = ", ".join(f"{s['nama_sektor']} ({s['return_pct']:+.1f}%)" for s in leaders)
        laggard_text = ", ".join(f"{s['nama_sektor']} ({s['return_pct']:+.1f}%)" for s in laggards)
        sections.append(
            f"🔄 *ROTASI SEKTOR HARI INI*\n"
            f"Terkuat: {leader_text}\n"
            f"Terlemah: {laggard_text}\n"
            f"Breadth: {n_positive}/{n_total} sektor positif"
        )
    else:
        sections.append("🔄 *ROTASI SEKTOR HARI INI*\nData tidak tersedia.")

    # ----- AI SCORE MOVERS -----
    movers = market_data.get("ai_movers")
    if movers:
        movers_text = "\n".join(
            f"{i}. {m['ticker']} - {m['score']}/100 {m['signal']} {m['rating']}"
            for i, m in enumerate(movers, 1)
        )
        sections.append(f"🚀 *AI SCORE MOVERS* (Top 5)\n{movers_text}")
    else:
        sections.append("🚀 *AI SCORE MOVERS*\nData tidak tersedia.")

    # ----- BERITA -----
    news_items = market_data.get("news_items")
    if news_items:
        news_text = "\n".join(
            f"• {sanitize_for_markdown(n['title'])} _({sanitize_for_markdown(n.get('source', ''))})_"
            for n in news_items
        )
        sections.append(f"📰 *BERITA TERKINI*\n{news_text}")
    else:
        sections.append("📰 *BERITA TERKINI*\nTidak ada berita signifikan saat ini.")

    return ("\n\n" + "="*40 + "\n\n").join(sections)


def _format_watchlist_recap(user_id: str, watchlist_data_by_ticker: dict) -> str:
    """Bagian PERSONAL per-user -- performa watchlist sejak ditambahkan,
    pakai data yang SUDAH didownload sebelumnya (TIDAK download ulang
    per user, lihat catatan efisiensi di send_evening_summary).

    GANTI dari versi lama yang cuma pointer teks statis ("Gunakan
    /rekapwl untuk update status") -- sekarang data SUNGGUHAN langsung
    ditampilkan di evening report."""
    watchlist = get_user_watchlist_db(user_id)
    if not watchlist:
        return "⭐ *WATCHLIST KAMU*\nBelum ada saham di watchlist. Pakai /addwl [kode] untuk menambahkan."

    lines = []
    for item in watchlist[:10]:  # cap 10 supaya pesan tidak kepanjangan
        ticker = item["ticker"]
        full_ticker = ticker + ".JK"
        price_at_add = item.get("price_at_add")
        df = watchlist_data_by_ticker.get(full_ticker)

        if df is None or price_at_add is None or price_at_add <= 0:
            lines.append(f"• {ticker}: data tidak tersedia")
            continue

        try:
            df_clean = fix_yf_columns(df).dropna()
            if df_clean.empty:
                lines.append(f"• {ticker}: data tidak tersedia")
                continue
            current_price = float(df_clean["Close"].iloc[-1])
            change_pct = ((current_price / price_at_add) - 1) * 100
            emoji = "🟢" if change_pct > 0 else "🔴" if change_pct < 0 else "⚪"
            lines.append(f"{emoji} {ticker}: Rp{current_price:,.0f} ({change_pct:+.1f}% sejak ditambahkan)")
        except Exception:
            lines.append(f"• {ticker}: data tidak tersedia")

    extra_note = f"\n_...dan {len(watchlist)-10} saham lainnya, cek /rekapwl untuk daftar lengkap_" if len(watchlist) > 10 else ""
    return "⭐ *WATCHLIST KAMU*\n" + "\n".join(lines) + extra_note


async def generate_morning_report() -> str:
    """Buat morning market summary."""
    try:
        ihsg_data, global_data = await async_download_many(["^JKSE"], period="5d"), \
            await async_download_many(list(GLOBAL_INDICES.values()), period="2d")

        ihsg = fix_yf_columns(ihsg_data["^JKSE"]).dropna()
        last_close = ihsg["Close"].iloc[-1]
        prev_close = ihsg["Close"].iloc[-2]
        change = ((last_close / prev_close) - 1) * 100

        global_msg = ""
        for name, symbol in GLOBAL_INDICES.items():
            try:
                data = global_data.get(symbol)
                if data is None:
                    continue
                data = fix_yf_columns(data).dropna()
                if len(data) >= 2:
                    last = data["Close"].iloc[-1]
                    prev = data["Close"].iloc[-2]
                    chg = ((last / prev) - 1) * 100
                    emoji = "🟢" if chg > 0 else "🔴" if chg < 0 else "⚪"
                    global_msg += f"{emoji} {name}: {chg:+.2f}%\n"
            except Exception:
                continue

        bsjp_results = await run_bsjp_screener(load_tickers(limit=200))
        bsjp_text = format_bsjp_screener_results(bsjp_results)
        bsjp_preview = '\n'.join(bsjp_text.split('\n')[:8])

        msg = (
            f"🌅 *MORNING MARKET SUMMARY*\n"
            f"{datetime.now().strftime('%A, %d %B %Y')}\n"
            f"{'='*40}\n\n"
            f"📊 *GLOBAL OVERNIGHT:*\n{global_msg}\n"
            f"🇮🇩 *IHSG:*\n"
            f"Harga: {last_close:,.0f}\n"
            f"Perubahan: {change:+.2f}%\n\n"
            f"🎯 *PIVOT POINTS:*\n"
            f"• R1: {last_close + (last_close - prev_close):,.0f}\n"
            f"• Pivot: {last_close:,.0f}\n"
            f"• S1: {last_close - (last_close - prev_close):,.0f}\n\n"
            f"{'='*40}\n"
            f"🚀 *HOT STOCKS:*\n{bsjp_preview}\n\n"
            f"{'='*40}\n"
            f"💡 *TIPS HARI INI:*\n"
            f"• Waktu terbaik: 09:30-11:00 & 14:00-15:30\n"
            f"• Hindari jam 11:30-13:30\n"
            f"• Gunakan stop loss!\n\n"
            f"⚠️ DYOR & manage risk!"
        )
        return msg
    except Exception as e:
        print(f"Error generating morning report: {e}")
        return "❌ Gagal generate morning report"


async def send_morning_summary(context):
    """Kirim morning summary ke semua subscriber."""
    users = get_all_subscribed_users()
    report = await generate_morning_report()
    for user_id in users:
        try:
            await context.bot.send_message(chat_id=int(user_id), text=report, parse_mode='Markdown')
        except Exception as e:
            print(f"Error sending morning summary to {user_id}: {e}")


async def send_evening_summary(context):
    """Kirim evening summary ke semua subscriber -- DIROMBAK TOTAL
    (Juni 2026, permintaan eksplisit user: 'bikin lebih canggih lagi').

    GANTI dari versi lama yang cuma: IHSG closing + S/R PALSU (current_
    price*0.98/1.02, BUKAN kalkulasi sungguhan) + pointer teks statis
    ke /rekapwl. Sekarang menggabungkan SEMUA engine terbaik yang sudah
    dibangun di project ini jadi satu laporan: IHSG advanced analysis
    + chart (engine SAMA dengan /ihsg, S/R asli + prediksi tervalidasi
    backtest), rotasi sektor harian, AI Score movers (engine SAMA
    dengan /airank), berita terkini, DAN watchlist personal SUNGGUHAN
    per-user (bukan cuma pointer teks).

    EFISIENSI (konsisten dengan pola check_watchlist_alerts() di atas
    file ini): komponen market-wide dihitung SEKALI untuk SEMUA
    subscriber (bukan per-user), dan SEMUA ticker watchlist dari SEMUA
    user dikumpulkan dulu lalu didownload SEKALI secara paralel --
    bukan N user x M ticker download sekuensial."""
    users = get_all_subscribed_users()
    if not users:
        return

    print(f"[{datetime.now()}] Generating evening report (market-wide, sekali untuk semua subscriber)...")
    market_data = await _compute_evening_market_data()
    market_section = _format_evening_market_section(market_data)

    # Kumpulkan SEMUA ticker watchlist unik dari SEMUA user dulu --
    # pola SAMA dengan check_watchlist_alerts() (lihat catatan di atas
    # file ini soal bug performa N*M yang sudah diperbaiki sebelumnya).
    all_watchlist_tickers = set()
    for user_id in users:
        watchlist = get_user_watchlist_db(user_id)
        for item in watchlist[:10]:  # cap sama dengan _format_watchlist_recap
            all_watchlist_tickers.add(item["ticker"] + ".JK")

    watchlist_data_by_ticker = {}
    if all_watchlist_tickers:
        try:
            watchlist_data_by_ticker = await async_download_many(list(all_watchlist_tickers), period="5d", interval="1d")
        except Exception as e:
            print(f"WARNING Evening report: gagal download watchlist gabungan: {e}")

    header = f"🌙 *EVENING MARKET SUMMARY*\n{datetime.now().strftime('%A, %d %B %Y')}\n{'='*40}\n\n"
    footer = "\n\n" + "="*40 + "\n⚠️ Analisis ini alat bantu, BUKAN jaminan hasil. Selalu DYOR & manage risk!"

    chart_path = market_data.get("ihsg_chart_path")
    sent_count = 0

    for user_id in users:
        try:
            watchlist_section = _format_watchlist_recap(user_id, watchlist_data_by_ticker)
            full_msg = header + market_section + "\n\n" + "="*40 + "\n\n" + watchlist_section + footer

            # Chart IHSG dikirim SEKALI per user sebagai foto terpisah
            # (kalau berhasil dibuat) -- file yang SAMA dipakai ulang
            # untuk semua user (BUKAN generate ulang per user), baru
            # dihapus SETELAH SEMUA user selesai dikirimi (lihat akhir
            # fungsi ini).
            if chart_path and os.path.exists(chart_path):
                try:
                    with open(chart_path, "rb") as f:
                        await context.bot.send_photo(chat_id=int(user_id), photo=f)
                except Exception as e:
                    print(f"WARNING Gagal kirim chart evening report ke {user_id}: {e}")

            for chunk in _split_for_telegram(full_msg):
                await context.bot.send_message(chat_id=int(user_id), text=chunk, parse_mode='Markdown')
            sent_count += 1
        except Exception as e:
            print(f"Error sending evening summary to {user_id}: {e}")

    if chart_path and os.path.exists(chart_path):
        try:
            os.remove(chart_path)
        except Exception:
            pass

    print(f"[{datetime.now()}] Evening report terkirim ke {sent_count}/{len(users)} subscriber.")


# =========================
# WATCHLIST NEWS + SINYAL DIGEST (BARU)
# =========================
# Job harian: untuk tiap user, kirim BERITA yang menyebut saham di
# watchlist mereka, DILAMPIRI sinyal teknikalnya (fitur /news <KODE> yang
# dirangkai, tapi otomatis & terpersonalisasi -- user tidak perlu ketik
# apa-apa). Menyatukan: tagging emiten (core/news_emiten.py) + sinyal
# teknikal (core/news_signal.py) + watchlist per-user + scheduler.
#
# EFISIENSI (pola SAMA dengan check_watchlist_alerts & send_evening_
# summary di file ini): berita di-fetch SEKALI untuk semua user; emiten
# di-skor SEKALI untuk GABUNGAN watchlist semua user; lalu tiap user
# cuma di-filter ke sahamnya sendiri. TIDAK ada fetch/skor per-user.
#
# CATATAN KEBENARAN PENTING: item berita itu OBJEK BERSAMA lintas user.
# Sinyal TIDAK ditempel (mutasi) ke item per-user -- formatter membaca
# langsung dari skor_map yang difilter ke kode milik user. Kalau item
# dimutasi per-user, sinyal user A bisa bocor ke pesan user B.

WATCHLIST_NEWS_POOL_LIMIT = 30      # pool berita lebih besar -> peluang nyangkut watchlist naik
WATCHLIST_NEWS_MAX_EMITEN_SCORE = 15  # cap skoring (sama semangat dgn cap di core/news_signal.py)


def _format_watchlist_news_digest(user_items: list[dict], user_codes: set,
                                  skor_map: dict[str, dict]) -> str:
    """Format digest PERSONAL per-user. Murni teks (tanpa I/O) -> bisa
    di-unit-test tanpa mock network. Membaca sinyal dari skor_map
    (difilter ke kode milik user), TIDAK memutasi item bersama."""
    header = (
        f"📰🔔 *BERITA WATCHLIST KAMU*\n"
        f"{datetime.now().strftime('%A, %d %B %Y')}\n{'='*40}\n\n"
    )
    blocks = []
    for it in user_items:
        watched = [k for k in it.get("emiten", []) if k in user_codes]
        if not watched:
            continue
        b = f"*{sanitize_for_markdown(it['title'])}*"
        src = sanitize_for_markdown(it.get("source", ""))
        if src:
            b += f" _({src})_"
        b += "\n📌 " + ", ".join(sanitize_for_markdown(k) for k in watched) + "\n"
        for k in watched:
            s = skor_map.get(k)
            if s:
                arah = "+" if s["change_1d"] >= 0 else ""
                b += (f"{s['signal']} *{sanitize_for_markdown(k)}* {s['score']}/100 "
                      f"({sanitize_for_markdown(s['rating'])}) {arah}{s['change_1d']}% hari ini\n")
        summary = it.get("summary", "")
        if summary:
            if len(summary) > 150:
                summary = summary[:150].rsplit(" ", 1)[0] + "..."
            b += sanitize_for_markdown(summary) + "\n"
        if it.get("link"):
            b += f"🔗 {it['link']}\n"
        blocks.append(b)

    footer = (
        "\n" + "="*40 + "\n_Berita yang menyebut saham di watchlist-mu, dilampiri kondisi "
        "teknikalnya saat ini. Kondisi teknikal di SAMPING berita = korelasi waktu, BUKAN klaim "
        "berita yang menyebabkannya. DYOR & manage risk._"
    )
    return header + "\n".join(blocks) + footer


async def send_watchlist_news_digest(context):
    """Kirim digest berita+sinyal watchlist ke semua subscriber. Lihat
    catatan efisiensi & kebenaran di atas blok ini."""
    print(f"[{datetime.now()}] Running watchlist news digest...")

    users = get_all_subscribed_users()
    if not users:
        return

    # 1. Fetch berita SEKALI (fetch_news sudah meng-tag emiten tiap item).
    try:
        items = await fetch_news(keyword=None, limit=WATCHLIST_NEWS_POOL_LIMIT)
    except Exception as e:
        print(f"⚠️ Digest: gagal fetch berita: {e}")
        return
    if not items:  # None (semua sumber gagal) ATAU [] (tidak ada hasil)
        print("Digest: tidak ada berita, dilewati.")
        return

    # 2. Kumpulkan watchlist semua user (operasi DB lokal, cepat).
    user_codes: dict[str, set] = {}
    semua_watch: set = set()
    for uid in users:
        wl = get_user_watchlist_db(uid)
        kodes = {item["ticker"] for item in wl} if wl else set()
        if kodes:
            user_codes[uid] = kodes
            semua_watch |= kodes
    if not semua_watch:
        return

    # 3. Saring berita yang menyebut MINIMAL 1 saham di gabungan watchlist.
    relevan = [it for it in items if set(it.get("emiten", [])) & semua_watch]
    if not relevan:
        print("Digest: tidak ada berita yang menyentuh watchlist user hari ini.")
        return

    # 4. Skor emiten (yang muncul di berita relevan & ada di watchlist) SEKALI
    #    untuk SEMUA user sekaligus (bukan per-user).
    emiten_to_score: set = set()
    for it in relevan:
        emiten_to_score |= set(it.get("emiten", [])) & semua_watch
    try:
        skor_map = await score_emiten(list(emiten_to_score)[:WATCHLIST_NEWS_MAX_EMITEN_SCORE])
    except Exception as e:
        print(f"⚠️ Digest: gagal skor emiten (berita tetap dikirim tanpa sinyal): {e}")
        skor_map = {}

    # 5. Kirim per user -- HANYA berita yang menyentuh sahamnya. Item TIDAK
    #    dimutasi; formatter membaca skor_map yang difilter ke kode user.
    sent = 0
    for uid, kodes in user_codes.items():
        user_items = [it for it in relevan if set(it.get("emiten", [])) & kodes]
        if not user_items:
            continue  # user ini tidak punya berita relevan hari ini -> tidak dispam
        msg = _format_watchlist_news_digest(user_items, kodes, skor_map)
        try:
            for chunk in _split_for_telegram(msg):
                await context.bot.send_message(chat_id=int(uid), text=chunk, parse_mode="Markdown")
            sent += 1
        except Exception as e:
            print(f"Gagal kirim digest ke {uid}: {e}")

    print(f"[{datetime.now()}] Watchlist news digest terkirim ke {sent} user.")


def _split_for_telegram(text: str, chunk_size: int = 4000) -> list[str]:
    """Pecah pesan panjang jadi beberapa chunk -- evening report yang
    diperkaya ini BISA melebihi batas 4096 karakter Telegram, beda dari
    versi lama yang selalu pendek. Implementasi sederhana: potong per
    baris supaya tidak memutus kalimat di tengah."""
    if len(text) <= chunk_size:
        return [text]
    chunks = []
    current = ""
    for line in text.split("\n"):
        if len(current) + len(line) + 1 > chunk_size:
            chunks.append(current)
            current = line
        else:
            current = f"{current}\n{line}" if current else line
    if current:
        chunks.append(current)
    return chunks
