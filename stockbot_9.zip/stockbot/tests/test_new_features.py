#!/usr/bin/env python3
# =========================
# TEST SUITE OFFLINE - FITUR BARU
# =========================
# Mengunci perilaku fitur yang dibangun (news dedup/tagging/sinyal,
# digest, SMC, laporan PDF saham & IHSG) supaya tidak diam-diam rusak
# saat kode diubah lagi. SEMUA offline: data OHLCV sintetis + mock
# network. Tidak butuh koneksi internet / Yahoo Finance.
#
# Cara jalan:
#   python tests/test_new_features.py
# Keluar code 0 kalau semua lolos, 1 kalau ada yang gagal.
#
# CATATAN: ini menguji LOGIKA & RENDER (yang deterministik). Alur unduh
# data LIVE diuji terpisah lewat tools/smoke_test_live.py di mesinmu.

import os
import sys
import asyncio
import re
from unittest.mock import patch

import numpy as np
import pandas as pd

# Pastikan root project ada di path saat dijalankan dari mana saja
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import core.charts  # noqa: F401  (aktifkan filter warning chart)


# ---------- util ----------
def synth_ohlcv(seed=42, n=260, start=7000, drift=3, vol=70):
    rng = np.random.default_rng(seed)
    close = np.maximum(start + np.cumsum(rng.normal(drift, vol, n)), 500)
    return pd.DataFrame({
        "Open": close + rng.normal(0, vol * 0.4, n),
        "High": close + rng.uniform(vol * 0.1, vol, n),
        "Low": close - rng.uniform(vol * 0.1, vol, n),
        "Close": close,
        "Volume": rng.uniform(5e6, 2e7, n),
    }, index=pd.date_range("2025-09-01", periods=n, freq="D"))


_results = []


def check(name, cond, detail=""):
    _results.append((name, bool(cond)))
    status = "✓" if cond else "✗"
    print(f"  {status} {name}" + (f" — {detail}" if detail and not cond else ""))


# ---------- tests ----------
def test_dedup():
    from core.news import _deduplikasi
    items = [
        {"title": "BBCA Cetak Laba Rp54 T", "summary": "x", "link": "a", "source": "CNBC Indonesia", "kategori": "berita"},
        {"title": "BBCA cetak laba Rp 54 T!", "summary": "lebih panjang informatif", "link": "b", "source": "Detik Finance", "kategori": "berita"},
        {"title": "IHSG melemah tipis", "summary": "beda", "link": "c", "source": "CNN Indonesia", "kategori": "berita"},
    ]
    out = _deduplikasi(items)
    check("dedup menggabungkan judul mirip", len(out) == 2, f"dapat {len(out)}")
    merged = next((i for i in out if "BBCA" in i["title"]), None)
    check("dedup mencatat sumber_lain", merged and merged.get("sumber_lain"), )


def test_emiten_tagging():
    from core.news_emiten import deteksi_emiten
    cases = [
        ("BBCA cetak laba bersih, BMRI naik", ["BBCA", "BMRI"]),
        ("Harga BBM naik, rupiah melemah", []),                 # 'laba'/'naik' lowercase != ticker
        ("Barang ini good dan care lingkungan", []),            # kata umum lowercase
        ("TLKM bagikan dividen, ANTM rilis lapkeu", ["TLKM", "ANTM"]),
    ]
    ok = all(deteksi_emiten(t) == e for t, e in cases)
    check("tagging emiten case-sensitive (tanpa false positive)", ok,
          str([(t, deteksi_emiten(t)) for t, e in cases if deteksi_emiten(t) != e]))


def test_news_signal_enrich():
    from core import news_signal
    async def fake_many(tickers, **kw):
        return {t: synth_ohlcv(seed=abs(hash(t)) % 999, drift=4 if "BBCA" in t else -3) for t in tickers}
    items = [
        {"title": "BBCA dividen", "summary": "x", "source": "CNBC Indonesia", "kategori": "berita", "emiten": ["BBCA"]},
        {"title": "BMRI & BBCA", "summary": "y", "source": "Detik Finance", "kategori": "berita", "emiten": ["BMRI", "BBCA"]},
    ]
    with patch.object(news_signal, "async_download_many", fake_many):
        out = asyncio.run(news_signal.enrich_news_with_signals(items))
    has_signal = all("sinyal" in it for it in out)
    bbca_scored = any("BBCA" in (it.get("sinyal") or {}) for it in out)
    check("enrich melampirkan sinyal teknikal", has_signal and bbca_scored)


def test_digest_no_leak():
    from jobs import notification_jobs as nj
    def fake_users(): return ["101", "102", "103"]
    def fake_wl(uid): return {"101": [{"ticker": "BBCA"}], "102": [{"ticker": "ANTM"}], "103": [{"ticker": "GOTO"}]}.get(uid, [])
    async def fake_news(keyword=None, limit=30):
        return [
            {"title": "BBCA dividen", "summary": "a", "link": "1", "source": "CNBC Indonesia", "kategori": "berita", "emiten": ["BBCA"]},
            {"title": "ANTM lapkeu", "summary": "b", "link": "2", "source": "Detik Finance", "kategori": "berita", "emiten": ["ANTM"]},
            {"title": "makro lain", "summary": "c", "link": "3", "source": "CNN Indonesia", "kategori": "berita", "emiten": ["TLKM"]},
        ]
    async def fake_score(kodes):
        base = {"BBCA": {"score": 72, "rating": "BAGUS", "signal": "📈", "recommendation": "Akumulasi", "change_1d": 1.5, "price": 9000},
                "ANTM": {"score": 40, "rating": "CUKUP", "signal": "👀", "recommendation": "Wait", "change_1d": -0.8, "price": 1500}}
        return {k: base[k] for k in kodes if k in base}
    sent = {}
    class Bot:
        async def send_message(self, chat_id, text, parse_mode=None):
            sent.setdefault(str(chat_id), []).append(text)
    class Ctx: bot = Bot()
    with patch.object(nj, "get_all_subscribed_users", fake_users), \
         patch.object(nj, "get_user_watchlist_db", fake_wl), \
         patch.object(nj, "fetch_news", fake_news), \
         patch.object(nj, "score_emiten", fake_score):
        asyncio.run(nj.send_watchlist_news_digest(Ctx()))
    a = " ".join(sent.get("101", [])); b = " ".join(sent.get("102", []))
    no_leak = ("BBCA" in a and "ANTM" not in a) and ("ANTM" in b and "BBCA" not in b)
    skip_empty = "103" not in sent
    check("digest: tidak bocor antar-user", no_leak)
    check("digest: user tanpa berita relevan tidak dispam", skip_empty)


def test_smc_summary():
    from core.report import build_smc_summary
    smc = build_smc_summary(synth_ohlcv())
    has_all = smc and all(k in smc for k in ("n_bos", "ob_bullish", "fvg_unfilled", "liq_high", "liq_low", "narasi"))
    check("SMC summary lengkap (termasuk liquidity pools)", has_all)


def test_stock_report_pdf(tmp="/tmp/_t_stock.pdf"):
    from core.ai_score import calculate_ai_score_from_df
    from core.insight import _narrate_technical
    from core.report import build_report_data, build_smc_summary
    from core.charts.report_pdf import generate_report_pdf
    from core.charts.advanced_chart import generate_advanced_chart
    from core.smc import detect_bos_choch, detect_order_blocks, detect_fvg, detect_liquidity_pools
    from core.charts.smc_chart import (generate_bos_chart, generate_orderblock_chart,
                                       generate_fvg_chart, generate_liquidity_chart)
    df = synth_ohlcv()
    ai = calculate_ai_score_from_df(df)
    smc = build_smc_summary(df)
    charts = {}
    specs = [("Struktur (BOS/CHoCH)", generate_bos_chart, detect_bos_choch(df, 5, 5)),
             ("Order Block", generate_orderblock_chart, detect_order_blocks(df)),
             ("Fair Value Gap", generate_fvg_chart, detect_fvg(df)),
             ("Liquidity Pools", generate_liquidity_chart, detect_liquidity_pools(df))]
    for label, gen, d in specs:
        p = gen(df, "TEST", d)
        if p and os.path.exists(p):
            charts[label] = p
    adv = generate_advanced_chart(df, "TEST")
    rd = build_report_data("TEST", "Test Tbk", ai, insight={"teknikal": _narrate_technical(ai)},
                           chart_path=adv, smc=smc, smc_charts=charts)
    generate_report_pdf(rd, tmp)
    data = open(tmp, "rb").read()
    n_img = len(re.findall(rb"/Subtype\s*/Image", data))
    check("PDF saham ter-render", os.path.getsize(tmp) > 50000)
    check("PDF saham memuat semua chart (logo+harga+4 SMC=6)", n_img == 6, f"dapat {n_img}")
    for p in (adv, *charts.values(), tmp):
        if p and os.path.exists(p):
            os.remove(p)


def test_ihsg_report_pdf(tmp="/tmp/_t_ihsg.pdf"):
    from core.ihsg.ihsg_analysis import analyze_ihsg_with_backtest
    from core.report import build_ihsg_report_data, build_smc_summary
    from core.charts.report_pdf import generate_ihsg_report_pdf
    from core.smc import detect_bos_choch, detect_order_blocks, detect_fvg, detect_liquidity_pools
    from core.charts.smc_chart import (generate_bos_chart, generate_orderblock_chart,
                                       generate_fvg_chart, generate_liquidity_chart)
    df = synth_ohlcv(seed=3, n=520, start=7000, drift=1, vol=60)
    dfw = df.resample("W").agg({"Open": "first", "High": "max", "Low": "min", "Close": "last", "Volume": "sum"}).dropna()
    analysis = analyze_ihsg_with_backtest(df, dfw, df)
    check("analisis IHSG menghasilkan output", bool(analysis))
    if analysis:
        smc = build_smc_summary(df)
        charts = {}
        for label, gen, d in [("Struktur (BOS/CHoCH)", generate_bos_chart, detect_bos_choch(df, 5, 5)),
                              ("Order Block", generate_orderblock_chart, detect_order_blocks(df)),
                              ("Fair Value Gap", generate_fvg_chart, detect_fvg(df)),
                              ("Liquidity Pools", generate_liquidity_chart, detect_liquidity_pools(df))]:
            p = gen(df, "IHSG", d)
            if p and os.path.exists(p):
                charts[label] = p
        sector = [{"nama_sektor": "Energi", "return_pct": 2.1}, {"nama_sektor": "Keuangan", "return_pct": -0.8}]
        rd = build_ihsg_report_data(analysis, sector, None, [{"title": "Pasar menguat", "source": "CNBC Indonesia"}],
                                    None, smc=smc, smc_charts=charts)
        generate_ihsg_report_pdf(rd, tmp)
        n_img = len(re.findall(rb"/Subtype\s*/Image", open(tmp, "rb").read()))
        check("PDF IHSG ter-render", os.path.getsize(tmp) > 20000)
        check("PDF IHSG memuat SMC (logo+4 SMC chart=5)", n_img >= 5, f"dapat {n_img}")
        for p in (*charts.values(), tmp):
            if p and os.path.exists(p):
                os.remove(p)


def test_backtest_edge():
    from core.backtest import backtest_condition, condition_golden_cross_ma
    df = synth_ohlcv(seed=7, n=500, start=7000, drift=2, vol=60)
    r = backtest_condition(df, condition_golden_cross_ma, forward_days=5)
    ok = r is not None and "base_rate" in r and "edge" in r
    if ok:
        ok = ok and (r["edge"] == round(r["win_rate"] - r["base_rate"], 1))
    check("backtest melaporkan base_rate & edge (win_rate − base_rate)", ok)


def test_wyckoff_phases():
    from core.wyckoff import detect_phases, current_phase
    import numpy as np
    rng = np.random.default_rng(1)
    up = np.cumsum(rng.normal(6, 15, 120)); down = np.cumsum(rng.normal(-6, 15, 120))
    close = np.maximum(1000 + np.concatenate([up, up[-1] + down]), 100)
    df = pd.DataFrame({"Open": close, "High": close + 10, "Low": close - 10, "Close": close,
                       "Volume": rng.uniform(1e6, 5e6, len(close))},
                      index=pd.date_range("2025-01-01", periods=len(close), freq="D"))
    segs = detect_phases(df)
    phases = {s["phase"] for s in segs}
    ok = len(segs) >= 2 and "Markup" in phases and "Markdown" in phases and current_phase(df) is not None
    check("Wyckoff: deteksi fase Markup & Markdown", ok, str(phases))


def main():
    tests = [test_dedup, test_emiten_tagging, test_news_signal_enrich, test_digest_no_leak,
             test_smc_summary, test_backtest_edge, test_wyckoff_phases,
             test_stock_report_pdf, test_ihsg_report_pdf]
    print("=" * 50)
    print("TEST SUITE OFFLINE — FITUR BARU")
    print("=" * 50)
    for t in tests:
        print(f"\n[{t.__name__}]")
        try:
            t()
        except Exception as e:
            check(f"{t.__name__} (exception)", False, f"{type(e).__name__}: {e}")
    total = len(_results)
    passed = sum(1 for _, ok in _results if ok)
    print("\n" + "=" * 50)
    print(f"HASIL: {passed}/{total} lolos")
    print("=" * 50)
    return 0 if passed == total else 1


if __name__ == "__main__":
    sys.exit(main())
