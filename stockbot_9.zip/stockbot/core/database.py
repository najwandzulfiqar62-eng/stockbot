# =========================
# DATABASE LAYER (SQLite)
# =========================
# Modul ini menangani semua akses database: koneksi, skema tabel,
# dan operasi CRUD untuk users, watchlist, fixed_entries, alert_history.
#
# PERUBAHAN dari main.py versi lama:
# - Koneksi sekarang di-pool sederhana per-thread (bukan buka/tutup file
#   setiap kali dipanggil) supaya lebih ringan saat banyak user bersamaan.
# - PRAGMA synchronous=NORMAL ditambahkan (aman dipakai bersama WAL mode,
#   dan jauh lebih cepat daripada default FULL untuk beban tulis tinggi).
# - Semua fungsi tetap memakai parameterized query (placeholder "?"),
#   ini sudah benar di versi lama dan dipertahankan.

import sqlite3
import threading
from contextlib import contextmanager

from core.config import DATABASE_PATH

# Satu koneksi per thread. SQLite connection tidak thread-safe untuk dipakai
# lintas thread tanpa pengaturan ini, dan job_queue python-telegram-bot bisa
# menjalankan callback di thread yang berbeda dari handler biasa.
_local = threading.local()


def _get_connection() -> sqlite3.Connection:
    """Mengambil koneksi yang sudah ada untuk thread saat ini, atau membuat baru."""
    conn = getattr(_local, "conn", None)
    if conn is None:
        conn = sqlite3.connect(DATABASE_PATH, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        conn.execute("PRAGMA synchronous=NORMAL")
        _local.conn = conn
    return conn


@contextmanager
def get_db():
    """Context manager untuk transaksi SQLite. Commit otomatis di akhir,
    rollback otomatis kalau ada exception."""
    conn = _get_connection()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise


def init_database():
    """Inisialisasi semua tabel SQLite. Aman dipanggil berulang kali (IF NOT EXISTS)."""
    with get_db() as conn:
        cursor = conn.cursor()

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                user_id     TEXT PRIMARY KEY,
                username    TEXT,
                first_seen  TEXT DEFAULT (datetime('now')),
                last_active TEXT DEFAULT (datetime('now')),
                subscribed  INTEGER DEFAULT 0
            )
        ''')

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS watchlist (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id      TEXT NOT NULL,
                ticker       TEXT NOT NULL,
                added_date   TEXT DEFAULT (datetime('now')),
                price_at_add INTEGER,
                UNIQUE(user_id, ticker)
            )
        ''')

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS fixed_entries (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id      TEXT NOT NULL,
                ticker       TEXT NOT NULL,
                scenario_key TEXT NOT NULL,
                display_name TEXT,
                entry        INTEGER,
                sl           INTEGER,
                risk_pct     REAL,
                tp1          INTEGER,
                tp1_pct      REAL,
                tp2          INTEGER,
                tp2_pct      REAL,
                tp3          INTEGER,
                tp3_pct      REAL,
                created_date TEXT DEFAULT (datetime('now')),
                UNIQUE(user_id, ticker, scenario_key)
            )
        ''')

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS alert_history (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id      TEXT NOT NULL,
                ticker       TEXT NOT NULL,
                scenario_key TEXT NOT NULL,
                alert_date   TEXT NOT NULL,
                alert_type   TEXT,
                UNIQUE(user_id, ticker, scenario_key, alert_date)
            )
        ''')

        # Tabel price_alerts: alert harga custom yang user tentukan sendiri
        # via /alert TICKER TARGET_PRICE. BARU -- dulu fitur ini di main.py
        # lama hanya menampilkan pesan "berhasil" tanpa benar-benar
        # menyimpan apapun (lihat catatan di handlers/market_handlers.py).
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS price_alerts (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id       TEXT NOT NULL,
                ticker        TEXT NOT NULL,
                target_price  REAL NOT NULL,
                direction     TEXT NOT NULL,
                created_date  TEXT DEFAULT (datetime('now')),
                triggered     INTEGER DEFAULT 0,
                triggered_date TEXT
            )
        ''')

        # Tabel fundamental_cache: cache data fundamental (PE, PBV, ROE, dst)
        # dari yfinance .info -- BARU. Fundamental BEDA dari data harga:
        # berubah lambat (laporan keuangan per kuartal), TIDAK perlu fresh
        # tiap hari seperti OHLCV. yfinance .info juga jauh LEBIH BERAT
        # & lebih rawan rate-limit dibanding .download() biasa (mengambil
        # puluhan field sekaligus, bukan cuma OHLCV) -- caching mengurangi
        # beban request ke Yahoo Finance secara signifikan, bukan cuma
        # optimisasi kecepatan.
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS fundamental_cache (
                ticker        TEXT PRIMARY KEY,
                data_json     TEXT NOT NULL,
                cached_at     TEXT DEFAULT (datetime('now'))
            )
        ''')

        cursor.execute('CREATE INDEX IF NOT EXISTS idx_watchlist_user ON watchlist(user_id)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_entries_user   ON fixed_entries(user_id, ticker)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_alert_date     ON alert_history(alert_date)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_price_alerts_user ON price_alerts(user_id, triggered)')

        print("✅ SQLite database initialized!")


# =========================
# USER FUNCTIONS
# =========================

def save_user_to_db(user_id: str, username: str):
    """Upsert user ke database."""
    with get_db() as conn:
        conn.execute('''
            INSERT INTO users (user_id, username, first_seen, last_active, subscribed)
            VALUES (?, ?, datetime('now'), datetime('now'), 0)
            ON CONFLICT(user_id) DO UPDATE SET
                last_active = datetime('now'),
                username = excluded.username
        ''', (user_id, username))


def get_user_subscription(user_id: str) -> bool:
    """Cek apakah user subscribe daily summary."""
    with get_db() as conn:
        row = conn.execute(
            'SELECT subscribed FROM users WHERE user_id = ?', (user_id,)
        ).fetchone()
        return bool(row['subscribed']) if row else False


def set_user_subscription(user_id: str, subscribed: bool):
    """Set subscription status user."""
    with get_db() as conn:
        conn.execute(
            'UPDATE users SET subscribed = ? WHERE user_id = ?',
            (1 if subscribed else 0, user_id)
        )


def get_all_subscribed_users() -> list:
    """Dapatkan semua user yang subscribe."""
    with get_db() as conn:
        rows = conn.execute('SELECT user_id FROM users WHERE subscribed = 1').fetchall()
        return [row['user_id'] for row in rows]


# =========================
# WATCHLIST FUNCTIONS
# =========================

def add_to_watchlist_db(user_id: str, ticker: str, fixed_levels: dict):
    """Tambah saham ke watchlist beserta fixed entries-nya (4 skenario)."""
    with get_db() as conn:
        conn.execute('''
            INSERT INTO watchlist (user_id, ticker, added_date, price_at_add)
            VALUES (?, ?, ?, ?)
            ON CONFLICT (user_id, ticker) DO UPDATE
                SET added_date   = excluded.added_date,
                    price_at_add = excluded.price_at_add
        ''', (user_id, ticker, fixed_levels['created_date'], fixed_levels['price_at_create']))

        for key, scenario in fixed_levels['scenarios'].items():
            conn.execute('''
                INSERT INTO fixed_entries
                    (user_id, ticker, scenario_key, display_name,
                     entry, sl, risk_pct,
                     tp1, tp1_pct, tp2, tp2_pct, tp3, tp3_pct,
                     created_date)
                VALUES (?,?,?,?, ?,?,?, ?,?,?,?,?,?, ?)
                ON CONFLICT (user_id, ticker, scenario_key) DO UPDATE
                    SET display_name = excluded.display_name,
                        entry        = excluded.entry,
                        sl           = excluded.sl,
                        risk_pct     = excluded.risk_pct,
                        tp1          = excluded.tp1,
                        tp1_pct      = excluded.tp1_pct,
                        tp2          = excluded.tp2,
                        tp2_pct      = excluded.tp2_pct,
                        tp3          = excluded.tp3,
                        tp3_pct      = excluded.tp3_pct,
                        created_date = excluded.created_date
            ''', (
                user_id, ticker, key, scenario['display_name'],
                int(scenario['entry']), int(scenario['sl']), scenario['risk_pct'],
                int(scenario['tp1']), scenario['tp1_pct'],
                int(scenario['tp2']), scenario['tp2_pct'],
                int(scenario['tp3']), scenario['tp3_pct'],
                fixed_levels['created_date']
            ))


def get_user_watchlist_db(user_id: str) -> list:
    """Ambil semua saham di watchlist user."""
    with get_db() as conn:
        rows = conn.execute('''
            SELECT ticker, price_at_add, added_date
            FROM watchlist
            WHERE user_id = ?
            ORDER BY added_date DESC
        ''', (user_id,)).fetchall()
        return [dict(row) for row in rows]


def remove_from_watchlist_db(user_id: str, ticker: str):
    """Hapus saham dari watchlist dan fixed entries-nya."""
    with get_db() as conn:
        conn.execute('DELETE FROM watchlist     WHERE user_id = ? AND ticker = ?', (user_id, ticker))
        conn.execute('DELETE FROM fixed_entries WHERE user_id = ? AND ticker = ?', (user_id, ticker))


def get_fixed_entries_db(user_id: str, ticker: str):
    """Ambil semua fixed entries untuk 1 saham. Return dict atau None."""
    with get_db() as conn:
        rows = conn.execute('''
            SELECT * FROM fixed_entries
            WHERE user_id = ? AND ticker = ?
        ''', (user_id, ticker)).fetchall()

    if not rows:
        return None

    scenarios = {}
    for row in rows:
        scenarios[row['scenario_key']] = {
            "display_name": row['display_name'],
            "entry":        row['entry'],
            "sl":           row['sl'],
            "risk_pct":     row['risk_pct'],
            "tp1":          row['tp1'],
            "tp1_pct":      row['tp1_pct'],
            "tp2":          row['tp2'],
            "tp2_pct":      row['tp2_pct'],
            "tp3":          row['tp3'],
            "tp3_pct":      row['tp3_pct'],
        }

    return {
        "created_date":    str(rows[0]['created_date']),
        "price_at_create": rows[0]['entry'],
        "scenarios":       scenarios
    }


def get_all_fixed_entries_for_user(user_id: str) -> dict:
    """Ambil semua fixed entries seluruh saham untuk 1 user."""
    with get_db() as conn:
        rows = conn.execute('''
            SELECT ticker, scenario_key, display_name,
                   entry, sl, risk_pct,
                   tp1, tp1_pct, tp2, tp2_pct, tp3, tp3_pct,
                   created_date
            FROM fixed_entries
            WHERE user_id = ?
        ''', (user_id,)).fetchall()

    result = {}
    for row in rows:
        t = row['ticker']
        if t not in result:
            result[t] = {"created_date": str(row['created_date']), "scenarios": {}}
        result[t]["scenarios"][row['scenario_key']] = {
            "display_name": row['display_name'],
            "entry":        row['entry'],
            "sl":           row['sl'],
            "risk_pct":     row['risk_pct'],
            "tp1":          row['tp1'],
            "tp1_pct":      row['tp1_pct'],
            "tp2":          row['tp2'],
            "tp2_pct":      row['tp2_pct'],
            "tp3":          row['tp3'],
            "tp3_pct":      row['tp3_pct'],
        }
    return result


# =========================
# ALERT HISTORY FUNCTIONS
# =========================

def save_alert_history_db(user_id: str, ticker: str, scenario_key: str,
                           alert_date: str, alert_type: str):
    """Simpan history alert agar tidak spam ke user yang sama di hari yang sama."""
    with get_db() as conn:
        conn.execute('''
            INSERT OR IGNORE INTO alert_history (user_id, ticker, scenario_key, alert_date, alert_type)
            VALUES (?, ?, ?, ?, ?)
        ''', (user_id, ticker, scenario_key, alert_date, alert_type))


def check_alert_sent_db(user_id: str, ticker: str, scenario_key: str,
                         alert_date: str) -> bool:
    """Cek apakah alert sudah pernah dikirim hari ini."""
    with get_db() as conn:
        row = conn.execute('''
            SELECT 1 FROM alert_history
            WHERE user_id = ? AND ticker = ?
              AND scenario_key = ? AND alert_date = ?
        ''', (user_id, ticker, scenario_key, alert_date)).fetchone()
        return row is not None


# =========================
# PRICE ALERT FUNCTIONS (custom alert harga, /alert TICKER PRICE)
# =========================
# BARU -- dulu /alert di main.py lama tidak benar-benar menyimpan apapun,
# cuma menampilkan pesan "berhasil" (lihat handlers/market_handlers.py).

def add_price_alert_db(user_id: str, ticker: str, target_price: float, direction: str):
    """Simpan alert harga custom. direction: 'above' atau 'below',
    ditentukan otomatis berdasarkan target_price vs harga saat alert dibuat."""
    with get_db() as conn:
        conn.execute('''
            INSERT INTO price_alerts (user_id, ticker, target_price, direction)
            VALUES (?, ?, ?, ?)
        ''', (user_id, ticker, target_price, direction))


def get_active_price_alerts_db(user_id: str = None) -> list:
    """Ambil semua price alert yang belum triggered. Kalau user_id None,
    ambil untuk SEMUA user (dipakai job scheduler)."""
    with get_db() as conn:
        if user_id:
            rows = conn.execute('''
                SELECT * FROM price_alerts WHERE user_id = ? AND triggered = 0
            ''', (user_id,)).fetchall()
        else:
            rows = conn.execute('SELECT * FROM price_alerts WHERE triggered = 0').fetchall()
        return [dict(row) for row in rows]


def mark_price_alert_triggered_db(alert_id: int):
    """Tandai price alert sebagai sudah triggered (terkena), supaya tidak
    dikirim notifikasi berulang."""
    with get_db() as conn:
        conn.execute('''
            UPDATE price_alerts SET triggered = 1, triggered_date = datetime('now')
            WHERE id = ?
        ''', (alert_id,))


def remove_price_alert_db(user_id: str, alert_id: int):
    """Hapus price alert milik user tertentu (validasi ownership)."""
    with get_db() as conn:
        conn.execute('DELETE FROM price_alerts WHERE id = ? AND user_id = ?', (alert_id, user_id))


# =========================
# FUNDAMENTAL CACHE (BARU)
# =========================

def get_cached_fundamental_db(ticker: str, max_age_days: int = 7) -> dict | None:
    """Ambil data fundamental dari cache, kalau ADA dan belum lebih tua
    dari max_age_days. Returns None kalau tidak ada cache atau sudah basi
    (caller harus fetch fresh dari yfinance dan simpan ulang).

    max_age_days=7: data fundamental (PE, ROE, dst) berubah lambat
    (laporan keuangan per kuartal), 7 hari adalah kompromi wajar antara
    data yang cukup fresh vs mengurangi beban request ke yfinance."""
    import json
    with get_db() as conn:
        row = conn.execute('''
            SELECT data_json, cached_at FROM fundamental_cache
            WHERE ticker = ? AND cached_at > datetime('now', ?)
        ''', (ticker, f'-{max_age_days} days')).fetchone()
        if row is None:
            return None
        try:
            return json.loads(row["data_json"])
        except (json.JSONDecodeError, TypeError):
            return None  # cache korup -- treat sebagai cache miss, bukan crash


def save_fundamental_cache_db(ticker: str, data: dict):
    """Simpan/update data fundamental ke cache (REPLACE -- timpa cache lama)."""
    import json
    with get_db() as conn:
        conn.execute('''
            INSERT INTO fundamental_cache (ticker, data_json, cached_at)
            VALUES (?, ?, datetime('now'))
            ON CONFLICT(ticker) DO UPDATE SET
                data_json = excluded.data_json,
                cached_at = excluded.cached_at
        ''', (ticker, json.dumps(data)))
