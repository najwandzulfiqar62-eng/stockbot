# =========================
# BACKTESTING SINYAL (VALIDASI STATISTIK HISTORIS)
# =========================
# FITUR BARU. Tujuan: ketika /signal atau /bsjp mengeluarkan sinyal untuk
# suatu saham, user bisa tahu "dalam histori saham ini, kondisi serupa
# muncul berapa kali, dan berapa persen yang akhirnya naik dalam N hari
# ke depan". Ini mengubah AI score dari rule-based scoring murni jadi
# punya bukti statistik konkret di belakangnya.
#
# PENTING -- KETERBATASAN YANG HARUS DISADARI (supaya tidak menyesatkan
# user dengan overclaim statistik):
# - Sample historis dari satu saham individual biasanya KECIL (puluhan
#   kejadian dalam 1-2 tahun data), jadi "win rate 70%" dari 10 kejadian
#   beda jauh kredibilitasnya dari yang sama dari 100 kejadian. Hasil
#   SELALU menyertakan jumlah sample (n) dan TIDAK PERNAH ditampilkan
#   tanpa itu.
# - Backtest "kondisi sama pernah muncul, harga naik X%" adalah pengujian
#   pada DATA YANG SAMA dengan yang dipakai screener (in-sample), bukan
#   out-of-sample validation yang sesungguhnya. Ini bentuk paling
#   sederhana dari validasi historis, bukan bukti bahwa strategi akan
#   profitable di masa depan. Disclaimer ini WAJIB ada di setiap output.
# - "Naik dalam N hari" tidak memperhitungkan kapan harus exit / stop
#   loss di tengah jalan -- ini ukuran arah pergerakan, bukan simulasi
#   trading plan lengkap.

import numpy as np
import pandas as pd

from core.indicators import calculate_rsi

MIN_SAMPLE_SIZE = 5  # di bawah ini, hasil backtest dianggap tidak cukup andal untuk ditampilkan


def _detect_signal_occurrences(df: pd.DataFrame, condition_fn) -> list[int]:
    """Scan seluruh df, kembalikan list index (posisi baris) di mana
    condition_fn(df, i) bernilai True. condition_fn menerima df dan
    index baris, return bool."""
    occurrences = []
    for i in range(20, len(df) - 1):  # mulai dari 20 supaya MA20 dkk sudah valid
        try:
            if condition_fn(df, i):
                occurrences.append(i)
        except Exception:
            continue
    return occurrences


def _forward_return(df: pd.DataFrame, idx: int, forward_days: int) -> float | None:
    """Hitung return harga dari index idx ke idx+forward_days. Return
    None kalau idx+forward_days di luar range data (sinyal terlalu baru
    untuk dihitung forward return-nya)."""
    target_idx = idx + forward_days
    if target_idx >= len(df):
        return None
    entry_price = float(df["Close"].iloc[idx])
    future_price = float(df["Close"].iloc[target_idx])
    return ((future_price / entry_price) - 1) * 100


def _base_rate(df: pd.DataFrame, forward_days: int) -> float | None:
    """Win rate TANPA SYARAT (base rate): dari SEMUA hari di histori,
    berapa persen yang harganya naik dalam forward_days ke depan.

    KENAPA PENTING (inti perbaikan berbasis riset): "win rate sinyal 58%"
    tidak berarti apa-apa kalau pasar memang naik 56% di hari acak mana
    pun (IHSG cenderung drift naik jangka panjang). Yang bermakna adalah
    EDGE = win_rate sinyal − base_rate. Literatur technical trading rules
    menekankan perbandingan terhadap null model / baseline ini (mis. Chen,
    Huang & Lai 2009 soal data-snooping di pasar Asia; Brock, Lakonishok &
    LeBaron 1992). Tanpa baseline, win rate gampang menyesatkan."""
    rets = []
    for i in range(20, len(df) - forward_days):
        r = _forward_return(df, i, forward_days)
        if r is not None:
            rets.append(r)
    if not rets:
        return None
    arr = np.array(rets)
    return round(float((arr > 0).mean() * 100), 1)


def backtest_condition(df: pd.DataFrame, condition_fn, forward_days: int = 5) -> dict | None:
    """Backtest satu kondisi sinyal terhadap histori harga.

    condition_fn: function(df, i) -> bool, kondisi yang dicek di tiap baris i.
    forward_days: berapa hari ke depan untuk mengukur hasil (default 5,
    konsisten dengan horizon swing-trading jangka pendek).

    Returns dict berisi statistik, atau None kalau sample terlalu kecil
    (< MIN_SAMPLE_SIZE) untuk dianggap bermakna.
    """
    occurrences = _detect_signal_occurrences(df, condition_fn)

    returns = []
    for idx in occurrences:
        r = _forward_return(df, idx, forward_days)
        if r is not None:
            returns.append(r)

    n = len(returns)
    if n < MIN_SAMPLE_SIZE:
        return None

    returns_arr = np.array(returns)
    win_count = int((returns_arr > 0).sum())
    win_rate = (win_count / n) * 100

    base_rate = _base_rate(df, forward_days)
    edge = round(win_rate - base_rate, 1) if base_rate is not None else None

    return {
        "n": n,
        "forward_days": forward_days,
        "win_rate": round(win_rate, 1),
        "base_rate": base_rate,          # win rate tanpa syarat (baseline)
        "edge": edge,                    # win_rate − base_rate; >0 = ada keunggulan
        "win_count": win_count,
        "loss_count": n - win_count,
        "avg_return": round(float(returns_arr.mean()), 2),
        "median_return": round(float(np.median(returns_arr)), 2),
        "best_return": round(float(returns_arr.max()), 2),
        "worst_return": round(float(returns_arr.min()), 2),
        "std_return": round(float(returns_arr.std()), 2),
    }


# ===== KONDISI SIAP-PAKAI (konsisten dengan kondisi /signal & /bsjp) =====

def condition_ma_cross_volume_spike(df: pd.DataFrame, i: int) -> bool:
    """Kondisi /signal: MA5>MA20 + volume spike + harga>200 + volume>500rb.
    Identik dengan kondisi cond1-cond4 di core/screener.py run_screener(),
    supaya backtest benar-benar mengukur kondisi yang sama dengan yang
    dipakai screener live."""
    ma5 = df["Close"].rolling(5).mean().iloc[i]
    ma20 = df["Close"].rolling(20).mean().iloc[i]
    vol_ma5 = df["Volume"].rolling(5).mean().iloc[i]
    vol_ma20 = df["Volume"].rolling(20).mean().iloc[i]
    close = df["Close"].iloc[i]
    volume = df["Volume"].iloc[i]

    cond1 = ma5 > ma20
    cond2 = (vol_ma5 / vol_ma20 if vol_ma20 > 0 else 1) > 1.2
    cond3 = close > 200
    cond4 = volume > 500000
    return cond1 and cond2 and cond3 and cond4


def condition_rsi_oversold(df: pd.DataFrame, i: int, threshold: float = 30) -> bool:
    """Kondisi RSI oversold (dipakai di banyak tempat: ai_score, advanced_chart)."""
    rsi = calculate_rsi(df["Close"])
    return rsi.iloc[i] < threshold


def condition_golden_cross_ma(df: pd.DataFrame, i: int) -> bool:
    """Golden cross: MA5 baru saja naik melewati MA20 (crossover persis
    di baris ini, bukan sudah berlangsung lama)."""
    ma5 = df["Close"].rolling(5).mean()
    ma20 = df["Close"].rolling(20).mean()
    if i < 1:
        return False
    return ma5.iloc[i - 1] <= ma20.iloc[i - 1] and ma5.iloc[i] > ma20.iloc[i]


def condition_ihsg_bullish_strong(df: pd.DataFrame, i: int) -> bool:
    """Versi ringkas dari 'skor bullish TINGGI' di analyze_ihsg_advanced
    (core/ihsg/ihsg_analysis.py): trend MA daily kuat (close > MA20 >
    MA50) + RSI belum overbought + MACD histogram positif. Sengaja tidak
    menyertakan komponen yang butuh data weekly atau pivot clustering
    (lebih mahal dihitung berulang untuk setiap baris saat backtest scan
    ratusan hari) -- ini APROKSIMASI dari kondisi penuh, dipakai khusus
    untuk mengukur win-rate historis yang menggantikan accuracy_estimate
    yang dulu rumus arbitrer (lihat catatan di ihsg_analysis.py)."""
    ma20 = df["Close"].rolling(20).mean().iloc[i]
    ma50 = df["Close"].rolling(50).mean().iloc[i]
    close = df["Close"].iloc[i]

    rsi = calculate_rsi(df["Close"])
    current_rsi = rsi.iloc[i]

    ema12 = df["Close"].ewm(span=12, adjust=False).mean()
    ema26 = df["Close"].ewm(span=26, adjust=False).mean()
    macd_line = ema12 - ema26
    signal_line = macd_line.ewm(span=9, adjust=False).mean()
    macd_hist = (macd_line - signal_line).iloc[i]

    trend_strong = close > ma20 and ma20 > ma50
    rsi_ok = 40 < current_rsi < 70  # bullish tapi belum overbought
    macd_bullish = macd_hist > 0

    return trend_strong and rsi_ok and macd_bullish


def condition_ihsg_bearish_strong(df: pd.DataFrame, i: int) -> bool:
    """Kebalikan dari condition_ihsg_bullish_strong -- versi ringkas
    'skor bearish TINGGI'. Lihat catatan di condition_ihsg_bullish_strong."""
    ma20 = df["Close"].rolling(20).mean().iloc[i]
    ma50 = df["Close"].rolling(50).mean().iloc[i]
    close = df["Close"].iloc[i]

    rsi = calculate_rsi(df["Close"])
    current_rsi = rsi.iloc[i]

    ema12 = df["Close"].ewm(span=12, adjust=False).mean()
    ema26 = df["Close"].ewm(span=26, adjust=False).mean()
    macd_line = ema12 - ema26
    signal_line = macd_line.ewm(span=9, adjust=False).mean()
    macd_hist = (macd_line - signal_line).iloc[i]

    trend_weak = close < ma20 and ma20 < ma50
    rsi_ok = 30 < current_rsi < 60  # bearish tapi belum oversold
    macd_bearish = macd_hist < 0

    return trend_weak and rsi_ok and macd_bearish


CONDITION_REGISTRY = {
    "ma_cross_volume": ("MA5>MA20 + Volume Spike (kondisi /signal)", condition_ma_cross_volume_spike),
    "rsi_oversold": ("RSI Oversold (<30)", condition_rsi_oversold),
    "golden_cross": ("Golden Cross MA5/MA20", condition_golden_cross_ma),
    "ihsg_bullish_strong": ("Trend Bullish Kuat (MA+RSI+MACD)", condition_ihsg_bullish_strong),
    "ihsg_bearish_strong": ("Trend Bearish Kuat (MA+RSI+MACD)", condition_ihsg_bearish_strong),
}


def format_backtest_result(ticker_name: str, condition_label: str, result: dict | None) -> str:
    """Format hasil backtest_condition() jadi pesan teks untuk user."""
    if result is None:
        return (
            f"📊 *BACKTEST: {condition_label}*\n"
            f"Saham: {ticker_name}\n\n"
            f"⚠️ Kondisi ini terlalu jarang muncul di histori {ticker_name} "
            f"(kurang dari {MIN_SAMPLE_SIZE} kejadian dalam data yang tersedia) "
            f"untuk dihitung statistiknya secara bermakna."
        )

    win_emoji = "🟢" if result["win_rate"] >= 60 else "🟡" if result["win_rate"] >= 45 else "🔴"

    return f"""
📊 *BACKTEST: {condition_label}*
Saham: {ticker_name}
{'='*40}

Kondisi ini muncul *{result['n']}x* di histori data yang tersedia.

{win_emoji} *Win Rate ({result['forward_days']} hari ke depan): {result['win_rate']}%*
├─ Naik: {result['win_count']}x
└─ Turun/Stagnan: {result['loss_count']}x

📈 *Return rata-rata: {result['avg_return']:+.2f}%*
├─ Median: {result['median_return']:+.2f}%
├─ Terbaik: {result['best_return']:+.2f}%
├─ Terburuk: {result['worst_return']:+.2f}%
└─ Std Dev: {result['std_return']:.2f}%

{'='*40}
⚠️ *PENTING:*
• Sample {result['n']}x {"tergolong kecil -- " if result['n'] < 15 else ""}hasil ini gambaran historis, BUKAN garansi hasil masa depan.
• Ini pengujian pada data yang sama dipakai screener (bukan validasi out-of-sample murni).
• Tidak memperhitungkan stop loss/exit di tengah jalan, cuma ukur arah harga.
• DYOR & gunakan sebagai SATU dari banyak pertimbangan, bukan satu-satunya.
"""
