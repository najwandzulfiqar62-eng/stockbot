# =========================
# CONFIGURATION
# =========================
# Semua nilai konfigurasi terpusat di sini supaya mudah ditemukan dan diubah.
#
# CATATAN SOAL BOT_TOKEN:
# Token di bawah ini sengaja TETAP ditulis langsung sesuai permintaan,
# bukan dipindah ke environment variable. Tapi tolong diingat risikonya:
# siapapun yang punya akses ke file/repo ini akan otomatis punya kontrol
# penuh ke bot Telegram-mu (kirim pesan ke semua subscriber, dsb).
# Kalau nanti project ini didorong ke Git repo (terutama yang publik),
# pertimbangkan untuk pindah ke os.environ.get("BOT_TOKEN") saat itu.

import os

# ---- Telegram ----
BOT_TOKEN = "8590771246:AAGd8MVZaxPC4SPWxH7JKgWNqBdLGWEMuuk"

# ---- Database ----
DATABASE_PATH = os.environ.get("DATABASE_URL", "stockbot.db")

# ---- Data Saham ----
# File Excel berisi daftar saham yang tercatat di BEI (kolom: Kode, Nama
# Perusahaan, Papan Pencatatan, dst). Diambil dari data/saham.xlsx.
SAHAM_XLSX_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "saham.xlsx")

# Papan pencatatan yang DI-EXCLUDE dari screening otomatis.
# "Pemantauan Khusus" = saham yang sedang diawasi BEI karena masalah
# likuiditas/keuangan/kepatuhan. Diexclude sesuai keputusan produk:
# lebih aman untuk rekomendasi yang dipakai komunitas.
EXCLUDED_PAPAN_PENCATATAN = {"Pemantauan Khusus"}

# Fallback kalau file Excel gagal dibaca (rusak/hilang). Dulu ini dipakai
# diam-diam tanpa warning — sekarang load_tickers() akan selalu print
# warning yang jelas kalau sampai jatuh ke sini, supaya tidak ketahuan
# belakangan bahwa screening cuma jalan di 8 saham.
FALLBACK_TICKERS = [
    "BBCA.JK", "BBRI.JK", "BMRI.JK", "TLKM.JK",
    "ASII.JK", "BRMS.JK", "MDKA.JK", "ANTM.JK"
]

# ---- Rate limiting / batching untuk panggilan ke Yahoo Finance ----
# Dipakai saat melakukan loop banyak ticker (screener, auto-alert check)
# supaya tidak membombardir Yahoo Finance dan kena rate-limit/IP block.
YF_BATCH_SIZE = 40          # jumlah ticker per batch
YF_BATCH_DELAY_SECONDS = 0.8  # delay antar batch
