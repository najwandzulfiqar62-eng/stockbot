# =========================
# AI STOCK SCREENER (IDX) - main.py
# =========================
# Versi modular hasil refactor menyeluruh dari main.py asli (6022 baris,
# monolitik). Semua logic kalkulasi & I/O dipisah ke core/, handlers/,
# dan jobs/ -- masing-masing sudah diverifikasi numerik dan/atau
# end-to-end secara terpisah selama proses migrasi.
#
# RINGKASAN PERUBAHAN UTAMA dari main.py lama (detail lengkap ada di
# komentar masing-masing modul):
# 1. SEMUA download yfinance dipindah dari blocking sync ke
#    asyncio.to_thread (core/async_yf.py) -- dulu satu user yang
#    menjalankan screening akan memblokir SELURUH bot untuk SEMUA user.
# 2. Loop sequential per-ticker di screener/filter/watchlist/notification
#    jobs diganti jadi batch paralel (async_download_many).
# 3. check_watchlist_alerts (job per jam) dulu N_user x M_ticker download
#    sequential; sekarang dedup ticker dulu lalu SATU batch download
#    paralel untuk semua user sekaligus.
# 4. /alert dulu FITUR PALSU (cuma menampilkan pesan, tidak menyimpan
#    apapun) -- sekarang benar-benar tersimpan ke DB dan dicek otomatis
#    via job check_price_alerts (BARU).
# 5. /ihsg: field target_move dulu RANDOM (random.uniform), sekarang
#    dihitung dari ATR (volatilitas riil index). Field accuracy_estimate
#    (ditampilkan sebagai "Akurasi estimasi: X%") dulu rumus arbitrer
#    (50 + jumlah_indikator_searah*5) -- sekarang diganti win-rate
#    SUNGGUHAN dari backtest historis (lihat poin 13 di bawah).
# 6. RSI, MACD, Bollinger, ATR, StochRSI, S/R yang dulu diduplikasi
#    belasan kali di berbagai fungsi disatukan jadi core/indicators.py.
# 7. advanced_chart_cmd dan stock_menu_callback dulu DIDEFINISIKAN DUA
#    KALI (definisi pertama jadi kode mati); dikonsolidasikan jadi satu.
# 8. ai_score.py: fix bug NaN pada StochRSI fallback yang tidak pernah
#    benar-benar tereksekusi di kode lama.
# 9. app.add_error_handler() ditambahkan -- TIDAK ADA SAMA SEKALI di
#    kode lama, artinya error tak tertangani di handler manapun akan
#    membuat user tidak mendapat respons apapun tanpa jejak yang jelas.
# 10. Screening dibatasi ke 200 ticker pertama dari saham.xlsx (bukan
#     semua 793) untuk menjaga waktu respons wajar -- lihat catatan
#     performa di core/screener.py untuk trade-off yang disadari.
#
# FITUR BARU (analisis lanjutan, lihat catatan lengkap di masing-masing
# modul untuk detail dan disclaimer):
# 11. /backtest -- validasi statistik historis untuk kondisi sinyal
#     (core/backtest.py). Mengubah AI score dari rule-based murni jadi
#     punya bukti win-rate/return historis di belakangnya.
# 12. /rs -- relative strength vs IHSG dan sektor (core/relative_strength.py).
#     Membedakan saham yang outperform/underperform pasar secara umum.
# 13. [DIHAPUS] /mlpredict -- fitur prediksi ML (XGBoost) sempat dibangun
#     tapi DIHAPUS TOTAL (Juni 2026) atas keputusan eksplisit setelah
#     berkali-kali training (threshold 1%, 2%, dengan/tanpa fitur market
#     context) precision-nya tidak pernah cukup meyakinkan untuk
#     dipakai sebagai dasar keputusan beli (32-42%, marginal di atas
#     baseline acak). Daripada fitur yang kredibilitasnya selalu perlu
#     disclaimer panjang, diputuskan dihapus -- AI Score (/ranah dkk,
#     rule-based, bukan ML) tetap ada sebagai alternatif yang lebih
#     transparan metodologinya.
# 14. /ihsg: "accuracy_estimate" (poin 5 di atas) sepenuhnya dihapus
#     dari analyze_ihsg_advanced() dan diganti via fungsi wrapper baru
#     analyze_ihsg_with_backtest() (core/ihsg/ihsg_analysis.py), yang
#     menjalankan backtest_condition() pada histori IHSG 2 tahun dengan
#     kondisi condition_ihsg_bullish_strong/bearish_strong (BARU, di
#     core/backtest.py) -- dipilih otomatis sesuai prediction yang
#     dihasilkan. Handler sekarang download 3 timeframe paralel (daily
#     3mo, weekly 1y, daily 2y khusus backtest) via asyncio.gather.
# 15. /bos /choch /orderblock /fvg /liquidity (BARU) -- Smart Money
#     Concepts (SMC), modul core/smc.py. Definisi BOS/CHOCH/Order
#     Block/FVG/Liquidity Pool DIKONFIRMASI via riset web (bukan
#     ditebak), termasuk DISCLAIMER EKSPLISIT bahwa narasi "jejak
#     institusional" di balik SMC adalah marketing narrative yang tidak
#     terverifikasi (dikonfirmasi dari analisis kritis AlgoStorm) --
#     yang benar-benar terukur cuma struktur harga (swing point,
#     breakout, gap, candle pattern), bukan fakta institusi tertentu
#     bertransaksi. Setiap respons command ini menyertakan disclaimer
#     ini. Swing detection bersifat "non-repainting" (right_bars candle
#     terakhir tidak akan punya swing point terdeteksi -- butuh
#     konfirmasi candle setelahnya, BUKAN bug). Tersedia juga sebagai
#     tombol di menu kode-saham-langsung (handlers/stock_menu_handlers.py).
# 16. /rr /target /cutloss /positionsize (BARU) -- Risk Management,
#     modul core/risk_management.py. CATATAN KRUSIAL: /positionsize
#     membulatkan hasil KE BAWAH ke kelipatan 1 LOT (100 lembar saham,
#     aturan resmi BEI sejak 2014, dikonfirmasi via riset web) -- bukan
#     ke lembar individual seperti formula umum yang ditulis untuk
#     pasar AS/forex, dan SELALU floor bukan round, supaya risiko
#     sesungguhnya tidak pernah melebihi yang direncanakan user. /target
#     & /cutloss tersedia sebagai tombol menu (cukup butuh kode saham);
#     /rr & /positionsize TIDAK (butuh banyak input angka manual yang
#     tidak bisa diambil otomatis dari kode saham semata).
# 17. /sektor /rotasi /leader /laggard /beta /relative (BARU) -- Sektor
#     & Rotasi, modul core/sector_rotation.py. /sektor & /rotasi
#     memakai 11 indeks sektoral resmi IDX-IC (IDX_SECTORAL_INDICES di
#     core/market.py) -- CATATAN JUJUR: ticker-ticker ini TIDAK BISA
#     dicoba eksekusi langsung di sandbox development (domain
#     finance.yahoo.com tidak ada di allowlist jaringan sandbox, bahkan
#     ^JKSE yang sudah lama dipakai ikut gagal kalau dicoba eksekusi
#     langsung -- SEMUA testing yfinance sepanjang project ini memakai
#     mock, bukan panggilan jaringan sungguhan). Bukti yang dipakai
#     untuk 11 ticker ini bersifat TIDAK LANGSUNG (snapshot harga +
#     halaman riwayat terindeks di Yahoo Finance, dikonfirmasi Juni
#     2026). /leader & /laggard TETAP dibatasi SECTOR_MAP yang cuma 21
#     saham dari 793 total -- setiap respons menyebutkan batasan ini
#     secara jujur. /relative adalah ALIAS untuk /rs (handler yang
#     SAMA, rs_cmd, didaftarkan dua kali dengan nama command berbeda),
#     BUKAN fitur baru -- sesuai daftar awal yang menyebut /RELATIVE
#     sebagai "relative strength vs sektor" yang persis sudah dilakukan
#     /rs. Hanya /beta yang masuk ke tombol menu kode-saham-langsung
#     (yang lain butuh input SEKTOR atau analisis seluruh market, tidak
#     cocok untuk menu per-saham).
# 18. /volumespike /adline (BARU) -- Volume Patterns, modul
#     core/volume_patterns.py. PENGGANTI NAMA & KONSOLIDASI untuk 6
#     command yang awalnya diminta dengan nama institusional
#     (BANDARMOLOGI, SMARTMONEY, BIGMONEY, UNUSUAL, HOTMONEY,
#     ACCUMULATION, DISTRIBUTION) -- setelah dibedah secara teknis,
#     6 nama itu cuma 2 konsep BERBEDA: (a) lonjakan volume vs rata-
#     rata historis (BANDARMOLOGI/BIGMONEY/UNUSUAL/HOTMONEY, beda cuma
#     threshold sensitivitas) -> /volumespike; (b) posisi close dalam
#     range candle dikombinasikan dengan volume, yang TERNYATA sudah
#     punya nama resmi & formula baku sejak lama: Chaikin Accumulation/
#     Distribution Line (ACCUMULATION/DISTRIBUTION bukan dua hal
#     terpisah, tapi dua ujung SATU SPEKTRUM yang sama) -> /adline.
#     SMARTMONEY (candle besar/displacement) DI-SKIP TOTAL karena
#     konsepnya sama dengan Order Block yang SUDAH ADA di /orderblock
#     (core/smc.py) -- membangun lagi sebagai command terpisah cuma
#     menduplikasi fitur dengan nama berbeda. Keduanya menyertakan
#     disclaimer bahwa ini pola harga & volume publik, BUKAN data
#     transaksi institusi/bandar sungguhan. Tersedia sebagai tombol
#     menu (cukup butuh kode saham).
# 19. /toploser /topvalue /heatmap (BARU) -- Market Overview tambahan.
#     /toploser mirror /topgainer (core/market.py: get_top_losers),
#     cuma beda arah sorting. /topvalue (get_top_value) MENGGANTIKAN
#     /TOPFREQ SEPENUHNYA -- data frekuensi transaksi (jumlah order
#     matched) TIDAK ADA di yfinance (dikonfirmasi via riset web,
#     cuma OHLCV standar 5 kolom), tapi nilai transaksi (harga x
#     volume) BISA dihitung, jadi command diganti nama bukan
#     dijadikan dua command terpisah. /heatmap (core/charts/
#     heatmap_chart.py: generate_heatmap_chart) visual grid 11 sektor
#     resmi IDX-IC dengan warna hijau/merah berdasarkan return_pct,
#     memakai get_sector_performance dari core/sector_rotation.py
#     (DIIMPOR DENGAN ALIAS get_sectoral_index_performance di
#     handlers/market_handlers.py -- CATATAN PENTING: nama fungsi ini
#     KEBETULAN SAMA dengan get_sector_performance yang SUDAH ADA di
#     core/market.py untuk /daily, padahal isinya BERBEDA TOTAL
#     [core/market.py = rata-rata 6 kategori SECTOR_MAP ad-hoc;
#     core/sector_rotation.py = 11 indeks sektoral resmi IDX-IC].
#     SENGAJA TIDAK diubah nama fungsi aslinya di kedua modul karena
#     berisiko menyentuh /daily yang sudah berjalan -- alias dipakai
#     cuma di titik pemanggilan untuk menghindari ambiguitas. Ketiga
#     command ini TIDAK masuk tombol menu (analisis seluruh market,
#     bukan per-saham, sama seperti /sektor & /rotasi sebelumnya).
# Catatan: fitur foreign flow (NBSA/investor asing) SENGAJA TIDAK
# diimplementasikan -- data ini tidak ada sumber gratis resmi dari IDX
# (cuma scraping tidak resmi yang dilindungi bot-detection aktif, atau
# API berbayar pihak ketiga). Diputuskan untuk skip demi keandalan.
# 20. Watermark logo "Ranah Saham" (BARU) -- core/charts/watermark.py,
#     diterapkan ke SEMUA chart generator (12 titik di 8 file: advanced_
#     chart, ai_gauge_chart, heatmap_chart, ml_chart, smc_chart x5,
#     snr_chart, trading_plan_chart, ihsg_chart). PENDEKATAN: PIL
#     post-processing SETELAH plt.savefig()+plt.close(fig), BUKAN
#     matplotlib artist sebelum savefig -- percobaan pertama pakai
#     AnnotationBbox ternyata tidak konsisten muncul di chart MULTI-
#     PANEL yang disimpan dengan bbox_inches='tight' (artist figure-
#     level bisa ikut terpotong dari kalkulasi ulang batas figure).
#     PIL post-processing bekerja di atas pixel file PNG yang sudah
#     jadi, jadi hasilnya konsisten apapun struktur layout chart-nya.
#     Logo asli (assets/logo_ranah_saham.png, upload user) di-key-out
#     background putihnya jadi transparan, di-crop ke simbol "RS" saja
#     (tanpa teks "RANAH SAHAM" + tagline, supaya watermark kecil tetap
#     proporsional di pojok chart), disimpan di assets/logo_symbol_
#     only.png. Watermark gagal load/apply TIDAK PERNAH menggagalkan
#     chart (fail-safe try/except, branding adalah bonus bukan syarat).
# 21. /news (BARU) -- core/news.py, RSS feed publik CNBC Indonesia
#     (https://www.cnbcindonesia.com/market/rss/, dikonfirmasi valid &
#     aktif via fetch langsung Juni 2026). /news tanpa argumen = berita
#     market umum terbaru; /news KODE = filter berita yang judul/
#     deskripsinya menyebut kode tersebut (case-insensitive substring
#     match, BUKAN NLP/sentiment analysis -- bot tidak mengklaim bisa
#     menilai nada berita positif/negatif, cuma menyaring berdasarkan
#     kata kunci). Parsing pakai xml.etree.ElementTree (built-in Python,
#     tidak butuh dependency feedparser tambahan). CATATAN JUJUR: RSS
#     feed ini mencampur berita saham sungguhan dengan konten
#     "infotainment finansial" (kisah orang kaya, sejarah, dst) -- filter
#     keyword membantu tapi tidak sempurna. Hanya 1 sumber berita (bukan
#     agregasi multi-portal), keterbatasan scope yang dicatat jujur,
#     bukan diklaim sebagai sumber berita terlengkap.
# 22. /compare REDESIGN (Juni 2026) -- pindah dari handlers/trading_
#     plan_handlers.py (tercampur dengan handler tidak terkait) ke file
#     sendiri handlers/compare_handlers.py. Scoring lama (0-4, 4 kondisi
#     sederhana, tanpa visual) diganti total: REUSE calculate_ai_score_
#     from_df() dari core/ai_score.py (supaya /compare KONSISTEN dengan
#     /aiscore -- skor sama persis kalau user cek masing-masing saham
#     terpisah), DITAMBAH relative performance ANTAR DUA SAHAM langsung
#     (calculate_relative_performance(), BUKAN vs IHSG -- siapa
#     outperform siapa dalam periode tertentu), DITAMBAH chart visual
#     baru (core/charts/compare_chart.py): panel atas garis return
#     TERNORMALISASI (% dari harga awal window, BUKAN harga absolut --
#     supaya 2 saham beda skala harga drastis, mis. BBCA Rp5000-an vs
#     GOTO Rp70-an, tetap bisa dibandingkan visual secara adil di sumbu
#     Y yang sama), panel bawah bar chart AI Score/RSI/Volume Ratio
#     side-by-side. Legend chart pakai loc='best' (bukan posisi tetap)
#     supaya matplotlib otomatis hindari menutupi garis data, ditemukan
#     perlu setelah testing visual menunjukkan posisi tetap kadang
#     tumpang tindih dengan data tergantung pola pergerakan harga.
# 23. /fundamental (BARU) -- core/fundamental.py, gap fitur paling besar
#     yang ditemukan dibanding kompetitor (Stockbit, RTI Business) --
#     project ini sebelumnya 100% teknikal, NOL data fundamental. REUSE
#     async_ticker_info() yang SUDAH ADA (core/async_yf.py, sudah
#     dipakai field marketCap di core/screener.py untuk BSJP screener
#     SEBELUM fitur ini dibangun -- bukan integrasi API baru). BUKTI:
#     (1) marketCap sudah jalan di produksi, (2) ditemukan contoh
#     implementasi pihak ketiga (mcp-idx di GitHub) yang pakai field
#     trailingPE/forwardPE/priceToBook/income_stmt/balance_sheet/
#     cash_flow untuk SAHAM IDX SPESIFIK, dikonfirmasi Juni 2026, (3)
#     halaman Yahoo Finance individual ticker .JK terkonfirmasi punya
#     data lengkap. TIDAK BISA dicoba eksekusi langsung dari sandbox
#     (pola yang sama dengan keterbatasan verifikasi yfinance di seluruh
#     project ini). CATATAN JUJUR PALING PENTING: field dividendYield,
#     returnOnEquity, debtToEquity TIDAK punya dokumentasi resmi yang
#     jelas soal unit (desimal 0.025 vs sudah-persen 2.5) -- masalah
#     yang dikenal luas di komunitas yfinance. Dipakai HEURISTIK
#     (_normalize_percent_field di core/fundamental.py: kalau raw value
#     <= 1 asumsi desimal dikali 100, kalau > 1 asumsi sudah persen) --
#     BUKAN kepastian, dan SETIAP pesan ke user menyertakan disclaimer
#     eksplisit untuk cross-check ke laporan keuangan resmi. CACHING:
#     tabel fundamental_cache baru di core/database.py, max_age 7 hari
#     (data fundamental berubah lambat per kuartal, beda dari data
#     harga yang perlu fresh tiap hari -- .info juga jauh lebih berat
#     & rawan rate-limit dibanding .download() OHLCV biasa).
# 24. /insight (BARU) -- core/insight.py, merangkai AI Score (teknikal)
#     + fundamental + berita jadi satu narasi paragraf yang enak dibaca,
#     bukan daftar angka. KEPUTUSAN ARSITEKTUR EKSPLISIT user: RULE-
#     BASED (template kondisional), BUKAN LLM -- demi menghindari biaya
#     API berbayar. Setiap "kalimat" dipilih dari variasi berdasarkan
#     kondisi data (skor AI, RSI oversold/overbought, ROE tinggi/rendah,
#     dst), disambung jadi paragraf -- BUKAN AI generatif sungguhan.
#     CATATAN KRUSIAL SOAL BAHASA (terkait diskusi regulasi OJK
#     finfluencer): narasi SENGAJA memakai bahasa DESKRIPTIF ("data
#     menunjukkan", "RSI berada di zona X") BUKAN PRESKRIPTIF
#     ("sebaiknya beli", "rekomendasi kami") -- lebih krusial di sini
#     dibanding command lain karena /insight menghasilkan PROSA BEBAS
#     yang lebih mudah "tergelincir" ke bahasa rekomendasi investasi
#     dibanding tampilan angka terstruktur. Disclaimer SELALU tampil,
#     tidak bisa di-skip. _narrate_synthesis() secara eksplisit
#     menyoroti KESELARASAN ATAU KONFLIK antara sinyal teknikal &
#     fundamental, bukan kesimpulan beli/jual.
#
#     BUG NYATA DITEMUKAN & DIPERBAIKI SAAT MEMBANGUN FITUR INI:
#     judul berita (RSS feed) dan nama perusahaan (Yahoo Finance) adalah
#     teks dari SUMBER EKSTERNAL yang TIDAK DIKONTROL bot ini -- bisa
#     mengandung underscore/asterisk yang men-trigger BUG MARKDOWN YANG
#     SAMA seperti kasus /ihsg sebelumnya (fib_position & nama
#     candlestick pattern). Ditemukan SAAT membangun /insight karena
#     judul berita dirangkai jadi kalimat narasi bebas, BUKAN cuma
#     ditampilkan apa adanya -- risikonya jadi lebih jelas terlihat.
#     DIPERBAIKI SECARA MENYELURUH (bukan cuma di /insight): fungsi baru
#     sanitize_for_markdown() di core/messages.py, diterapkan RETROAKTIF
#     ke /news (judul & ringkasan berita) dan /fundamental (nama
#     perusahaan/sektor/industri) JUGA -- keduanya punya bug laten yang
#     sama, belum sempat ketahuan sebelum sesi ini. Pendekatan: ganti
#     karakter spesial Markdown dengan karakter visual aman (BUKAN
#     escape backslash -- Telegram parse_mode='Markdown' lama tidak
#     mendukung escape secara konsisten, beda dengan MarkdownV2).
# 25. /insight REVISI (Juni 2026) -- komponen FUNDAMENTAL diganti TOTAL
#     dengan KONTEKS IHSG, atas permintaan eksplisit user dengan alasan
#     yang masuk akal: arah pergerakan saham individual SANGAT
#     dipengaruhi arah IHSG (sentimen pasar keseluruhan), dan data
#     fundamental dari yfinance punya ketidakpastian unit yang sudah
#     diakui jujur (dividendYield/ROE/DER, lihat core/fundamental.py).
#     REUSE infrastruktur yang SUDAH ADA & TERUJI: calculate_ai_score_
#     from_df() dipanggil DUA KALI (sekali untuk saham, sekali untuk
#     IHSG itu sendiri -- IHSG cuma diperlakukan sebagai "saham" untuk
#     keperluan skoring teknikal ini, elegan karena cuma data OHLCV
#     biasa), DAN calculate_relative_strength() dari core/relative_
#     strength.py (logic identik yang SUDAH dipakai /rs, period_days=20
#     konsisten dengan default /rs) untuk angka kuantitatif outperform/
#     underperform vs IHSG. _narrate_synthesis() sekarang membandingkan
#     skor teknikal saham vs skor teknikal IHSG (5 kasus: searah
#     bullish, searah bearish, saham kuat di tengah IHSG lemah/sebaliknya
#     [keduanya ditandai "Menarik" -- mengindikasikan faktor SPESIFIK
#     saham, bukan sekadar imbas pasar], atau keduanya netral). ai_ihsg
#     & rs_data BISA None (IHSG gagal diambil) -- generate_insight()
#     TETAP menghasilkan narasi masuk akal tanpa konteks pasar, BUKAN
#     crash. /fundamental TETAP ADA sebagai command standalone terpisah
#     (diverifikasi via regression test masih utuh) -- cuma TIDAK LAGI
#     dipakai di alur /insight.
# 26. /insight REVISI KEDUA (Juni 2026) -- user menunjukkan contoh
#     laporan analisis trading multi-agent (gaya "TradingAgents": 4
#     analis spesialis + debat Bull/Bear + debat Risk Management +
#     keputusan Portfolio Manager). DIJELASKAN bahwa level laporan itu
#     butuh LLM beneran (penalaran dinamis merespons argumen lawan,
#     mis. "ATR tinggi juga berarti harga bisa naik drastis" -- BUKAN
#     sesuatu yang bisa ditiru template kondisional). KEPUTUSAN
#     EKSPLISIT user: TETAP RULE-BASED & GRATIS, perkaya template yang
#     ada. Perkayaan yang dilakukan:
#     (a) calculate_ai_score_from_df() (core/ai_score.py) di-extend
#         dengan field BARU yang SEBENARNYA SUDAH DIHITUNG internal
#         untuk skoring tapi belum di-expose: macd_hist, macd_bullish,
#         bb_position, ma20/ma50/ma200, atr_pct (BARU, import
#         calculate_atr), bullish_count/bearish_count/netral_count
#         (confluence count eksplisit, mirip gaya "5 Bearish/1
#         Bullish/2 Netral" di contoh user TAPI dihitung dari kondisi
#         data asli), DAN ma_detail/macd_detail/rsi_detail/vol_detail/
#         bb_detail/stoch_detail (detail string yang SAMA PERSIS dipakai
#         untuk klasifikasi reasons/confluence -- SATU SUMBER KEBENARAN,
#         supaya narasi /insight TIDAK PERNAH kontradiksi dengan angka
#         konfluensi yang ditampilkan, BUG NYATA yang ditemukan &
#         diperbaiki saat development: versi awal _narrate_technical
#         re-derive perbandingan "price>MA50>MA200" sendiri secara
#         terpisah dari ma_score, menghasilkan narasi yang BISA bilang
#         "selaras bullish" padahal confluence count cuma 1 bullish
#         dari 6 -- diperbaiki dengan memakai ma_detail dkk langsung).
#         PURE ADDITION ke return dict, tidak mengubah field lama,
#         diverifikasi via regression test /aiscore & /compare masih
#         utuh. Bonus: ditemukan & diperbaiki bug akurasi kecil yang
#         SUDAH ADA sebelumnya (bb_position>=100 = breakout sungguhan
#         dilabeli "Mendekati BB upper" yang menyesatkan -- sekarang
#         dipisah jadi label "Breakout di atas BB upper" tersendiri).
#     (b) /insight IHSG (atau /insight tanpa argumen, BARU) -- insight
#         market-wide TERPISAH dari insight per-saham (handlers/
#         insight_handlers.py: _run_market_insight vs _run_stock_insight,
#         routing di insight_cmd berdasarkan keyword "IHSG"/"JKSE" --
#         pola SAMA dengan alias yang sudah ada di /correlation).
#         generate_market_insight() (core/insight.py): TIDAK ADA
#         perbandingan "vs IHSG" (membandingkan IHSG dengan dirinya
#         sendiri tidak masuk akal), diganti narasi ROTASI SEKTOR
#         (REUSE get_sector_performance() dari core/sector_rotation.py,
#         logic SAMA dipakai /sektor) + breadth analysis (apakah
#         pergerakan IHSG didukung mayoritas sektor/broad-based, atau
#         segelintir saja/narrow -- distingsi teknis sungguhan).
#         Action handler menu (handlers/stock_menu_handlers.py)
#         DIREFACTOR untuk reuse _run_stock_insight() langsung (passing
#         "query" sebagai pengganti "update" -- aman karena
#         query.message punya interface .reply_text() yang identik),
#         menghilangkan duplikasi logic yang sebelumnya ada di sana.
# 27. /ranah, /aiscore, /airank REVISI (Juni 2026) -- permintaan
#     eksplisit user: "/ranah jangan pakai /signal, pakai metode yang
#     lebih akurat dan ada jurnalnya". TEMUAN PENTING saat investigasi:
#     result['score'] SUDAH SEJAK LAMA dihitung pakai calculate_ai_
#     score_from_df() (sistem 6-dimensi berbasis riset jurnal, lihat
#     sitasi lengkap di core/ai_score.py) -- MASALAHNYA tampilan pesan
#     MASIH membingkai semuanya seolah pakai "/signal + Stochastic" (4
#     kondisi sederhana lama: MA cross, volume spike 1.2x, harga>200,
#     volume>500rb), framing teks yang MENYESATKAN karena BUKAN
#     metodologi yang sungguhan dipakai menghitung skor.
#
#     BUG NYATA LEBIH SERIUS ditemukan di aiscore_cmd (breakdown):
#     breakdown yang ditampilkan ke user dihitung ULANG secara TERPISAH
#     dengan bobot LAMA (ma_score=25 if cond_ma else 10, dkk) yang SAMA
#     SEKALI BEDA dari bobot SUNGGUHAN yang dipakai result['score'] --
#     breakdown yang ditampilkan TIDAK PERNAH benar-benar menjumlah ke
#     skor yang ditampilkan ke user. DIPERBAIKI dengan expose komponen
#     skor ASLI di core/ai_score.py (macd_rsi_score, ma_trend_score,
#     volume_score, bollinger_score, stochrsi_score, momentum_score --
#     PURE ADDITION, sudah dihitung internal, cuma belum di-expose).
#     Breakdown sekarang DIJAMIN menjumlah persis ke score, DIVERIFIKASI
#     via test multi-seed (4 seed berbeda, semua cocok).
#
#     BUG NYATA KEDUA ditemukan & diperbaiki: tombol menu "AI RANKING"
#     punya callback_data "airank_menu" (DENGAN underscore) -- tapi
#     parsing `data.split("_", 1)` didesain untuk pola "action_ticker"
#     (SATU underscore pemisah), jadi "airank_menu".split("_", 1)
#     menghasilkan action="airank" (BUKAN "airank_menu")! Kondisi
#     `elif action == "airank_menu"` TIDAK PERNAH match -- tombol ini
#     SUDAH LAMA TIDAK BERFUNGSI (silent no-op, klik tombolnya tidak
#     melakukan apapun). DIPERBAIKI: callback_data diganti jadi
#     "airankmenu" (TANPA underscore), menghilangkan ambiguitas parsing.
#     Diaudit seluruh file untuk pola serupa -- ini SATU-SATUNYA
#     callback_data statis (non-f-string) yang kena masalah ini,
#     tombol lain aman karena action name-nya tidak pernah mengandung
#     underscore sebelum {stock} disisipkan.
#
#     Ketiga handler (ranah_cmd, aiscore_cmd, airank_cmd) DITULIS ULANG
#     menghapus semua referensi "/signal" yang menyesatkan, ditambah
#     sitasi riset eksplisit (METHODOLOGY_CITATIONS) di setiap pesan.
#     Action menu yang sebelumnya PUNYA SALINAN logic sendiri (termasuk
#     bug "/signal" framing & breakdown palsu yang SAMA) DIREFACTOR jadi
#     memanggil helper bersama (_run_ranah_analysis, _run_aiscore_
#     breakdown, dan airank_cmd langsung untuk ranking) -- pola SAMA
#     dengan refactor /insight sebelumnya (query.message kompatibel
#     dengan update.message), menghilangkan duplikasi logic sepenuhnya.
# 28. BUG FIX dari laporan user (Juni 2026) -- traceback nyata: /airank
#     gagal dengan "Gagal menghitung ranking" TANPA penjelasan, DAN
#     query.answer() di stock_menu_callback() sempat TimedOut (httpx.
#     ConnectTimeout -> telegram.error.TimedOut) yang menggagalkan
#     SELURUH handler sebelum sempat melakukan apapun. DUA PERBAIKAN
#     TERPISAH:
#     (a) async_download_many() (core/async_yf.py) SEBELUMNYA TIDAK
#         PUNYA RETRY SAMA SEKALI -- batch yang gagal/kosong langsung
#         dilewati. Untuk /airank (200 ticker / 5 batch @ 40), kalau
#         Yahoo Finance lagi rate-limit, SEMUA batch bisa gagal beruntun
#         dan hasil akhirnya KOSONG TOTAL (persis yang dialami user).
#         DITAMBAHKAN retry PER BATCH (bukan per-ticker individual --
#         1 batch = 1 panggilan API untuk puluhan ticker, retry per-
#         ticker untuk 200 ticker akan terlalu lambat) dengan backoff,
#         max 3 percobaan, konsisten dengan pola _download_with_retry
#         yang sudah dipakai core/sector_rotation.py & handlers/
#         ihsg_handlers.py untuk masalah yang SAMA PERSIS. DIVERIFIKASI
#         via test: (1) sukses langsung -- behavior lama tidak berubah,
#         1 panggilan saja, (2) gagal 2x lalu sukses -- retry berhasil
#         dapat data, (3) gagal total -- degradasi graceful (dict
#         kosong, BUKAN crash). Pesan error airank_cmd JUGA diperbaiki
#         supaya menjelaskan kemungkinan penyebab (rate-limit) & saran
#         tunggu 1-2 menit, bukan cuma "Coba lagi nanti" tanpa konteks.
#     (b) query.answer() di stock_menu_callback() (handlers/stock_menu_
#         handlers.py) SEBELUMNYA TIDAK dibungkus try/except -- padahal
#         ini CUMA acknowledgment UI (menghilangkan loading spinner di
#         tombol Telegram), BUKAN bagian esensial dari fungsi tombol.
#         Kalau koneksi user ke server Telegram lagi tidak stabil,
#         SELURUH handler crash di baris paling awal SEBELUM sempat
#         memproses tombol sama sekali -- user dapat pesan error generic
#         tanpa tahu kenapa, padahal aksi tombolnya sendiri (mis. AI
#         Ranking) belum sempat dicoba. DIBUNGKUS try/except: kalau
#         answer() gagal, tetap lanjut proses tombol seperti biasa --
#         efek samping PALING BURUK cuma spinner tombol sedikit lebih
#         lama, BUKAN seluruh aksi gagal. DIVERIFIKASI via test: handler
#         tetap mengirim chart & pesan lengkap meski answer() di-mock
#         untuk raise exception persis seperti traceback asli user.
# 29. send_evening_summary() DIROMBAK TOTAL (Juni 2026, permintaan
#     eksplisit user: "bikin lebih canggih lagi, harus canggih banget
#     atau bagus banget"). BUG NYATA ditemukan di versi lama: bagian
#     "Support/Resistance" BUKAN kalkulasi sungguhan -- cuma current_
#     price*0.98 / *1.02 (flat 2% offset), padahal project ini SUDAH
#     PUNYA engine S/R asli (analyze_ihsg_with_backtest, SAMA yang
#     dipakai /ihsg). Watchlist section juga cuma pointer teks statis
#     ("Gunakan /rekapwl"), BUKAN data personal sungguhan.
#
#     SEKARANG menggabungkan SEMUA engine terbaik yang sudah dibangun
#     project ini jadi SATU laporan: (1) IHSG advanced analysis + chart
#     -- engine SAMA dengan /ihsg (S/R asli dari cluster pivot, prediksi
#     dengan confidence, backtest win_rate tervalidasi historis -- BUKAN
#     rumus arbitrer), (2) rotasi sektor harian -- REUSE get_sector_
#     performance() (core/sector_rotation.py, logic SAMA /sektor &
#     /insight IHSG), (3) AI Score movers Top 5 -- REUSE calculate_ai_
#     score_from_df() (engine SAMA /airank, BARU diuntungkan retry-
#     per-batch dari perbaikan poin 28 di atas), (4) berita terkini --
#     REUSE fetch_news(), (5) watchlist PERSONAL SUNGGUHAN per-user
#     (performa tiap saham sejak ditambahkan, BUKAN cuma pointer teks).
#
#     ARSITEKTUR EFISIENSI (konsisten pola check_watchlist_alerts()):
#     SEMUA komponen market-wide (poin 1-4) dihitung SEKALI untuk SEMUA
#     subscriber, BUKAN per-user -- DIVERIFIKASI via test: IHSG cuma
#     didownload 3x total (daily+weekly+longer-history) untuk SEMENTARA
#     2 user berlangganan, BUKAN 3x2=6x. Watchlist (poin 5) JUGA
#     dikumpulkan dulu SEMUA ticker dari SEMUA user, didownload SEKALI
#     paralel, baru di-render personal per-user dari data yang sudah
#     ada di memory -- DIVERIFIKASI via test 2 user dengan watchlist
#     berbeda: masing-masing CUMA lihat saham mereka sendiri (tidak ada
#     cross-contamination). Setiap komponen dibungkus try/except
#     SENDIRI-SENDIRI -- 1 komponen gagal (mis. rate-limit) TIDAK
#     menggagalkan komponen lain, beda dari versi lama yang try/except
#     di level fungsi (1 kegagalan apapun = SELURUH report gagal).
#
#     BUG DITEMUKAN & DIPERBAIKI SAAT TESTING: asumsi awal field
#     backtest_result pakai key 'total_occurrences' -- SALAH, field
#     asli dari backtest_condition() (core/backtest.py) adalah 'n'.
#     Ditemukan lewat test integrasi end-to-end (KeyError), bukan lewat
#     asumsi -- diperbaiki sebelum dikirim ke user.
#
#     Pesan evening report sekarang BISA melebihi 4096 karakter (limit
#     Telegram) -- fungsi _split_for_telegram() BARU ditambahkan untuk
#     memecah pesan per baris (tidak memutus kalimat di tengah).
# 30. /news DIPERLUAS jadi multi-sumber (Juni 2026, permintaan eksplisit
#     user: "bisa lebih luas lagi ga ambil beritanya"). SEBELUMNYA cuma
#     1 sumber (CNBC Indonesia Market). SEKARANG agregasi 3 RSS feed,
#     MASING-MASING DIVERIFIKASI aktif via fetch langsung sebelum
#     diintegrasikan (bukan asumsi dari listing aggregator pihak
#     ketiga): CNBC Indonesia Market, CNN Indonesia Ekonomi, Detik
#     Finance. KANDIDAT YANG DICOBA TAPI DITOLAK: Kontan.co.id
#     (rss.kontan.co.id) -- diblokir bot detection saat verifikasi
#     langsung, indikasi subdomain RSS-nya rusak/tidak dikelola lagi
#     (halaman default Apache, bukan SSL) -- TIDAK dipaksakan masuk
#     meski sering muncul di daftar aggregator RSS lain.
#
#     ARSITEKTUR: SEMUA sumber di-fetch PARALEL (asyncio.gather), MASING
#     -MASING dibungkus try/except sendiri -- 1-2 sumber gagal TIDAK
#     menggagalkan yang lain (semantik None vs [] dipertahankan: None
#     HANYA kalau SEMUA sumber gagal total, list kosong kalau semua
#     sumber berhasil tapi tidak ada yang cocok keyword -- DIVERIFIKASI
#     eksplisit via test partial-failure & total-failure). Hasil
#     gabungan diurutkan ULANG berdasarkan tanggal publikasi SUNGGUHAN
#     (parse RFC 822 pubDate via email.utils.parsedate_to_datetime,
#     BUKAN cuma urutan asli per-feed) supaya berita TERBARU lintas
#     SEMUA sumber tampil duluan, bukan terkelompok per portal --
#     DIVERIFIKASI via test 3-sumber: urutan akhir 17:30 > 15:00 > 12:00
#     > 10:00 lintas CNN/CNBC/Detik, bukan dikelompokkan per sumber.
#
#     BUG NYATA ditemukan & diperbaiki SAAT development (sebelum
#     sempat ke production): sort key awal mencampur datetime timezone
#     -aware (hasil parsedate_to_datetime dengan offset, mis. "+0700")
#     dengan datetime.min yang naive sebagai fallback untuk item tanpa
#     tanggal -- Python akan CRASH (TypeError) saat membandingkan
#     keduanya dalam satu sort(). DIPERBAIKI: _parse_pub_date() SELALU
#     menormalisasi hasil jadi timezone-aware (assume UTC kalau parsing
#     menghasilkan naive), sentinel fallback JUGA dibuat UTC-aware,
#     sehingga SEMUA sort key konsisten comparable.
#
#     format_news_message() (handlers/news_handlers.py) & evening
#     report (jobs/notification_jobs.py) DIPERBARUI menampilkan
#     atribusi sumber per-item (mis. "(CNBC Indonesia)") -- transparansi
#     supaya user tahu berita itu dari portal mana, BUKAN cuma satu
#     baris generik "Sumber: CNBC Indonesia" seperti versi lama (yang
#     sekarang MENYESATKAN karena ada 3 sumber, bukan 1). fetch_news()
#     SIGNATURE TIDAK BERUBAH (keyword, limit) -- SEMUA caller existing
#     (/news command, menu action, evening report, /insight) otomatis
#     dapat manfaat multi-sumber TANPA perlu modifikasi kode pemanggil,
#     diverifikasi via regression test ketiganya.

import logging
from datetime import time as dtime

from telegram import Update
from telegram.ext import (
    ApplicationBuilder, CommandHandler, MessageHandler,
    CallbackQueryHandler, ContextTypes, filters,
)

from core.config import BOT_TOKEN
from core.database import init_database

# ---- Handlers ----
from handlers.base_handlers import start_cmd, help_cmd, id_cmd, signal_cmd, bsjp_cmd
from handlers.howto_handler import howto_cmd
from handlers.trading_plan_handlers import (
    plan_cmd, bsjp_plan_cmd, bsjp_top_plan_cmd,
)
from handlers.compare_handlers import compare_cmd
from handlers.chart_handlers import snr_cmd, ml_cmd, ta_cmd, advanced_chart_cmd, signals_chart_cmd
from handlers.watchlist_handlers import (
    watchlist_cmd, wlstatus_cmd, checkalerts_cmd, rekap_watchlist_cmd,
    subscribe_cmd, unsubscribe_cmd,
)
from handlers.market_handlers import (
    filter_cmd, daily_cmd, topgainer_cmd, topvolume_cmd, hotstock_cmd,
    alert_cmd, myalerts_cmd, removealert_cmd, toploser_cmd, topvalue_cmd, heatmap_cmd,
)
from handlers.ihsg_handlers import ihsg_advanced_cmd
from handlers.ai_score_handlers import ranah_cmd, aiscore_cmd, airank_cmd
from handlers.report_handlers import laporan_cmd
from handlers.stock_signal_handlers import stocksignal_cmd, topsignal_cmd
from handlers.stock_menu_handlers import stock_direct_handler, stock_menu_callback
from handlers.backtest_handlers import backtest_cmd
from handlers.relative_strength_handlers import rs_cmd
from handlers.smc_handlers import bos_cmd, choch_cmd, orderblock_cmd, fvg_cmd, liquidity_cmd
from handlers.risk_handlers import rr_cmd, target_cmd, cutloss_cmd, positionsize_cmd
from handlers.sector_rotation_handlers import beta_cmd, sektor_cmd, rotasi_cmd, leader_cmd, laggard_cmd
from handlers.volume_pattern_handlers import volumespike_cmd, adline_cmd
from handlers.screening_pro_handlers import (
    screenerpro_cmd, multitimeframe_cmd, patternscan_cmd,
    correlation_cmd, confluence_cmd, backtestpro_cmd,
)
from handlers.news_handlers import news_cmd
from handlers.fundamental_handlers import fundamental_cmd
from handlers.insight_handlers import insight_cmd

# ---- Jobs ----
from jobs.notification_jobs import (
    check_watchlist_alerts, check_price_alerts, send_morning_summary, send_evening_summary,
    send_watchlist_news_digest,
)

logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO,
)
logger = logging.getLogger(__name__)


async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Global error handler. TIDAK ADA SAMA SEKALI di main.py lama --
    artinya exception tak tertangani di handler manapun (misalnya
    KeyError, IndexError dari data yfinance yang tidak terduga) akan
    membuat user tidak mendapat respons apapun, dan error hanya muncul
    di traceback console tanpa konteks update yang jelas.

    Sekarang: error di-log dengan konteks update, dan kalau update
    punya effective_message, user diberi tahu secara graceful bukan
    dibiarkan menunggu tanpa respons."""
    logger.error("Exception saat menangani update:", exc_info=context.error)

    if isinstance(update, Update) and update.effective_message:
        try:
            await update.effective_message.reply_text(
                "⚠️ Terjadi kesalahan saat memproses permintaan Anda. "
                "Silakan coba lagi atau gunakan /help untuk bantuan."
            )
        except Exception:
            pass  # kalau reply pun gagal, sudah ter-log di atas


def main():
    init_database()
    logger.info("✅ SQLite database ready!")

    # Timeout global dinaikkan dari default PTB (~20s) supaya upload file
    # besar (PDF laporan dengan banyak chart, gambar chart) tidak gampang
    # "Timed out" di koneksi lambat. Per-call timeout di reply_document
    # tetap ada sebagai lapisan tambahan untuk file yang paling berat.
    app = (
        ApplicationBuilder()
        .token(BOT_TOKEN)
        .read_timeout(60)
        .write_timeout(120)
        .connect_timeout(30)
        .pool_timeout(30)
        .build()
    )

    # ---- Basic ----
    app.add_handler(CommandHandler("start", start_cmd))
    app.add_handler(CommandHandler("help", help_cmd))
    app.add_handler(CommandHandler("id", id_cmd))
    app.add_handler(CommandHandler("howto", howto_cmd))

    # ---- Signal & Screener ----
    app.add_handler(CommandHandler("signal", signal_cmd))
    app.add_handler(CommandHandler("bsjp", bsjp_cmd))
    app.add_handler(CommandHandler("bsjpplan", bsjp_plan_cmd))
    app.add_handler(CommandHandler("bsjptop", bsjp_top_plan_cmd))
    app.add_handler(CommandHandler("stocksignal", stocksignal_cmd))
    app.add_handler(CommandHandler("topsignal", topsignal_cmd))

    # ---- Filter ----
    app.add_handler(CommandHandler("filter", filter_cmd))

    # ---- Watchlist ----
    app.add_handler(CommandHandler("watchlist", watchlist_cmd))
    app.add_handler(CommandHandler("rekapwl", rekap_watchlist_cmd))
    app.add_handler(CommandHandler("wlstatus", wlstatus_cmd))
    app.add_handler(CommandHandler("checkalerts", checkalerts_cmd))

    # ---- Alert (sekarang benar-benar fungsional, lihat catatan di
    #      handlers/market_handlers.py) ----
    app.add_handler(CommandHandler("alert", alert_cmd))
    app.add_handler(CommandHandler("myalerts", myalerts_cmd))
    app.add_handler(CommandHandler("removealert", removealert_cmd))

    # ---- Compare ----
    app.add_handler(CommandHandler("compare", compare_cmd))

    # ---- Market Reports ----
    app.add_handler(CommandHandler("daily", daily_cmd))
    app.add_handler(CommandHandler("topgainer", topgainer_cmd))
    app.add_handler(CommandHandler("topvolume", topvolume_cmd))
    app.add_handler(CommandHandler("toploser", toploser_cmd))
    app.add_handler(CommandHandler("topvalue", topvalue_cmd))
    app.add_handler(CommandHandler("heatmap", heatmap_cmd))
    app.add_handler(CommandHandler("hotstock", hotstock_cmd))

    # ---- Trading Plan ----
    app.add_handler(CommandHandler("plan", plan_cmd))

    # ---- Technical Analysis ----
    app.add_handler(CommandHandler("snr", snr_cmd))
    app.add_handler(CommandHandler("ml", ml_cmd))
    app.add_handler(CommandHandler("ta", ta_cmd))
    app.add_handler(CommandHandler("ihsg", ihsg_advanced_cmd))

    # ---- Charts ----
    app.add_handler(CommandHandler("chart", advanced_chart_cmd))
    app.add_handler(CommandHandler("signals", signals_chart_cmd))

    # ---- Subscription ----
    app.add_handler(CommandHandler("subscribe", subscribe_cmd))
    app.add_handler(CommandHandler("unsubscribe", unsubscribe_cmd))

    # ---- RANAH AI ANALYZER ----
    app.add_handler(CommandHandler("ranah", ranah_cmd))
    app.add_handler(CommandHandler("aiscore", aiscore_cmd))
    app.add_handler(CommandHandler("airank", airank_cmd))
    app.add_handler(CommandHandler("laporan", laporan_cmd))

    # ---- ANALISIS LANJUTAN (BARU) ----
    app.add_handler(CommandHandler("backtest", backtest_cmd))
    app.add_handler(CommandHandler("rs", rs_cmd))

    # ---- MARKET STRUCTURE / SMART MONEY CONCEPTS (BARU) ----
    app.add_handler(CommandHandler("bos", bos_cmd))
    app.add_handler(CommandHandler("choch", choch_cmd))
    app.add_handler(CommandHandler("orderblock", orderblock_cmd))
    app.add_handler(CommandHandler("fvg", fvg_cmd))
    app.add_handler(CommandHandler("liquidity", liquidity_cmd))

    # ---- RISK MANAGEMENT (BARU) ----
    app.add_handler(CommandHandler("rr", rr_cmd))
    app.add_handler(CommandHandler("target", target_cmd))
    app.add_handler(CommandHandler("cutloss", cutloss_cmd))
    app.add_handler(CommandHandler("positionsize", positionsize_cmd))

    # ---- SEKTOR & ROTASI (BARU) ----
    app.add_handler(CommandHandler("beta", beta_cmd))
    app.add_handler(CommandHandler("sektor", sektor_cmd))
    app.add_handler(CommandHandler("rotasi", rotasi_cmd))
    app.add_handler(CommandHandler("leader", leader_cmd))
    app.add_handler(CommandHandler("laggard", laggard_cmd))
    app.add_handler(CommandHandler("relative", rs_cmd))  # alias /rs, lihat catatan di handlers/sector_rotation_handlers.py

    # ---- VOLUME PATTERNS (BARU, lihat catatan penamaan ulang di core/volume_patterns.py) ----
    app.add_handler(CommandHandler("volumespike", volumespike_cmd))
    app.add_handler(CommandHandler("adline", adline_cmd))

    # ---- SCREENING PREMIUM (BARU) ----
    app.add_handler(CommandHandler("screenerpro", screenerpro_cmd))
    app.add_handler(CommandHandler("multitimeframe", multitimeframe_cmd))
    app.add_handler(CommandHandler("patternscan", patternscan_cmd))
    app.add_handler(CommandHandler("correlation", correlation_cmd))
    app.add_handler(CommandHandler("confluence", confluence_cmd))
    app.add_handler(CommandHandler("backtestpro", backtestpro_cmd))

    # ---- NEWS (BARU) ----
    app.add_handler(CommandHandler("news", news_cmd))

    # ---- FUNDAMENTAL (BARU) ----
    app.add_handler(CommandHandler("fundamental", fundamental_cmd))

    # ---- INSIGHT (BARU) ----
    app.add_handler(CommandHandler("insight", insight_cmd))

    # ---- FITUR KETIK LANGSUNG KODE SAHAM + TOMBOL MENU ----
    # (Dulu stock_menu_callback didefinisikan 2x di main.py lama --
    # sudah dikonsolidasikan jadi satu di handlers/stock_menu_handlers.py)
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, stock_direct_handler))
    app.add_handler(CallbackQueryHandler(stock_menu_callback))

    # ---- Global error handler (TIDAK ADA di main.py lama) ----
    app.add_error_handler(error_handler)

    # =========================
    # AUTO NOTIFICATION JOBS
    # =========================
    job_queue = app.job_queue

    if job_queue:
        # Check watchlist alerts setiap jam
        job_queue.run_repeating(check_watchlist_alerts, interval=3600, first=60)

        # Check price alerts (dari /alert) setiap jam juga -- BARU, dulu
        # tidak ada job ini sama sekali karena /alert memang fitur palsu
        job_queue.run_repeating(check_price_alerts, interval=3600, first=90)

        # Morning summary (08:30 WIB = 01:30 UTC)
        job_queue.run_daily(send_morning_summary, time=dtime(hour=1, minute=30))

        # Evening summary (16:30 WIB = 09:30 UTC)
        job_queue.run_daily(send_evening_summary, time=dtime(hour=9, minute=30))

        # Watchlist news + sinyal digest (BARU) -- 12:00 WIB = 05:00 UTC,
        # slot siang sendiri supaya tidak menumpuk dengan morning/evening.
        # Mengirim HANYA ke user yang punya berita menyentuh watchlistnya
        # hari itu (user tanpa berita relevan tidak dispam).
        job_queue.run_daily(send_watchlist_news_digest, time=dtime(hour=5, minute=0))

        logger.info("✅ Auto-notification jobs scheduled!")
    else:
        logger.warning("⚠️ Job queue tidak tersedia.")

    logger.info("🤖 Bot started! Polling...")
    app.run_polling(drop_pending_updates=True)


if __name__ == "__main__":
    main()
