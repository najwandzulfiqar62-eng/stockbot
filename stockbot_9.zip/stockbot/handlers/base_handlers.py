# =========================
# HANDLERS: DASAR & SCREENING
# =========================
# PERUBAHAN KRUSIAL dari main.py lama: signal_cmd dan bsjp_cmd dulu
# memanggil run_screener()/run_bsjp_screener() yang SINKRON (memanggil
# yf.download secara blocking di dalam loop ratusan ticker), langsung di
# dalam handler async TANPA executor. Ini artinya seluruh bot freeze
# untuk SEMUA user selama screening berjalan (bisa puluhan detik untuk
# ratusan ticker).
#
# Sekarang run_screener()/run_bsjp_screener() sendiri sudah jadi async
# function yang memakai async_download_many() (lihat core/screener.py),
# jadi tinggal di-await langsung di sini -- otomatis non-blocking karena
# I/O-nya sudah dipindah ke thread terpisah di level lebih dalam.

from core.database import save_user_to_db
from core.stock_data import load_tickers
from core.screener import run_screener, run_bsjp_screener
from core.messages import (
    OPENING, HELP_TEXT, DISCLAIMER,
    format_screener_results, format_bsjp_screener_results,
)

# Dibatasi ke 200 ticker pertama (lihat catatan performa di core/screener.py)
SCREENING_TICKER_LIMIT = 200


async def start_cmd(update, context):
    user_id = str(update.effective_user.id)
    username = update.effective_user.username or ""
    save_user_to_db(user_id, username)
    await update.message.reply_text(OPENING)


async def help_cmd(update, context):
    await update.message.reply_text(HELP_TEXT)


async def id_cmd(update, context):
    chat_id = update.effective_chat.id
    await update.message.reply_text(f"🆔 CHAT ID\n\n{chat_id}")


async def signal_cmd(update, context):
    await update.message.reply_text("⏳ Lagi scan signal...")
    tickers = load_tickers(limit=SCREENING_TICKER_LIMIT)
    results = await run_screener(tickers)
    result_text = format_screener_results(results)
    await update.message.reply_text(DISCLAIMER + "\n\n" + result_text)


async def bsjp_cmd(update, context):
    await update.message.reply_text("🚀 Lagi scan BSJP...")
    tickers = load_tickers(limit=SCREENING_TICKER_LIMIT)
    results = await run_bsjp_screener(tickers)
    result_text = format_bsjp_screener_results(results)
    await update.message.reply_text(DISCLAIMER + "\n\n" + result_text)
