# =========================
# HANDLERS: SEKTOR & ROTASI
# =========================
# FITUR BARU. /rotasi, /sektor, /leader, /laggard, /beta -- memakai
# core/sector_rotation.py (lihat catatan batasan verifikasi data
# sektoral & cakupan SECTOR_MAP yang terbatas di file itu).
#
# /relative (alias untuk /rs yang SUDAH ADA, BUKAN fitur baru) didaftar
# terpisah di main.py memakai handler rs_cmd yang sama persis --
# sesuai daftar awal "Value Finance Bot", /RELATIVE = "relative
# strength vs sektor", yang persis sudah dilakukan /rs. Didaftarkan
# sebagai alias daripada duplikasi logic.

from core.async_yf import async_download
from core.stock_data import fix_yf_columns
from core.sector_rotation import (
    calculate_beta, get_sector_performance, get_sector_rotation, get_leader_laggard,
)
from core.market import SECTOR_MAP


async def _download_and_clean(ticker: str, period: str = "3mo"):
    import pandas as pd
    df = await async_download(ticker, period=period, interval="1d", progress=False)
    df = fix_yf_columns(df)
    df = df.apply(pd.to_numeric, errors="coerce")
    df = df.dropna()
    return df


def format_beta_message(ticker_name: str, result: dict) -> str:
    return f"""
📈 *BETA COEFFICIENT* - {ticker_name}
{'='*35}

Beta: *{result['beta']}*
(Berdasarkan {result['n_observations']} hari observasi)

{result['interpretasi']}

💡 Beta = 1 artinya bergerak persis sama dengan IHSG. Beta > 1 = lebih volatile (untung/rugi lebih besar). Beta < 1 = lebih stabil (untung/rugi lebih kecil). Beta dihitung dari data historis, BUKAN garansi perilaku ke depan.
"""


async def beta_cmd(update, context):
    """/beta KODE - Koefisien beta vs IHSG."""
    if not context.args:
        return await update.message.reply_text("Usage: /beta BBCA")

    ticker = context.args[0].upper() + ".JK"
    ticker_name = ticker.replace(".JK", "")

    await update.message.reply_text(f"📊 Menghitung beta {ticker_name} vs IHSG...")

    stock_df = await _download_and_clean(ticker, period="6mo")
    ihsg_df = await _download_and_clean("^JKSE", period="6mo")

    if len(stock_df) < 30 or len(ihsg_df) < 30:
        return await update.message.reply_text(f"❌ Data {ticker_name} atau IHSG tidak cukup (minimal ~30 hari).")

    result = calculate_beta(stock_df, ihsg_df)
    if result is None:
        return await update.message.reply_text(f"❌ Tidak bisa menghitung beta {ticker_name} (data tidak bisa disejajarkan dengan IHSG).")

    msg = format_beta_message(ticker_name, result)
    await update.message.reply_text(msg, parse_mode='Markdown')


async def sektor_cmd(update, context):
    """/sektor - Ranking kekuatan 11 sektor resmi IDX-IC."""
    await update.message.reply_text("📊 Menghitung performa 11 sektor IDX...")

    results = await get_sector_performance(period_days=5)

    if not results:
        return await update.message.reply_text("❌ Gagal mengambil data sektor. Coba lagi nanti.")

    msg = f"🏆 *RANKING SEKTOR (5 HARI)*\n{'='*35}\n\n"
    for i, r in enumerate(results, 1):
        emoji = "🟢" if r["return_pct"] > 0 else "🔴" if r["return_pct"] < 0 else "⚪"
        msg += f"{i}. {emoji} *{r['nama_sektor']}*: {r['return_pct']:+.2f}%\n"

    msg += "\n💡 Berdasarkan 11 indeks sektoral resmi IDX-IC. Sektor di atas IHSG menunjukkan dana sedang mengalir lebih banyak ke sana dibanding rata-rata pasar."
    await update.message.reply_text(msg, parse_mode='Markdown')


async def rotasi_cmd(update, context):
    """/rotasi - Rotasi sektor: momentum jangka pendek vs panjang."""
    await update.message.reply_text("📊 Menganalisis rotasi sektor (5 hari vs 20 hari)...")

    results = await get_sector_rotation(short_period=5, long_period=20)

    if not results:
        return await update.message.reply_text("❌ Gagal mengambil data sektor. Coba lagi nanti.")

    msg = f"🔄 *ROTASI SEKTOR*\n{'='*35}\n\n"
    for r in results:
        msg += (
            f"*{r['nama_sektor']}*\n"
            f"├─ 5 hari: {r['return_short']:+.2f}% | 20 hari: {r['return_long']:+.2f}%\n"
            f"└─ {r['fase']}\n\n"
        )

    msg += "💡 AKSELERASI = sektor baru mulai diminati (peluang masuk lebih awal). KONSISTEN KUAT = sudah lama diminati (trend mungkin sudah matang). MULAI MELEMAH = waspada, momentum mulai hilang."
    await update.message.reply_text(msg, parse_mode='Markdown')


async def leader_cmd(update, context):
    """/leader SEKTOR - Saham terkuat di dalam satu sektor."""
    if not context.args:
        sektor_list = ", ".join(SECTOR_MAP.keys())
        return await update.message.reply_text(f"Usage: /leader SEKTOR\nSektor tersedia: {sektor_list}")

    sektor = context.args[0]
    result = await get_leader_laggard(sektor, top_n=3)

    if result is None:
        sektor_list = ", ".join(SECTOR_MAP.keys())
        return await update.message.reply_text(f"❌ Sektor '{sektor}' tidak dikenal atau data gagal diambil.\nSektor tersedia: {sektor_list}")

    msg = f"🏆 *LEADER SEKTOR {result['sector_key']}*\n{'='*35}\n\n"
    for i, s in enumerate(result["leader"], 1):
        msg += f"{i}. {s['ticker']}: {s['return_pct']:+.2f}% (20 hari)\n"

    if result["sector_index_return"] is not None:
        msg += f"\n(Indeks sektor {result['sector_index_ticker'].replace('.JK','')}: {result['sector_index_return']:+.2f}%)\n"

    msg += (
        f"\n⚠️ *Keterbatasan*: hanya {result['total_saham_di_sektor_ini']} saham yang terdaftar "
        f"untuk sektor ini di bot ini (BUKAN seluruh saham sektor {result['sector_key']} yang ada di IDX)."
    )
    await update.message.reply_text(msg, parse_mode='Markdown')


async def laggard_cmd(update, context):
    """/laggard SEKTOR - Saham terlemah di dalam satu sektor."""
    if not context.args:
        sektor_list = ", ".join(SECTOR_MAP.keys())
        return await update.message.reply_text(f"Usage: /laggard SEKTOR\nSektor tersedia: {sektor_list}")

    sektor = context.args[0]
    result = await get_leader_laggard(sektor, top_n=3)

    if result is None:
        sektor_list = ", ".join(SECTOR_MAP.keys())
        return await update.message.reply_text(f"❌ Sektor '{sektor}' tidak dikenal atau data gagal diambil.\nSektor tersedia: {sektor_list}")

    msg = f"📉 *LAGGARD SEKTOR {result['sector_key']}*\n{'='*35}\n\n"
    for i, s in enumerate(result["laggard"], 1):
        msg += f"{i}. {s['ticker']}: {s['return_pct']:+.2f}% (20 hari)\n"

    if result["sector_index_return"] is not None:
        msg += f"\n(Indeks sektor {result['sector_index_ticker'].replace('.JK','')}: {result['sector_index_return']:+.2f}%)\n"

    msg += (
        f"\n⚠️ *Keterbatasan*: hanya {result['total_saham_di_sektor_ini']} saham yang terdaftar "
        f"untuk sektor ini di bot ini (BUKAN seluruh saham sektor {result['sector_key']} yang ada di IDX)."
    )
    await update.message.reply_text(msg, parse_mode='Markdown')
