# =========================
# HANDLERS: AI SCORE (RANAH AI)
# =========================
# PERUBAHAN dari main.py lama:
# - airank_cmd dulu loop SEQUENTIAL melalui 500 ticker, masing-masing
#   memanggil calculate_ai_score(ticker) yang download data sendiri
#   secara sinkron. Pesan ke user pun mengakui ini lambat ("Mohon tunggu
#   30-60 detik"). Sekarang: download SEMUA ticker paralel dulu via
#   async_download_many, baru kalkulasi (CPU-only, sudah cepat) dijalankan
#   untuk tiap hasil download. Dibatasi 200 ticker (bukan 500) konsisten
#   dengan keputusan SCREENING_TICKER_LIMIT di handler lain.
#
# REVISI BESAR (Juni 2026) -- permintaan eksplisit user: "/ranah jangan
# pakai /signal, pakai metode yang lebih akurat dan ada jurnalnya".
# TEMUAN PENTING saat investigasi: result['score'] yang ditampilkan
# SUDAH SEJAK LAMA dihitung pakai calculate_ai_score_from_df()
# (core/ai_score.py) -- sistem 6-dimensi berbasis riset jurnal (MACD+
# RSI 30pts dari backtest QuantifiedStrategies.com 73% win rate, MA
# Trend 25pts dari Minervini Trend Template, Volume 20pts, Bollinger
# 10pts, StochRSI 10pts, Momentum 5pts -- lihat sitasi lengkap di
# core/ai_score.py). MASALAHNYA: tampilan pesan ke user MASIH membingkai
# semuanya seolah pakai "/signal + Stochastic" (4 kondisi sederhana
# lama: MA cross, volume spike 1.2x, harga>200, volume>500rb) -- cuma
# framing teks yang menyesatkan, BUKAN benar-benar metodologi yang
# dipakai untuk menghitung skor.
#
# BUG NYATA YANG LEBIH SERIUS ditemukan di aiscore_cmd (breakdown):
# breakdown yang ditampilkan ke user dihitung ULANG secara TERPISAH
# dengan bobot LAMA (ma_score=25 if cond_ma else 10, dkk) yang SAMA
# SEKALI BEDA dari bobot yang SUNGGUHAN dipakai untuk result['score']
# -- breakdown yang ditampilkan TIDAK PERNAH benar-benar menjumlah ke
# skor yang ditampilkan. DIPERBAIKI dengan expose komponen skor ASLI
# di core/ai_score.py (macd_rsi_score, ma_trend_score, volume_score,
# bollinger_score, stochrsi_score, momentum_score) -- breakdown
# sekarang DIJAMIN menjumlah persis ke score (diverifikasi via test
# multi-seed, lihat catatan testing).
#
# Ketiga handler di file ini (ranah_cmd, aiscore_cmd, airank_cmd)
# DITULIS ULANG untuk menampilkan metodologi & sitasi yang SUNGGUHAN
# dipakai, hapus semua referensi "/signal" yang menyesatkan.

import os
from datetime import datetime

from core.async_yf import async_download, async_download_many
from core.stock_data import fix_yf_columns, load_tickers
from core.ai_score import calculate_ai_score_from_df
from core.charts.ai_gauge_chart import generate_ai_gauge_chart
from core.messages import split_long_message

SCREENING_TICKER_LIMIT = 200

# Sitasi riset -- SAMA PERSIS dengan yang didokumentasikan di header
# core/ai_score.py, ditampilkan ke user supaya transparan soal dasar
# metodologi (bukan klaim "AI" generik tanpa dasar).
METHODOLOGY_CITATIONS = (
    "📚 *Dasar Riset:*\n"
    "• MACD+RSI kombinasi: backtest 73% win rate (QuantifiedStrategies.com, 235 trade)\n"
    "• Konfirmasi: EMA+RSI 66.7% win rate (Journal of Autonomous Intelligence, 2024)\n"
    "• Konfirmasi IDX: RSI+MACD paling akurat untuk LQ45 BEI (El-Mal Journal, 2024)\n"
    "• MA Trend: Minervini Trend Template (Stage 2 uptrend filtering)\n"
)


async def _download_and_clean(ticker: str, period: str = "6mo"):
    import pandas as pd
    df = await async_download(ticker, period=period, interval="1d", progress=False)
    df = fix_yf_columns(df)
    df = df.apply(pd.to_numeric, errors="coerce")
    df = df.dropna()
    return df


async def ranah_cmd(update, context):
    """/ranah BBCA - Analisis multi-faktor teknikal berbasis riset jurnal."""
    if not context.args:
        return await update.message.reply_text(
            "🧠 *RANAH AI ANALYZER*\n\n"
            "Usage: /ranah BBCA\n\n"
            "Analisis multi-faktor teknikal berbasis riset jurnal:\n"
            "• 📊 MACD + RSI kombinasi (30 poin)\n"
            "• 📈 MA Trend Minervini-style (25 poin)\n"
            "• 💰 Volume confirmation (20 poin)\n"
            "• 🎯 Bollinger Band position (10 poin)\n"
            "• 🔄 StochRSI (10 poin)\n"
            "• ⚡ Momentum 5 hari (5 poin)\n\n"
            f"{METHODOLOGY_CITATIONS}\n"
            "Total maksimal 100 poin!",
            parse_mode='Markdown'
        )

    ticker_name = context.args[0].upper()
    await _run_ranah_analysis(update, ticker_name)


async def _run_ranah_analysis(reply_target, ticker_name: str):
    """Logic inti /ranah, DIPISAH dari ranah_cmd supaya BISA DIPAKAI
    ULANG oleh action menu (handlers/stock_menu_handlers.py) tanpa
    duplikasi -- REFACTOR Juni 2026, sebelumnya menu action punya
    salinan logic ini sendiri (termasuk bug "/signal" framing yang
    sama, lihat catatan panjang di awal file).

    reply_target: objek apapun yang punya .message.reply_text() DAN
    .message.reply_photo() -- bisa Update (dari command langsung) atau
    CallbackQuery (dari menu action), keduanya kompatibel karena
    query.message punya interface identik dengan update.message."""
    ticker = ticker_name + ".JK"

    await reply_target.message.reply_text(
        f"🧠 *AI menganalisis {ticker_name}...*\n⏳ Multi-faktor teknikal berbasis riset jurnal",
        parse_mode='Markdown'
    )

    df = await _download_and_clean(ticker)
    result = calculate_ai_score_from_df(df)

    if not result:
        return await reply_target.message.reply_text("❌ Gagal menganalisis. Data tidak cukup (minimal 50 hari).")

    chart_file = generate_ai_gauge_chart(ticker_name, result)

    msg = f"""
🧠 *RANAH AI ANALYZER* - {ticker_name}
🎯 *Multi-Faktor Teknikal Berbasis Riset Jurnal*
{'='*45}

📊 *AI SCORE: {result['score']}/100*
{result['signal']} *{result['rating']}* → *{result['recommendation']}*

{'='*45}
📈 *HARGA & VOLUME:*

💰 Harga      : Rp{result['price']:,.0f} ({result['change_1d']:+.2f}%)
📊 Volume     : {result['vol_ratio']}x rata-rata
📈 5 Hari     : {result['change_5d']:+.2f}%

{'='*45}
✅ *BREAKDOWN PER KOMPONEN:* (6 dimensi, total 100 poin)

"""

    for r in result["reasons"]:
        msg += f"{r}\n"

    msg += f"""
{'='*45}
🔢 *KONFLUENSI SINYAL:* {result['bullish_count']} Bullish / {result['bearish_count']} Bearish / {result['netral_count']} Netral

{'='*45}
💡 *REKOMENDASI AI:*

{result['recommendation']}

{METHODOLOGY_CITATIONS}
⚠️ *DISCLAIMER:* AI Score adalah alat bantu analisis teknikal berbasis riset, BUKAN jaminan hasil. Keputusan investasi sepenuhnya ada di tangan Anda. DYOR!
"""

    if chart_file and os.path.exists(chart_file):
        with open(chart_file, "rb") as f:
            await reply_target.message.reply_photo(
                f,
                caption=f"📊 *{ticker_name} - AI Score Gauge*\nScore: {result['score']}/100 | {result['recommendation']}",
                parse_mode='Markdown'
            )
        os.remove(chart_file)

    for chunk in split_long_message(msg):
        await reply_target.message.reply_text(chunk, parse_mode='Markdown')


async def aiscore_cmd(update, context):
    """/aiscore BBCA - Breakdown skor per komponen, berbasis riset jurnal."""
    if not context.args:
        return await update.message.reply_text(
            "📊 *AI SCORE BREAKDOWN*\n\nUsage: /aiscore BBCA\n\n"
            "Menampilkan rincian skor per komponen (6 dimensi berbasis riset jurnal).",
            parse_mode='Markdown'
        )

    ticker_name = context.args[0].upper()
    await _run_aiscore_breakdown(update, ticker_name)


async def _run_aiscore_breakdown(reply_target, ticker_name: str):
    """Logic inti /aiscore, DIPISAH dari aiscore_cmd supaya BISA DIPAKAI
    ULANG oleh action menu tanpa duplikasi -- REFACTOR Juni 2026 (lihat
    catatan di _run_ranah_analysis soal pola yang sama)."""
    ticker = ticker_name + ".JK"

    await reply_target.message.reply_text(f"📊 Menghitung AI Score breakdown untuk {ticker_name}...")

    df = await _download_and_clean(ticker)
    result = calculate_ai_score_from_df(df)

    if not result:
        return await reply_target.message.reply_text("❌ Gagal menganalisis. Data tidak cukup.")

    # PENTING: komponen skor di bawah ini adalah ANGKA ASLI yang
    # SUNGGUHAN dipakai menghitung result['score'] (core/ai_score.py)
    # -- BUKAN dihitung ulang terpisah seperti versi lama (bug yang
    # sudah diperbaiki, lihat catatan di awal file). Jumlahnya
    # DIJAMIN sama dengan result['score'].
    msg = f"""
📊 *AI SCORE BREAKDOWN* - {ticker_name}
🎯 *Multi-Faktor Teknikal Berbasis Riset Jurnal*
{'='*45}

🎯 *TOTAL AI SCORE: {result['score']}/100*

{'='*45}
📈 *KOMPONEN SKOR (MAX 100):*

1️⃣ *MACD + RSI Kombinasi* (max 30) -- riset 73% win rate
   → {result['macd_rsi_score']}/30 pts
   {result['macd_detail']}
   {result['rsi_detail']}

2️⃣ *MA Trend (Minervini-style)* (max 25)
   → {result['ma_trend_score']}/25 pts
   {result['ma_detail']}

3️⃣ *Volume Confirmation* (max 20)
   → {result['volume_score']}/20 pts
   {result['vol_detail']}

4️⃣ *Bollinger Band Position* (max 10)
   → {result['bollinger_score']}/10 pts
   {result['bb_detail']}

5️⃣ *StochRSI* (max 10)
   → {result['stochrsi_score']}/10 pts
   {result['stoch_detail']}

6️⃣ *Momentum 5 Hari* (max 5)
   → {result['momentum_score']}/5 pts
   Perubahan 5 hari: {result['change_5d']:+.2f}%

{'='*45}
🔢 *VERIFIKASI JUMLAH:* {result['macd_rsi_score']}+{result['ma_trend_score']}+{result['volume_score']}+{result['bollinger_score']}+{result['stochrsi_score']}+{result['momentum_score']} = {result['macd_rsi_score']+result['ma_trend_score']+result['volume_score']+result['bollinger_score']+result['stochrsi_score']+result['momentum_score']}/100

{'='*45}
📊 *INFORMASI TAMBAHAN:*

├─ RSI(14)      : {result['rsi']}
├─ MACD Hist    : {result['macd_hist']:+.2f}
├─ ATR          : {result['atr_pct']:.1f}% dari harga
├─ Perubahan 1D : {result['change_1d']:+.2f}%
└─ Perubahan 5D : {result['change_5d']:+.2f}%

{'='*45}
🎯 *REKOMENDASI AI: {result['recommendation']}*

{result['signal']} {result['rating']}

{METHODOLOGY_CITATIONS}
⚠️ DYOR sebelum mengambil keputusan!
"""

    await reply_target.message.reply_text(msg, parse_mode='Markdown')


async def airank_cmd(update, context):
    """/airank - Top 20 saham berdasarkan AI Score (multi-faktor, berbasis riset jurnal).

    Dulu loop sequential 500 ticker (pesan ke user mengakui "tunggu 30-60
    detik"). Sekarang download paralel dulu (200 ticker, konsisten dengan
    limit screener lain), baru kalkulasi (cepat, CPU-only) untuk tiap hasil."""
    await update.message.reply_text(
        "🏆 *AI RANKING* 🏆\n\n"
        "📊 Menghitung AI Score multi-faktor berbasis riset jurnal...\n\n"
        "Dimensi yang dinilai:\n"
        "• MACD + RSI kombinasi (30 poin)\n"
        "• MA Trend Minervini-style (25 poin)\n"
        "• Volume confirmation (20 poin)\n"
        "• Bollinger Band position (10 poin)\n"
        "• StochRSI (10 poin)\n"
        "• Momentum 5 hari (5 poin)",
        parse_mode='Markdown'
    )

    tickers = load_tickers(limit=SCREENING_TICKER_LIMIT)
    data_by_ticker = await async_download_many(tickers)

    results = []
    for ticker, df in data_by_ticker.items():
        try:
            df = fix_yf_columns(df).dropna()
            result = calculate_ai_score_from_df(df)
            if result:
                results.append({
                    "ticker": ticker.replace(".JK", ""), "score": result['score'],
                    "rating": result['rating'], "recommendation": result['recommendation'],
                    "signal": result['signal'], "price": result['price'],
                    "bullish_count": result['bullish_count'],
                    "bearish_count": result['bearish_count'],
                })
        except Exception as e:
            print(f"Error airank {ticker}: {e}")
            continue

    if not results:
        return await update.message.reply_text(
            "❌ Gagal menghitung ranking -- semua percobaan download data gagal.\n\n"
            "Kemungkinan penyebab:\n"
            "• Yahoo Finance sedang membatasi (rate-limit) request dari koneksi server, "
            "biasanya terjadi setelah banyak command dijalankan beruntun (mengunduh 200 "
            "saham sekaligus untuk /airank memang permintaan yang berat)\n"
            "• Koneksi internet server sedang tidak stabil\n\n"
            "Sudah dicoba ulang otomatis (3x per batch) tapi tetap gagal. "
            "Tunggu 1-2 menit lalu coba lagi."
        )

    results.sort(key=lambda x: x['score'], reverse=True)

    msg = "🏆 *TOP 20 AI SCORE RANKING* 🏆\n"
    msg += f"📅 {datetime.now().strftime('%d %B %Y, %H:%M')}\n"
    msg += "🎯 *Multi-Faktor Teknikal Berbasis Riset Jurnal*\n"
    msg += "=" * 45 + "\n\n"

    for i, r in enumerate(results[:20], 1):
        medal = "🥇" if i == 1 else "🥈" if i == 2 else "🥉" if i == 3 else "📊"
        msg += f"{medal} {i}. *{r['ticker']}*\n"
        msg += f"   🎯 Score: {r['score']}/100\n"
        msg += f"   {r['signal']} {r['rating']} → {r['recommendation']}\n"
        msg += f"   💰 Harga: Rp{r['price']:,.0f}\n"
        msg += f"   🔢 Konfluensi: {r['bullish_count']} Bullish / {r['bearish_count']} Bearish\n\n"

    msg += "=" * 45 + "\n"
    msg += f"📈 Total saham dianalisis: {len(results)}\n"
    msg += "💡 Gunakan /ranah [kode] untuk analisis detail per saham\n"
    msg += f"\n{METHODOLOGY_CITATIONS}"
    msg += "⚠️ AI hanya alat bantu, tetap DYOR!"

    await update.message.reply_text(msg, parse_mode='Markdown')
