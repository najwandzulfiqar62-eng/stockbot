# =========================
# HANDLER: RELATIVE STRENGTH
# =========================
# FITUR BARU -- lihat catatan lengkap di core/relative_strength.py.

import asyncio

from core.async_yf import async_download
from core.stock_data import fix_yf_columns
from core.relative_strength import (
    calculate_relative_strength, find_sector_for_ticker, format_relative_strength_message,
)
from core.market import SECTOR_MAP


async def _download_and_clean(ticker: str, period: str = "2mo"):
    import pandas as pd
    df = await async_download(ticker, period=period, interval="1d", progress=False)
    df = fix_yf_columns(df)
    df = df.apply(pd.to_numeric, errors="coerce")
    df = df.dropna()
    return df


async def _calculate_sector_average_df(sector_tickers: list[str]):
    """Hitung 'index sektor' sintetik: rata-rata Close (dinormalisasi)
    dari semua saham di sektor tersebut, dipakai sebagai benchmark."""
    import pandas as pd
    from core.async_yf import async_download_many

    data_by_ticker = await async_download_many(sector_tickers, period="2mo", interval="1d")
    cleaned = []
    for t in sector_tickers:
        df = data_by_ticker.get(t)
        if df is None:
            continue
        df = fix_yf_columns(df).dropna()
        if df.empty:
            continue
        # Normalisasi ke basis 100 di hari pertama supaya saham dengan
        # harga absolut jauh berbeda (misal saham 50rb vs saham 500) tidak
        # mendominasi rata-rata secara tidak proporsional
        normalized = (df["Close"] / df["Close"].iloc[0]) * 100
        cleaned.append(normalized)

    if not cleaned:
        return None

    # Align index (tanggal) dan rata-ratakan
    combined = pd.concat(cleaned, axis=1).dropna()
    avg_close = combined.mean(axis=1)
    return pd.DataFrame({"Close": avg_close})


async def rs_cmd(update, context):
    """/rs BBCA [hari] - Hitung relative strength vs IHSG dan sektor (kalau terdaftar)."""
    if not context.args:
        return await update.message.reply_text(
            "📊 *RELATIVE STRENGTH*\n\n"
            "Usage: /rs BBCA [hari]\n\n"
            "Mengukur apakah saham bergerak lebih kuat atau lebih lemah "
            "dibanding IHSG (dan sektornya, kalau terdaftar) dalam periode tertentu.\n\n"
            "Contoh: `/rs BBCA` (default 20 hari)\n`/rs TLKM 10`",
            parse_mode='Markdown'
        )

    ticker = context.args[0].upper() + ".JK"
    ticker_name = ticker.replace(".JK", "")

    try:
        period_days = int(context.args[1]) if len(context.args) >= 2 else 20
        period_days = max(5, min(period_days, 90))
    except ValueError:
        period_days = 20

    await update.message.reply_text(f"📊 Menghitung relative strength {ticker_name} ({period_days} hari)...")

    sector_name = find_sector_for_ticker(ticker)

    if sector_name:
        sector_tickers = [t for t in SECTOR_MAP[sector_name] if t != ticker]
        stock_df, ihsg_df_raw, sector_df = await asyncio.gather(
            _download_and_clean(ticker),
            _download_and_clean("^JKSE"),
            _calculate_sector_average_df(sector_tickers) if sector_tickers else asyncio.sleep(0, result=None),
        )
    else:
        stock_df, ihsg_df_raw = await asyncio.gather(
            _download_and_clean(ticker),
            _download_and_clean("^JKSE"),
        )
        sector_df = None

    rs_vs_ihsg = calculate_relative_strength(stock_df, ihsg_df_raw, period_days=period_days)
    rs_vs_sector = calculate_relative_strength(stock_df, sector_df, period_days=period_days) if sector_df is not None else None

    msg = format_relative_strength_message(ticker_name, rs_vs_ihsg, sector_name, rs_vs_sector)
    await update.message.reply_text(msg, parse_mode='Markdown')
