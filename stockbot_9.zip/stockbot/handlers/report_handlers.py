# =========================
# HANDLERS: LAPORAN PDF
# =========================
# /laporan KODE  -> menyusun laporan analisis PDF profesional untuk satu
# saham (struktur multi-perspektif: snapshot, teknikal, Bull vs Bear,
# skenario, risiko). Memakai data SUNGGUHAN: calculate_ai_score_from_df()
# yang sama dengan /ranah & /aiscore, plus narasi teknikal dari
# core/insight.py (_narrate_technical) supaya konsisten lintas fitur.
#
# Render PDF (reportlab, CPU-bound & sinkron) dijalankan di thread via
# asyncio.to_thread supaya TIDAK memblok event loop bot -- pola yang sama
# dengan _run_chart_in_thread di chart_handlers.py.
#
# Berita bersifat OPSIONAL & best-effort: kalau fetch_news gagal/timeout,
# laporan tetap dibuat tanpa bagian berita (tidak menggagalkan perintah).

import os
import asyncio
import tempfile
from datetime import datetime
from functools import lru_cache

import pandas as pd

from core.async_yf import async_download
from core.stock_data import fix_yf_columns
from core.ai_score import calculate_ai_score_from_df
from core.insight import _narrate_technical, generate_market_insight
from core.report import build_report_data, build_smc_summary, build_ihsg_report_data
from core.charts.report_pdf import generate_report_pdf, generate_ihsg_report_pdf
from core.charts.advanced_chart import generate_advanced_chart
from core.smc import detect_bos_choch, detect_order_blocks, detect_fvg, detect_liquidity_pools
from core.charts.smc_chart import (
    generate_bos_chart, generate_orderblock_chart, generate_fvg_chart, generate_liquidity_chart,
)
from core.ihsg.ihsg_analysis import analyze_ihsg_with_backtest
from core.ihsg.ihsg_chart import generate_ihsg_advanced_chart
from core.sector_rotation import get_sector_performance
from core.news import fetch_news
from core.config import SAHAM_XLSX_PATH

_IHSG_ALIASES = {"IHSG", "JKSE", "^JKSE", "COMPOSITE", "INDEX"}


@lru_cache(maxsize=1)
def _nama_map() -> dict:
    """Cache {KODE: Nama Perusahaan} dari saham.xlsx (nama asli/proper-case,
    beda dari versi ternormalisasi di core/news_emiten.py). Kalau gagal,
    return {} -> laporan tetap jalan, nama perusahaan dikosongkan."""
    try:
        df = pd.read_excel(SAHAM_XLSX_PATH)
        return {str(r["Kode"]).strip().upper(): str(r.get("Nama Perusahaan", "")).strip()
                for _, r in df.iterrows()}
    except Exception as e:
        print(f"⚠️ /laporan: gagal load nama emiten: {e}")
        return {}


async def _download_and_clean(ticker: str, period: str = "1y", interval: str = "1d"):
    df = await async_download(ticker, period=period, interval=interval, progress=False)
    df = fix_yf_columns(df)
    df = df.apply(pd.to_numeric, errors="coerce").dropna()
    return df


async def laporan_cmd(update, context):
    """/laporan [KODE|IHSG] - laporan analisis PDF profesional.

    /laporan          -> laporan IHSG (market-wide)
    /laporan IHSG     -> laporan IHSG
    /laporan BBCA     -> laporan satu saham
    """
    arg = context.args[0].upper().replace(".JK", "") if context.args else "IHSG"
    if arg in _IHSG_ALIASES:
        return await _laporan_ihsg(update)
    return await _laporan_saham(update, arg)


async def _laporan_saham(update, kode: str):
    ticker = kode + ".JK"
    await update.message.reply_text(
        f"📄 Menyusun laporan analisis PDF untuk *{kode}*...\n_Membutuhkan beberapa detik._",
        parse_mode="Markdown")

    # 1. Data harga
    try:
        df = await _download_and_clean(ticker, period="1y")
    except Exception as e:
        print(f"⚠️ /laporan {kode}: gagal download: {e}")
        return await update.message.reply_text(
            f"❌ Gagal mengambil data untuk {kode}. Pastikan kode saham benar (mis. BBCA, TLKM).")

    if df is None or len(df) < 50:
        return await update.message.reply_text(
            f"❌ Data {kode} tidak cukup untuk analisis (butuh ≥50 hari perdagangan).")

    # 2. Skor teknikal (fungsi yang SAMA dengan /ranah & /aiscore)
    ai = calculate_ai_score_from_df(df)
    if ai is None:
        return await update.message.reply_text(f"❌ Gagal menganalisis {kode}.")

    insight = {"teknikal": _narrate_technical(ai)}

    # 3. Chart (opsional, best-effort) + SMC (murni, pandas)
    chart_path = None
    try:
        chart_path = await asyncio.to_thread(generate_advanced_chart, df, kode)
    except Exception as e:
        print(f"⚠️ /laporan {kode}: chart dilewati: {e}")
    smc = None
    smc_charts = {}
    try:
        smc = build_smc_summary(df)
        if smc:
            # Hitung tiap komponen sekali, lalu render chart-nya (di thread).
            specs = [
                ("Struktur (BOS/CHoCH)", generate_bos_chart, detect_bos_choch(df, left_bars=5, right_bars=5)),
                ("Order Block", generate_orderblock_chart, detect_order_blocks(df)),
                ("Fair Value Gap", generate_fvg_chart, detect_fvg(df)),
                ("Liquidity Pools", generate_liquidity_chart, detect_liquidity_pools(df)),
            ]
            for label, gen, detected in specs:
                try:
                    p = await asyncio.to_thread(gen, df, kode, detected)
                    if p:
                        smc_charts[label] = p
                except Exception as e:
                    print(f"⚠️ /laporan {kode}: chart SMC '{label}' dilewati: {e}")
    except Exception as e:
        print(f"⚠️ /laporan {kode}: SMC dilewati: {e}")

    # 4. Berita (opsional, best-effort)
    news = None
    try:
        items = await fetch_news(keyword=kode, limit=5)
        if items:
            news = items
    except Exception as e:
        print(f"⚠️ /laporan {kode}: berita dilewati: {e}")

    nama = _nama_map().get(kode, "")
    report_data = build_report_data(kode, nama, ai, insight=insight, news_items=news,
                                    chart_path=chart_path, smc=smc, smc_charts=smc_charts)

    # 5. Render PDF di thread, kirim, lalu bersihkan (PDF + chart sementara)
    tmp = tempfile.NamedTemporaryFile(suffix=".pdf", delete=False, prefix=f"laporan_{kode}_")
    path = tmp.name
    tmp.close()
    try:
        await asyncio.to_thread(generate_report_pdf, report_data, path)
        fname = f"Laporan_{kode}_{datetime.now():%Y%m%d}.pdf"
        with open(path, "rb") as f:
            await update.message.reply_document(
                f, filename=fname,
                caption=(f"📄 *Laporan Analisis {kode}*\n"
                         f"AI Score: {ai['score']}/100 ({ai['rating']}) — {ai['recommendation']}\n\n"
                         f"_Laporan otomatis berbasis analisis teknikal. Bukan rekomendasi/nasihat keuangan._"),
                parse_mode="Markdown",
                # PDF bisa >1 MB (banyak chart) -> upload lambat. Timeout
                # default PTB (~20s) sering tak cukup di koneksi lambat.
                read_timeout=120, write_timeout=120, connect_timeout=30, pool_timeout=30)
    except Exception as e:
        print(f"⚠️ /laporan {kode}: gagal render/kirim PDF: {e}")
        await update.message.reply_text(
            f"❌ Gagal membuat file PDF untuk {kode}. Coba lagi sebentar.")
    finally:
        for p in (path, chart_path, *smc_charts.values()):
            if p and os.path.exists(p):
                try:
                    os.remove(p)
                except OSError:
                    pass


async def _laporan_ihsg(update):
    await update.message.reply_text(
        "📄 Menyusun laporan analisis PDF *IHSG*...\n_Membutuhkan beberapa detik._",
        parse_mode="Markdown")

    # 1. Data IHSG (pola SAMA dengan /ihsg: sequential + jeda anti rate-limit)
    try:
        df_daily = await _download_and_clean("^JKSE", period="3mo")
        await asyncio.sleep(0.5)
        df_weekly = await _download_and_clean("^JKSE", period="1y", interval="1wk")
        await asyncio.sleep(0.5)
        df_longer = await _download_and_clean("^JKSE", period="2y")
    except Exception as e:
        print(f"⚠️ /laporan IHSG: gagal download: {e}")
        return await update.message.reply_text(
            "❌ Gagal mengambil data IHSG. Kemungkinan Yahoo Finance sedang rate-limit. "
            "Tunggu 1-2 menit lalu coba lagi.")

    if df_daily is None or len(df_daily) < 50:
        return await update.message.reply_text(
            "❌ Data IHSG tidak cukup untuk analisis (butuh ≥50 hari). Coba lagi sebentar.")

    # 2. Analisis IHSG (fungsi yang SAMA dengan /ihsg)
    analysis = analyze_ihsg_with_backtest(df_daily, df_weekly, df_longer)
    if not analysis:
        return await update.message.reply_text("❌ Gagal menganalisis IHSG.")

    # 3. Chart IHSG (best-effort)
    chart_path = None
    try:
        chart_path = await asyncio.to_thread(generate_ihsg_advanced_chart, df_daily)
    except Exception as e:
        print(f"⚠️ /laporan IHSG: chart dilewati: {e}")

    # 3b. SMC untuk IHSG (sama seperti laporan saham — build_smc_summary
    #     murni jalan di OHLCV apa pun, jadi langsung dipakai utk indeks).
    smc = None
    smc_charts = {}
    try:
        smc = build_smc_summary(df_daily)
        if smc:
            specs = [
                ("Struktur (BOS/CHoCH)", generate_bos_chart, detect_bos_choch(df_daily, left_bars=5, right_bars=5)),
                ("Order Block", generate_orderblock_chart, detect_order_blocks(df_daily)),
                ("Fair Value Gap", generate_fvg_chart, detect_fvg(df_daily)),
                ("Liquidity Pools", generate_liquidity_chart, detect_liquidity_pools(df_daily)),
            ]
            for label, gen, detected in specs:
                try:
                    p = await asyncio.to_thread(gen, df_daily, "IHSG", detected)
                    if p:
                        smc_charts[label] = p
                except Exception as e:
                    print(f"⚠️ /laporan IHSG: chart SMC '{label}' dilewati: {e}")
    except Exception as e:
        print(f"⚠️ /laporan IHSG: SMC dilewati: {e}")

    # 4. Rotasi sektor + insight market (best-effort)
    sector_data = None
    try:
        sector_data = await get_sector_performance(period_days=5)
    except Exception as e:
        print(f"⚠️ /laporan IHSG: sektor dilewati: {e}")

    market_insight = None
    try:
        ai_ihsg = calculate_ai_score_from_df(df_daily)
        news_for_insight = None
        try:
            news_for_insight = await fetch_news(keyword="IHSG", limit=5)
        except Exception:
            pass
        if ai_ihsg:
            market_insight = await generate_market_insight(ai_ihsg, sector_data, news_for_insight)
    except Exception as e:
        print(f"⚠️ /laporan IHSG: market insight dilewati: {e}")

    news = None
    try:
        items = await fetch_news(keyword="IHSG", limit=5)
        if items:
            news = items
    except Exception:
        pass

    report_data = build_ihsg_report_data(analysis, sector_data, market_insight, news, chart_path,
                                         smc=smc, smc_charts=smc_charts)

    # 5. Render + kirim + bersihkan
    tmp = tempfile.NamedTemporaryFile(suffix=".pdf", delete=False, prefix="laporan_ihsg_")
    path = tmp.name
    tmp.close()
    try:
        await asyncio.to_thread(generate_ihsg_report_pdf, report_data, path)
        fname = f"Laporan_IHSG_{datetime.now():%Y%m%d}.pdf"
        with open(path, "rb") as f:
            await update.message.reply_document(
                f, filename=fname,
                caption=(f"📄 *Laporan Analisis IHSG*\n"
                         f"Prediksi: {analysis.get('prediction','-')} "
                         f"({analysis.get('confidence','-')})\n\n"
                         f"_Laporan otomatis berbasis analisis teknikal. Bukan nasihat keuangan._"),
                parse_mode="Markdown",
                # Laporan IHSG paling berat (chart IHSG + 4 chart SMC) ->
                # upload bisa lama. Naikkan timeout supaya tidak "Timed out".
                read_timeout=120, write_timeout=120, connect_timeout=30, pool_timeout=30)
    except Exception as e:
        print(f"⚠️ /laporan IHSG: gagal render/kirim PDF: {e}")
        await update.message.reply_text("❌ Gagal membuat file PDF IHSG. Coba lagi sebentar.")
    finally:
        for p in (path, chart_path, *smc_charts.values()):
            if p and os.path.exists(p):
                try:
                    os.remove(p)
                except OSError:
                    pass
