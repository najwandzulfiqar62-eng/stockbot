async def howto_cmd(update, context):
    """Menampilkan cara penggunaan fitur baru."""
    await update.message.reply_text(
        "🎯 *CARA PAKAI FITUR BARU*\n\n"
        "Cukup *KETIK KODE SAHAM* di chat!\n\n"
        "Contoh:\n"
        "• `BBCA`\n"
        "• `BBRI`\n"
        "• `TLKM`\n"
        "• `ASII`\n\n"
        "Maka akan muncul MENU dengan pilihan:\n"
        "📈 Trading Plan\n"
        "📊 Advanced Chart\n"
        "📉 SNR Chart\n"
        "🤖 ML Chart\n"
        "⭐ Watchlist\n"
        "📊 Quick Info\n\n"
        "✅ MUDAH & CEPAT!",
        parse_mode='Markdown'
    )
