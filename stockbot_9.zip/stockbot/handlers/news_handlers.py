# =========================
# HANDLER: NEWS
# =========================
# /news [kode] -- berita pasar/saham, AGREGASI dari 3 RSS feed publik
# Indonesia (CNBC Indonesia, CNN Indonesia, Detik Finance). Lihat
# catatan sumber & keterbatasan lengkap di core/news.py.

from core.news import fetch_news
from core.news_idx import ENABLE_IDX_DISCLOSURES
from core.news_signal import enrich_news_with_signals
from core.messages import sanitize_for_markdown


def format_news_message(items: list[dict], keyword: str | None) -> str:
    """Format list berita jadi pesan Telegram. Dipisah dari handler
    supaya bisa ditest tanpa perlu mock network call.

    PENTING: judul & ringkasan berita SUMBER EKSTERNAL (RSS feed,
    tidak dikontrol bot ini) -- SELALU disanitasi via
    sanitize_for_markdown() sebelum dimasukkan ke pesan parse_mode=
    'Markdown', supaya underscore/asterisk di judul berita asli tidak
    memicu Telegram parse error (bug yang sama dengan kasus /ihsg
    sebelumnya, lihat catatan lengkap di core/messages.py).

    REVISI (Juni 2026, multi-sumber): setiap item SEKARANG punya field
    'source' (nama portal asalnya) -- ditampilkan per-item untuk
    transparansi, supaya user tahu berita itu dari portal mana, BUKAN
    cuma satu baris generik "Sumber: CNBC Indonesia" seperti versi
    lama (yang sekarang MENYESATKAN karena ada 3 sumber, bukan 1)."""
    if not items:
        if keyword:
            return (
                f"📰 Tidak ada berita yang menyebut *{sanitize_for_markdown(keyword)}* dalam berita "
                f"market terbaru dari 3 sumber yang dipantau (CNBC Indonesia, CNN Indonesia, Detik Finance).\n\n"
                f"Coba /news tanpa kode untuk berita market umum, atau cek lagi nanti "
                f"(berita per-saham tidak selalu ada tiap saat)."
            )
        return "📰 Tidak ada berita yang bisa diambil saat ini. Coba lagi dalam beberapa menit."

    header = f"📰 *BERITA: {sanitize_for_markdown(keyword.upper())}*" if keyword else "📰 *BERITA MARKET TERKINI*"
    msg = f"{header}\n{'='*35}\n\n"

    for item in items:
        source_tag = sanitize_for_markdown(item.get("source", ""))
        msg += f"*{sanitize_for_markdown(item['title'])}*"
        if source_tag:
            msg += f" _({source_tag}"
            # Kalau berita ini juga diliput portal lain (hasil dedup),
            # tampilkan supaya user tahu cakupannya, bukan disembunyikan.
            sumber_lain = item.get("sumber_lain") or []
            if sumber_lain:
                lain = ", ".join(sanitize_for_markdown(s) for s in sumber_lain)
                msg += f" +{lain}"
            msg += ")_"
        msg += "\n"
        # Tag emiten yang terdeteksi disebut di berita (kalau ada)
        emiten = item.get("emiten") or []
        if emiten:
            tag = ", ".join(sanitize_for_markdown(e) for e in emiten[:6])
            msg += f"📌 Saham terkait: {tag}\n"
        # Sinyal teknikal yang DIRANGKAI ke emiten di berita ini (kalau
        # sudah di-enrich oleh handler). Ditampilkan di SAMPING berita --
        # ini kondisi teknikal terpisah, BUKAN klaim berita yg menyebabkannya.
        sinyal = item.get("sinyal") or {}
        for kode, s in sinyal.items():
            arah = "+" if s["change_1d"] >= 0 else ""
            msg += (
                f"{s['signal']} *{sanitize_for_markdown(kode)}* {s['score']}/100 "
                f"({sanitize_for_markdown(s['rating'])}) {arah}{s['change_1d']}% hari ini\n"
            )
        if item["summary"]:
            # Potong ringkasan supaya pesan tidak terlalu panjang per item
            summary = item["summary"]
            if len(summary) > 150:
                summary = summary[:150].rsplit(" ", 1)[0] + "..."
            msg += f"{sanitize_for_markdown(summary)}\n"
        if item["pub_date"]:
            msg += f"🕐 {item['pub_date']}\n"
        msg += f"🔗 {item['link']}\n\n"

    sumber_list = "CNBC Indonesia, CNN Indonesia, dan Detik Finance"
    if ENABLE_IDX_DISCLOSURES:
        sumber_list = ("CNBC Indonesia, CNN Indonesia, Detik Finance, dan Keterbukaan "
                       "Informasi BEI (idx.co.id)")
    msg += (
        f"_Sumber: agregasi RSS feed publik {sumber_list} "
        "(diurutkan berdasarkan waktu publikasi terbaru, duplikat lintas sumber digabung). "
        "Bot ini cuma menampilkan headline & ringkasan, bukan menulis atau menilai isi berita._"
    )
    return msg


async def news_cmd(update, context):
    """/news [kode] - Berita pasar/saham terkini (agregasi 3 sumber)."""
    keyword = context.args[0].upper() if context.args else None

    label = f"berita {keyword}" if keyword else "berita market terkini"
    await update.message.reply_text(f"📰 Mengambil {label} dari 3 sumber...")

    items = await fetch_news(keyword=keyword, limit=8)

    if items is None:
        return await update.message.reply_text(
            "❌ Gagal mengambil berita saat ini.\n\n"
            "Kemungkinan penyebab:\n"
            "• Ketiga sumber berita (CNBC Indonesia, CNN Indonesia, Detik Finance) sedang tidak bisa diakses bersamaan\n"
            "• Koneksi internet server terputus sementara\n\n"
            "Coba lagi dalam 1-2 menit."
        )

    # RANGKAI berita + sinyal teknikal. Hanya saat user fokus ke SATU
    # saham (/news BBCA) -- di situ enrichment cuma ~1 download, relevan,
    # & murah. Untuk /news umum (tanpa kode) sengaja TIDAK di-enrich:
    # bisa menyentuh belasan emiten lintas berita = banyak download &
    # lambat (lihat alasan lengkap di core/news_signal.py). Dibungkus
    # try/except: kalau skoring gagal (mis. Yahoo Finance down), berita
    # TETAP tampil tanpa sinyal, bukan gagal total.
    if keyword and items:
        try:
            items = await enrich_news_with_signals(items)
        except Exception as e:
            print(f"⚠️ Gagal enrich berita dengan sinyal teknikal: {type(e).__name__}: {e}")

    msg = format_news_message(items, keyword)
    await update.message.reply_text(msg, parse_mode='Markdown', disable_web_page_preview=True)
