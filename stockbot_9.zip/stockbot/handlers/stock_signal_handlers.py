# =========================
# HANDLERS: STOCK SIGNAL (BUY SCANNER)
# =========================
# Menggunakan core/stock_signals.py yang sudah memperbaiki bug KeyError
# above_ma20/above_ma50 dari kode lama (lihat catatan di modul tersebut).

from datetime import datetime

from core.stock_data import load_tickers
from core.stock_signals import scan_stocks_for_buy_signals

SCREENING_TICKER_LIMIT = 200


async def stocksignal_cmd(update, context):
    """/stocksignal - Menampilkan saham yang memenuhi kriteria BUY."""
    await update.message.reply_text("🔍 Scanning semua saham untuk sinyal BUY...")

    tickers = load_tickers(limit=SCREENING_TICKER_LIMIT)
    results = await scan_stocks_for_buy_signals(tickers)

    if not results:
        return await update.message.reply_text(
            "❌ Tidak ada saham yang memenuhi kriteria BUY saat ini.\n\n"
            "Kriteria BUY:\n"
            "• Stochastic RSI Oversold (K < 30) ATAU Golden Cross\n"
            "• Volume > 1.2x rata-rata ATAU Harga > MA20\n"
            "• Minimal 2 kondisi terpenuhi"
        )

    msg = "🔥 *SAHAM DENGAN SINYAL BUY* 🔥\n"
    msg += f"📅 {datetime.now().strftime('%d %B %Y, %H:%M')}\n"
    msg += "=" * 40 + "\n\n"

    for i, r in enumerate(results[:15], 1):
        if r["confidence"] >= 80:
            emoji = "🚀🔥"
        elif r["confidence"] >= 60:
            emoji = "✅"
        elif r["confidence"] >= 40:
            emoji = "📊"
        else:
            emoji = "⚠️"

        msg += f"{emoji} *{i}. {r['ticker']}*\n"
        msg += f"   💰 Harga: Rp{r['price']:,.0f} | {r['change']:+.2f}%\n"
        msg += f"   📊 Stoch K/D: {r['stoch_k']:.1f} / {r['stoch_d']:.1f}\n"
        msg += f"   📈 Volume: {r['volume_ratio']:.1f}x rata-rata\n"

        ma_status = ""
        if r['above_ma20']:
            ma_status += "🟢 Above MA20 "
        if r['above_ma50']:
            ma_status += "🟢 Above MA50"
        if ma_status:
            msg += f"   {ma_status}\n"

        msg += f"   🎯 Sinyal: {r['reasons']}\n"
        msg += f"   ⭐ Confidence: {r['confidence']}%\n\n"

    msg += "=" * 40 + "\n"
    msg += f"📈 Total saham dengan sinyal BUY: {len(results)}\n"
    msg += "💡 Gunakan /chart [kode] untuk analisis detail\n"
    msg += "⚠️ DYOR sebelum mengambil keputusan!"

    await update.message.reply_text(msg, parse_mode='Markdown')


async def topsignal_cmd(update, context):
    """/topsignal - Menampilkan TOP 5 saham dengan sinyal BUY terkuat."""
    await update.message.reply_text("🔍 Mencari sinyal terbaik...")

    tickers = load_tickers(limit=SCREENING_TICKER_LIMIT)
    results = await scan_stocks_for_buy_signals(tickers)

    if not results:
        return await update.message.reply_text("❌ Tidak ada sinyal BUY saat ini.")

    top5 = results[:5]
    msg = "🏆 *TOP 5 SAHAM DENGAN SINYAL BUY TERKUAT* 🏆\n\n"

    for i, r in enumerate(top5, 1):
        msg += f"{i}. *{r['ticker']}*\n"
        msg += f"   Harga: Rp{r['price']:,.0f} ({r['change']:+.2f}%)\n"
        msg += f"   Confidence: {r['confidence']}%\n"
        msg += f"   Sinyal: {r['reasons']}\n\n"

    msg += "💡 Gunakan /chart [kode] untuk analisis detail"
    await update.message.reply_text(msg, parse_mode='Markdown')
