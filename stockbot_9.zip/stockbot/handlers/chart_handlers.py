# =========================
# HANDLERS: CHART COMMANDS
# =========================
# PERUBAHAN dari main.py lama:
# - advanced_chart_cmd DULU DIDEFINISIKAN DUA KALI (baris 4585 dan 4620
#   di main.py lama), isinya identik -- definisi pertama jadi kode mati
#   yang ditimpa diam-diam oleh definisi kedua. Dikonsolidasikan jadi
#   SATU fungsi di sini.
# - signals_chart_cmd dulu memanggil generate_trading_signals_chart()
#   yang cuma alias untuk generate_advanced_chart(ticker, period="6mo").
#   Sekarang langsung panggil generate_advanced_chart dengan period
#   eksplisit -- tidak perlu alias terpisah.
# - snr_cmd dulu memanggil get_rsi_value(ticker) yang download data LAGI
#   secara terpisah (2 bulan data) HANYA untuk menampilkan RSI di caption,
#   padahal generate_snr() sendiri sudah menghitung RSI dari data 6 bulan
#   yang sama. Sekarang RSI diambil dari hasil generate_snr (lewat
#   calculate_snr_levels + calculate_rsi pada df yang sama), tidak perlu
#   download kedua.

import os
import asyncio

from core.async_yf import async_download
from core.stock_data import fix_yf_columns
from core.indicators import calculate_rsi
from core.charts.snr_chart import generate_snr
from core.charts.ta_chart import generate_ta_chart
from core.charts.advanced_chart import generate_advanced_chart
from core.messages import DISCLAIMER


async def _run_chart_in_thread(func, *args, **kwargs):
    """Jalankan fungsi generate chart (matplotlib, blocking & CPU-bound)
    di thread terpisah supaya tidak memblokir event loop. Chart generation
    cukup CPU-intensive untuk chart kompleks (4-panel dengan ratusan
    candlestick), jadi tetap perlu di-offload meski bukan I/O murni."""
    return await asyncio.to_thread(func, *args, **kwargs)


async def _download_and_clean(ticker: str, period: str = "6mo"):
    import pandas as pd
    df = await async_download(ticker, period=period, interval="1d", progress=False)
    df = fix_yf_columns(df)
    df = df.apply(pd.to_numeric, errors="coerce")
    df = df.dropna()
    return df


def _get_rsi_label(df) -> str:
    """Format RSI dari df yang sudah ada jadi label dengan status, tanpa
    perlu download data terpisah (beda dari get_rsi_value() di kode lama
    yang download ulang)."""
    if len(df) < 30:
        return "N/A"
    try:
        last_rsi = float(calculate_rsi(df["Close"]).iloc[-1])
        if last_rsi > 70:
            return f"{last_rsi:.1f} (Overbought)"
        elif last_rsi < 30:
            return f"{last_rsi:.1f} (Oversold)"
        else:
            return f"{last_rsi:.1f} (Normal)"
    except Exception:
        return "N/A"


async def snr_cmd(update, context):
    if not context.args:
        return await update.message.reply_text(
            "📊 *SNR CHART (Support & Resistance Level 3)*\n\n"
            "Usage: /snr BBCA\n\n"
            "Menampilkan chart professional dengan:\n"
            "• Candlestick chart\n"
            "• MA5 (orange), MA20 (yellow), MA50 (cyan), MA200 (magenta)\n"
            "• Support S1, S2, S3\n"
            "• Resistance R1, R2, R3\n"
            "• RSI indicator\n"
            "• Volume analysis\n"
            "• Sama persis dengan gambar contoh!",
            parse_mode='Markdown'
        )

    ticker = context.args[0].upper() + ".JK"
    ticker_name = ticker.replace('.JK', '')
    await update.message.reply_text(f"📊 Membuat SNR chart professional untuk {ticker_name}...")

    df = await _download_and_clean(ticker, period="6mo")
    file = await _run_chart_in_thread(generate_snr, df, ticker)

    if file and os.path.exists(file):
        rsi_value = _get_rsi_label(df)

        with open(file, "rb") as f:
            await update.message.reply_photo(
                f,
                caption=f"📈 *{ticker_name} - SNR Analysis (3 Level S/R)*\n\n"
                        f"🔴 *Resistance:* R1, R2, R3\n"
                        f"🟢 *Support:* S1, S2, S3\n"
                        f"📊 *RSI:* {rsi_value}\n\n"
                        f"💡 *Strategi:*\n"
                        f"• Beli di area Support (S1-S2-S3)\n"
                        f"• Jual di area Resistance (R1-R2-R3)\n"
                        f"• Konfirmasi dengan volume & RSI",
                parse_mode='Markdown'
            )
        os.remove(file)
    else:
        await update.message.reply_text("❌ Gagal membuat SNR chart. Data tidak cukup (minimal 50 hari data).")


async def ta_cmd(update, context):
    """/ta KODE - Technical Analysis lengkap (candlestick + MA5/20/50/200
    + Fibonacci + S/R + panel info + MACD + Volume).

    REDESIGN (Juni 2026): MENGGANTIKAN chart "ML" lama (core/charts/
    ml_chart.py, dihapus -- namanya menyiratkan machine learning padahal
    cuma regresi linear sederhana, lihat catatan jujur yang pernah ada
    di file itu). /ta dirancang meniru referensi visual yang diberikan
    user secara eksplisit. /ml dipertahankan sebagai ALIAS (memanggil
    fungsi yang SAMA persis) supaya tidak breaking change untuk siapapun
    yang sudah terbiasa pakai command lama."""
    if not context.args:
        return await update.message.reply_text("Contoh:\n/ta BBCA")
    ticker = context.args[0].upper() + ".JK"
    await update.message.reply_text(f"📊 Membuat chart Technical Analysis {ticker}...")

    df = await _download_and_clean(ticker, period="1y")
    file = await _run_chart_in_thread(generate_ta_chart, df, ticker)

    if file is None:
        return await update.message.reply_text("❌ Data tidak cukup (minimal 60 hari data).")

    with open(file, "rb") as f:
        await update.message.reply_photo(f)
    os.remove(file)


# Alias /ml -> ta_cmd (SAMA PERSIS, bukan command terpisah) -- lihat
# catatan lengkap di docstring ta_cmd soal alasan penggantian.
ml_cmd = ta_cmd


async def advanced_chart_cmd(update, context, period: str = "3mo"):
    """/chart BBCA - Generate advanced chart with indicators.

    Konsolidasi dari 2 definisi duplikat di main.py lama (identik)."""
    if not context.args:
        return await update.message.reply_text(
            "📊 Advanced Chart\n\n"
            "Usage: /chart BBCA\n\n"
            "Features:\n"
            "• Candlestick chart\n"
            "• Multiple MAs (20, 50, 200)\n"
            "• Bollinger Bands\n"
            "• Support/Resistance\n"
            "• RSI subplot\n"
            "• Volume analysis\n"
            "• Auto buy/sell signals"
        )
    ticker = context.args[0].upper() + ".JK"
    await update.message.reply_text(f"📈 Generating advanced chart for {ticker}...")

    df = await _download_and_clean(ticker, period=period)
    file = await _run_chart_in_thread(generate_advanced_chart, df, ticker)

    if file:
        with open(file, "rb") as f:
            await update.message.reply_photo(
                f,
                caption=(
                    f"📊 *{ticker.replace('.JK', '')} - Advanced Technical Analysis*\n\n"
                    f"🟢 *Bullish Signals:* MA20 > MA50, RSI > 50\n"
                    f"🔴 *Bearish Signals:* MA20 < MA50, RSI < 50\n\n"
                    f"💡 *Trading Tips:*\n"
                    f"• Buy when price bounces from support\n"
                    f"• Sell when price hits resistance\n"
                    f"• Wait for golden cross for confirmation"
                ),
                parse_mode='Markdown'
            )
        os.remove(file)
    else:
        await update.message.reply_text("❌ Failed to generate chart. Data insufficient.")


async def signals_chart_cmd(update, context):
    """/signals BBCA - Chart with annotated trading signals.

    Dulu memanggil generate_trading_signals_chart() yang cuma alias untuk
    generate_advanced_chart(ticker, period="6mo"). Sekarang panggil
    advanced_chart_cmd langsung dengan period="6mo"."""
    if not context.args:
        return await update.message.reply_text(
            "📈 *Trading Signals Chart*\n\n"
            "Usage: /signals BBCA\n\n"
            "Shows:\n"
            "• Golden/Death Cross signals\n"
            "• Oversold/Overbought alerts\n"
            "• Volume spikes\n"
            "• Buy/Sell entry points",
            parse_mode='Markdown'
        )

    ticker = context.args[0].upper() + ".JK"
    await update.message.reply_text(f"🔍 Analyzing {ticker.replace('.JK', '')} for trading signals...")

    df = await _download_and_clean(ticker, period="6mo")
    file = await _run_chart_in_thread(generate_advanced_chart, df, ticker)

    if file:
        with open(file, "rb") as f:
            await update.message.reply_photo(
                f,
                caption=f"🎯 *{ticker.replace('.JK', '')} - Trading Signals*\n\n"
                        f"✅ *Buy Signal when:*\n"
                        f"• Golden Cross (MA20 crosses above MA50)\n"
                        f"• RSI < 30 + bullish reversal candle\n"
                        f"• High volume breakout (1.5x normal)\n\n"
                        f"❌ *Sell Signal when:*\n"
                        f"• Death Cross (MA20 crosses below MA50)\n"
                        f"• RSI > 70 + bearish reversal candle\n"
                        f"• Price hits strong resistance\n\n"
                        f"{DISCLAIMER}",
                parse_mode='Markdown'
            )
        os.remove(file)
    else:
        await update.message.reply_text("❌ Failed to generate signals chart. Data insufficient (need at least 50 days).")


