# =========================
# HANDLER: INSIGHT
# =========================
# /insight KODE -- sintesis narasi rule-based dari AI Score (teknikal
# saham), konteks IHSG, dan berita.
# /insight IHSG (atau /insight tanpa argumen) -- sintesis narasi
# market-wide untuk IHSG itu sendiri, dengan narasi rotasi sektor.
# Lihat catatan metodologi lengkap di core/insight.py.

import asyncio

from core.async_yf import async_download
from core.stock_data import fix_yf_columns
from core.ai_score import calculate_ai_score_from_df
from core.relative_strength import calculate_relative_strength
from core.sector_rotation import get_sector_performance
from core.news import fetch_news
from core.insight import generate_insight, generate_market_insight

_IHSG_ALIASES = ("IHSG", "JKSE")


async def _download_and_clean(ticker: str, period: str = "6mo"):
    """Download dengan retry untuk mengatasi rate-limit Yahoo Finance
    (lihat catatan di handlers/stock_menu_handlers.py)."""
    import pandas as pd
    for attempt in range(3):
        try:
            df = await async_download(ticker, period=period, interval="1d", progress=False)
            if df is not None and not df.empty:
                df = fix_yf_columns(df)
                df = df.apply(pd.to_numeric, errors="coerce")
                df = df.dropna()
                if not df.empty:
                    return df
        except Exception:
            pass
        if attempt < 2:
            await asyncio.sleep(1.5 * (attempt + 1))
    return pd.DataFrame()


def format_insight_message(ticker_name: str, insight: dict) -> str:
    """Format hasil generate_insight()/generate_market_insight() jadi
    pesan Telegram -- SAMA untuk keduanya, karena struktur dict
    keduanya kompatibel (selalu ada 'narasi_lengkap')."""
    return f"""
🧩 *INSIGHT* - {ticker_name}
{'='*35}

{insight['narasi_lengkap']}

{'='*35}
⚠️ *CATATAN PENTING*
• Narasi ini disusun OTOMATIS dari kombinasi data teknikal, konteks pasar/sektor, dan berita -- BUKAN ditulis manusia, dan BUKAN analisis AI generatif (sistem berbasis aturan/kondisi sederhana).
• Ini BUKAN rekomendasi investasi atau saran beli/jual. Semua kalimat di atas bersifat deskriptif (menjelaskan KONDISI data saat ini), bukan instruksi tindakan.
• Selalu lakukan riset sendiri (DYOR) dan pertimbangkan profil risiko pribadi sebelum mengambil keputusan investasi.
"""


async def _run_market_insight(update):
    """Insight market-wide untuk IHSG -- DIPISAH dari insight per-saham
    karena membandingkan IHSG dengan dirinya sendiri tidak masuk akal
    (lihat catatan lengkap di core/insight.py generate_market_insight)."""
    await update.message.reply_text("🧩 Menyusun insight IHSG...")

    ihsg_df = await _download_and_clean("^JKSE", period="6mo")
    if len(ihsg_df) < 50:
        return await update.message.reply_text("❌ Data IHSG tidak cukup (minimal ~50 hari).")

    ai_ihsg = calculate_ai_score_from_df(ihsg_df)
    if ai_ihsg is None:
        return await update.message.reply_text("❌ Gagal menghitung AI Score untuk IHSG.")

    # Sektor & berita PARALEL -- keduanya independen, tidak saling tunggu
    sector_data, news_items = await asyncio.gather(
        get_sector_performance(period_days=5),
        fetch_news(keyword=None, limit=5),  # berita market umum, bukan filter per-kode
    )

    insight = await generate_market_insight(ai_ihsg, sector_data, news_items)
    msg = format_insight_message("IHSG", insight)
    await update.message.reply_text(msg, parse_mode='Markdown')


async def _run_stock_insight(update, ticker_arg: str):
    """Insight per-saham (alur existing, REVISI sebelumnya: konteks
    IHSG menggantikan fundamental)."""
    ticker = ticker_arg + ".JK"

    await update.message.reply_text(f"🧩 Menyusun insight {ticker_arg}...")

    df, ihsg_df = await asyncio.gather(
        _download_and_clean(ticker, period="6mo"),
        _download_and_clean("^JKSE", period="6mo"),
    )

    if len(df) < 50:
        return await update.message.reply_text(
            f"❌ Data historis {ticker_arg} tidak cukup (minimal ~50 hari)."
        )

    ai_score = calculate_ai_score_from_df(df)
    if ai_score is None:
        return await update.message.reply_text(f"❌ Gagal menghitung AI Score untuk {ticker_arg}.")

    ai_ihsg = None
    rs_data = None
    if len(ihsg_df) >= 50:
        ai_ihsg = calculate_ai_score_from_df(ihsg_df)
        rs_data = calculate_relative_strength(df, ihsg_df, period_days=20)

    news_items = await fetch_news(keyword=ticker_arg, limit=5)

    insight = await generate_insight(ticker_arg, ai_score, ai_ihsg, rs_data, news_items)
    msg = format_insight_message(ticker_arg, insight)
    await update.message.reply_text(msg, parse_mode='Markdown')


async def insight_cmd(update, context):
    """/insight [KODE] - Sintesis narasi teknikal + konteks pasar + berita.

    Tanpa argumen ATAU /insight IHSG -> insight market-wide IHSG.
    /insight KODE -> insight per-saham."""
    if not context.args or context.args[0].upper() in _IHSG_ALIASES:
        return await _run_market_insight(update)

    ticker_arg = context.args[0].upper()
    await _run_stock_insight(update, ticker_arg)
