# =========================
# HANDLERS: MARKET REPORT & ALERT
# =========================
# PERUBAHAN dari main.py lama:
# - Semua handler ini dulu loop SEQUENTIAL per-ticker; sekarang paralel
#   via core/market.py yang pakai async_download_many().
# - daily_cmd dan hotstock_cmd dulu memanggil run_bsjp_screener()/
#   run_screener() yang return STRING langsung. Sekarang fungsi-fungsi
#   itu return list of dict (core/screener.py), jadi handler ini yang
#   melakukan format_*_results() untuk dapat representasi teksnya.
# - alert_cmd DULU FITUR PALSU: cuma menampilkan "ALERT BERHASIL" tanpa
#   menyimpan apapun. SEKARANG BENAR-BENAR MENYIMPAN ke tabel price_alerts
#   (core/database.py) dan akan benar-benar dicek oleh job scheduler
#   (lihat jobs/notification_jobs.py) yang mengirim notifikasi nyata
#   ketika target price tercapai.

import os

from core.database import save_user_to_db, add_price_alert_db, get_active_price_alerts_db, remove_price_alert_db
from core.async_yf import async_download
from core.stock_data import fix_yf_columns, load_tickers
from core.market import (
    run_filter, format_filter_results, get_sector_performance,
    get_top_gainers, get_top_volume, get_top_losers, get_top_value,
)
from core.sector_rotation import get_sector_performance as get_sectoral_index_performance
from core.charts.heatmap_chart import generate_heatmap_chart
from core.screener import run_bsjp_screener, run_screener
from core.messages import format_screener_results, format_bsjp_screener_results

SCREENING_TICKER_LIMIT = 200
FILTER_TICKER_LIMIT = 150  # filter_cmd lebih berat (banyak indikator), limit lebih kecil


async def filter_cmd(update, context):
    if not context.args:
        return await update.message.reply_text(
            "📊 FILTER SAHAM (STRICT MODE)\n\n"
            "/filter bullish\n"
            "/filter breakout\n"
            "/filter volume\n"
            "/filter reversal\n\n"
            "Filter ketat:\n"
            "✓ Price > 500\n"
            "✓ Volume > 500.000\n"
            "✓ Minimal 50 data"
        )

    mode = context.args[0].lower()
    await update.message.reply_text(f"🔍 Scan filter {mode} (strict mode)...")

    tickers = load_tickers(limit=FILTER_TICKER_LIMIT)
    results = await run_filter(tickers, mode)
    msg = format_filter_results(results, mode)
    await update.message.reply_text(msg)


async def daily_cmd(update, context):
    await update.message.reply_text("📊 Membuat Daily Market Report...")

    sector_results = await get_sector_performance()

    if not sector_results:
        return await update.message.reply_text("❌ Gagal mengambil data sektor")

    market_avg = sum(s["change"] for s in sector_results) / len(sector_results)
    sentiment = "BULLISH 🟢" if market_avg > 0 else "BEARISH 🔴"

    msg = "📊 DAILY MARKET REPORT\n\n"
    msg += f"📈 MARKET SENTIMENT : {sentiment}\n\n"
    msg += "🔥 SECTOR PERFORMANCE\n\n"
    for s in sector_results:
        emoji = "🟢" if s["change"] > 0 else "🔴"
        msg += f"{emoji} {s['sector']} {s['change']}%\n"

    top_sector = sector_results[0]
    msg += f"\n🚀 HOT SECTOR : {top_sector['sector']}"
    msg += "\n\n🔥 HOT STOCK\n"

    tickers = load_tickers(limit=SCREENING_TICKER_LIMIT)
    bsjp_results = await run_bsjp_screener(tickers)
    bsjp_text = format_bsjp_screener_results(bsjp_results)
    msg += bsjp_text[:500]

    await update.message.reply_text(msg)


async def topgainer_cmd(update, context):
    await update.message.reply_text("🚀 Scan Top Gainer...")
    tickers = load_tickers(limit=SCREENING_TICKER_LIMIT)
    results = await get_top_gainers(tickers)

    msg = "🚀 TOP GAINER\n\n"
    for r in results[:10]:
        msg += f"{r['ticker']} | {r['change']}%\n"
    await update.message.reply_text(msg)


async def topvolume_cmd(update, context):
    await update.message.reply_text("📊 Scan Top Volume...")
    tickers = load_tickers(limit=SCREENING_TICKER_LIMIT)
    results = await get_top_volume(tickers)

    msg = "📊 TOP VOLUME\n\n"
    for r in results[:10]:
        msg += f"{r['ticker']} | {int(r['volume']):,}\n"
    await update.message.reply_text(msg)


async def toploser_cmd(update, context):
    """FITUR BARU. /toploser - kebalikan /topgainer, saham dengan
    penurunan harga terbesar."""
    await update.message.reply_text("📉 Scan Top Loser...")
    tickers = load_tickers(limit=SCREENING_TICKER_LIMIT)
    results = await get_top_losers(tickers)

    msg = "📉 TOP LOSER\n\n"
    for r in results[:10]:
        msg += f"{r['ticker']} | {r['change']}%\n"
    await update.message.reply_text(msg)


async def topvalue_cmd(update, context):
    """FITUR BARU. /topvalue - ranking nilai transaksi (harga x volume).
    PENGGANTI NAMA untuk /TOPFREQ (lihat catatan keputusan di
    core/market.py: get_top_value -- data frekuensi transaksi tidak
    tersedia di yfinance, nilai transaksi yang bisa dihitung)."""
    await update.message.reply_text("💰 Scan Top Value...")
    tickers = load_tickers(limit=SCREENING_TICKER_LIMIT)
    results = await get_top_value(tickers)

    msg = "💰 TOP VALUE (Nilai Transaksi)\n\n"
    for r in results[:10]:
        msg += f"{r['ticker']} | Rp{r['value']:,.0f}\n"
    await update.message.reply_text(msg)


async def heatmap_cmd(update, context):
    """/heatmap - Heatmap visual performa 11 sektor resmi IDX-IC.
    FITUR BARU. Memakai get_sector_performance dari core/sector_rotation.py
    (DIIMPOR DENGAN ALIAS get_sectoral_index_performance di file ini --
    nama fungsi ini KEBETULAN SAMA dengan get_sector_performance yang
    sudah ada di core/market.py, padahal keduanya BERBEDA: yang di
    core/market.py menghitung rata-rata 6 kategori SECTOR_MAP ad-hoc
    untuk /daily, sementara yang dipakai di sini menghitung 11 indeks
    sektoral resmi IDX-IC untuk /sektor & /heatmap. Alias dipakai
    supaya tidak ambigu di file ini, TANPA mengubah nama fungsi
    aslinya di kedua modul (mengubahnya berisiko menyentuh fitur
    /daily yang sudah berjalan)."""
    await update.message.reply_text("🗺️ Membuat heatmap sektor...")

    sector_results = await get_sectoral_index_performance(period_days=5)

    if not sector_results:
        return await update.message.reply_text("❌ Gagal mengambil data sektor.")

    chart_file = generate_heatmap_chart(sector_results)

    if chart_file and os.path.exists(chart_file):
        with open(chart_file, "rb") as f:
            await update.message.reply_photo(
                f,
                caption="🗺️ *Heatmap Performa Sektor (5 Hari)*\nHijau = menguat, Merah = melemah. Berdasarkan 11 indeks sektoral resmi IDX-IC.",
                parse_mode='Markdown'
            )
        os.remove(chart_file)
    else:
        await update.message.reply_text("❌ Gagal membuat heatmap.")


async def hotstock_cmd(update, context):
    await update.message.reply_text("🔥 Scan Hot Stock...")
    tickers = load_tickers(limit=SCREENING_TICKER_LIMIT)

    signal_results = await run_screener(tickers)
    bsjp_results = await run_bsjp_screener(tickers)

    signal_text = format_screener_results(signal_results)
    bsjp_text = format_bsjp_screener_results(bsjp_results)

    msg = "🔥 HOT STOCK\n\nGabungan Signal + BSJP\n\n"
    msg += signal_text[:700]
    msg += "\n\n"
    msg += bsjp_text[:700]
    await update.message.reply_text(msg)


async def alert_cmd(update, context):
    """/alert BBCA 9500 - Set alert harga custom.

    DULU FITUR PALSU (cuma tampilkan pesan tanpa menyimpan apapun).
    SEKARANG: benar-benar menyimpan ke price_alerts, dan job scheduler
    (jobs/notification_jobs.py) akan benar-benar mengecek & mengirim
    notifikasi saat target tercapai."""
    if len(context.args) < 2:
        return await update.message.reply_text(
            "/alert BBCA 9500\n\n"
            "Bot akan memberi notifikasi saat harga BBCA mencapai/melewati Rp9.500\n"
            "Gunakan /myalerts untuk lihat alert aktif\n"
            "Gunakan /removealert [id] untuk hapus alert"
        )

    user_id = str(update.effective_user.id)
    username = update.effective_user.username or ""
    save_user_to_db(user_id, username)

    stock = context.args[0].upper()
    try:
        target = float(context.args[1])
    except ValueError:
        return await update.message.reply_text("❌ Target harga harus berupa angka. Contoh: /alert BBCA 9500")

    # Tentukan direction berdasarkan harga saat ini vs target
    try:
        df = await async_download(stock + ".JK", period="2d", interval="1d", progress=False)
        df = fix_yf_columns(df).dropna()
        current_price = float(df["Close"].iloc[-1]) if not df.empty else None
    except Exception:
        current_price = None

    if current_price is None:
        return await update.message.reply_text(f"❌ Gagal mengambil harga {stock}. Cek kode saham.")

    direction = "above" if target > current_price else "below"
    add_price_alert_db(user_id, stock, target, direction)

    arah_text = "naik ke / melewati" if direction == "above" else "turun ke / di bawah"
    msg = (
        "🔔 ALERT BERHASIL DISIMPAN\n\n"
        f"Saham : {stock}\n"
        f"Harga sekarang : Rp{current_price:,.0f}\n"
        f"Target : Rp{target:,.0f} ({arah_text})\n\n"
        "Bot akan cek otomatis setiap jam dan kirim notifikasi saat target tercapai."
    )
    await update.message.reply_text(msg)


async def myalerts_cmd(update, context):
    """/myalerts - Lihat semua price alert aktif milik user."""
    user_id = str(update.effective_user.id)
    alerts = get_active_price_alerts_db(user_id)

    if not alerts:
        return await update.message.reply_text("📭 Tidak ada alert aktif.\n\nBuat dengan: /alert BBCA 9500")

    msg = "🔔 *ALERT AKTIF*\n\n"
    for a in alerts:
        arah = "≥" if a["direction"] == "above" else "≤"
        msg += f"#{a['id']} {a['ticker']} {arah} Rp{a['target_price']:,.0f}\n"
    msg += "\nHapus dengan: /removealert [id]"
    await update.message.reply_text(msg, parse_mode="Markdown")


async def removealert_cmd(update, context):
    """/removealert [id] - Hapus price alert."""
    if not context.args:
        return await update.message.reply_text("Contoh: /removealert 3\n\nLihat ID dengan /myalerts")

    user_id = str(update.effective_user.id)
    try:
        alert_id = int(context.args[0])
    except ValueError:
        return await update.message.reply_text("❌ ID harus berupa angka")

    remove_price_alert_db(user_id, alert_id)
    await update.message.reply_text(f"✅ Alert #{alert_id} dihapus (kalau memang milik Anda)")
