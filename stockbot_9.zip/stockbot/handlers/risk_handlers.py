# =========================
# HANDLERS: RISK MANAGEMENT
# =========================
# FITUR BARU. /rr, /target, /cutloss, /positionsize -- memakai
# core/risk_management.py (lihat catatan krusial soal satuan LOT IDX
# dan pembulatan ke bawah di file itu).
#
# /rr dan /positionsize TIDAK butuh download data (kalkulasi murni
# dari input user), jadi keduanya responsif instan. /target dan
# /cutloss butuh data historis (Fibonacci/SR, ATR).

from core.async_yf import async_download
from core.stock_data import fix_yf_columns
from core.risk_management import (
    calculate_risk_reward, calculate_target_levels, calculate_cutloss_levels, calculate_position_size,
)


async def _download_and_clean(ticker: str, period: str = "6mo"):
    import pandas as pd
    df = await async_download(ticker, period=period, interval="1d", progress=False)
    df = fix_yf_columns(df)
    df = df.apply(pd.to_numeric, errors="coerce")
    df = df.dropna()
    return df


async def rr_cmd(update, context):
    """/rr ENTRY STOPLOSS TAKEPROFIT - Hitung rasio risk/reward."""
    if not context.args or len(context.args) < 3:
        return await update.message.reply_text(
            "Usage: /rr ENTRY STOPLOSS TAKEPROFIT\n"
            "Contoh: /rr 5000 4800 5600\n\n"
            "(Untuk posisi short: TAKEPROFIT di bawah ENTRY, contoh: /rr 5000 5200 4400)"
        )

    try:
        entry = float(context.args[0])
        stop_loss = float(context.args[1])
        take_profit = float(context.args[2])
    except ValueError:
        return await update.message.reply_text("❌ Pastikan ENTRY, STOPLOSS, TAKEPROFIT berupa angka.")

    result = calculate_risk_reward(entry, stop_loss, take_profit)
    if result is None:
        return await update.message.reply_text("❌ ENTRY dan STOPLOSS tidak boleh sama (akan membagi dengan nol).")

    arah = "LONG (Beli)" if result["is_long"] else "SHORT (Jual)"
    rr = result["rr_ratio"]
    rr_label = "✅ BAGUS (≥2:1)" if rr >= 2 else "⚠️ KURANG IDEAL (<2:1)" if rr > 0 else "❌ TIDAK MASUK AKAL"

    msg = f"""
⚖️ *RISK/REWARD CALCULATOR*
{'='*35}

Arah posisi: {arah}
Entry: Rp{entry:,.0f}
Stop Loss: Rp{stop_loss:,.0f}
Take Profit: Rp{take_profit:,.0f}

Risk per lembar: Rp{result['risk_per_share']:,.0f} ({result['risk_pct']}%)
Reward per lembar: Rp{result['reward_per_share']:,.0f} ({result['reward_pct']}%)

📊 *Rasio R:R = 1:{rr}*
{rr_label}

💡 Idealnya cari setup dengan R:R minimal 1:2 -- supaya satu kali profit bisa menutup 2x kerugian beruntun.
"""
    await update.message.reply_text(msg, parse_mode='Markdown')


def format_target_message(ticker_name: str, t: dict) -> str:
    return f"""
🎯 *TARGET HARGA* - {ticker_name}
{'='*35}

Harga sekarang: Rp{t['current_price']:,.0f}
Pivot point: Rp{t['pivot']:,.0f}

🔼 *RESISTANCE (target naik)*
├─ R1: Rp{t['resistance_levels'][0]:,.0f}
├─ R2: Rp{t['resistance_levels'][1]:,.0f}
└─ R3: Rp{t['resistance_levels'][2]:,.0f}

🔽 *SUPPORT (target turun)*
├─ S1: Rp{t['support_levels'][0]:,.0f}
├─ S2: Rp{t['support_levels'][1]:,.0f}
└─ S3: Rp{t['support_levels'][2]:,.0f}

📊 *REFERENSI TAMBAHAN*
├─ High 20 hari: Rp{t['high_20d']:,.0f}
└─ High 50 hari: Rp{t['high_50d']:,.0f}

💡 R1/S1 = target terdekat (lebih sering tercapai). R3/S3 = target jauh (lebih jarang tercapai, tapi reward lebih besar kalau kena).
"""


def format_cutloss_message(ticker_name: str, c: dict) -> str:
    return f"""
🛑 *AREA CUT LOSS* - {ticker_name}
{'='*35}

Harga sekarang: Rp{c['current_price']:,.0f}
Volatilitas (ATR): Rp{c['atr']:,.0f} ({c['atr_pct']}% dari harga)

🟡 *KONSERVATIF (1.5x ATR)*
├─ Cut loss: Rp{c['cutloss_conservative']:,.0f}
└─ Jarak: -{c['conservative_distance_pct']}%

🔴 *AGRESIF (2.5x ATR)*
├─ Cut loss: Rp{c['cutloss_aggressive']:,.0f}
└─ Jarak: -{c['aggressive_distance_pct']}%

💡 Konservatif = stop lebih rapat, lebih sering kena tapi kerugian per kena lebih kecil. Agresif = stop lebih lebar, lebih jarang kena (mengurangi noise) tapi kerugian per kena lebih besar. Pilih sesuai gaya trading, bukan berdasarkan mana yang "lebih aman" secara mutlak.
"""


async def target_cmd(update, context):
    """/target KODE - Target harga via Support/Resistance + Fibonacci."""
    if not context.args:
        return await update.message.reply_text("Usage: /target BBCA")

    ticker = context.args[0].upper() + ".JK"
    ticker_name = ticker.replace(".JK", "")
    df = await _download_and_clean(ticker, period="6mo")

    if len(df) < 20:
        return await update.message.reply_text(f"❌ Data {ticker_name} tidak cukup (minimal ~20 hari).")

    t = calculate_target_levels(df)
    msg = format_target_message(ticker_name, t)
    await update.message.reply_text(msg, parse_mode='Markdown')


async def cutloss_cmd(update, context):
    """/cutloss KODE - Area cut loss ideal berbasis ATR."""
    if not context.args:
        return await update.message.reply_text("Usage: /cutloss BBCA")

    ticker = context.args[0].upper() + ".JK"
    ticker_name = ticker.replace(".JK", "")
    df = await _download_and_clean(ticker, period="6mo")

    if len(df) < 20:
        return await update.message.reply_text(f"❌ Data {ticker_name} tidak cukup (minimal ~20 hari).")

    c = calculate_cutloss_levels(df)
    msg = format_cutloss_message(ticker_name, c)
    await update.message.reply_text(msg, parse_mode='Markdown')


async def positionsize_cmd(update, context):
    """/positionsize MODAL RISIKO% ENTRY CUTLOSS - Kalkulasi jumlah lot."""
    if not context.args or len(context.args) < 4:
        return await update.message.reply_text(
            "Usage: /positionsize MODAL RISIKO% ENTRY CUTLOSS\n"
            "Contoh: /positionsize 10000000 1 5000 4800\n"
            "(Modal Rp10jt, risiko 1%, entry Rp5000, cutloss Rp4800)"
        )

    try:
        modal = float(context.args[0])
        risk_pct = float(context.args[1])
        entry = float(context.args[2])
        stop_loss = float(context.args[3])
    except ValueError:
        return await update.message.reply_text("❌ Pastikan semua parameter berupa angka.")

    result = calculate_position_size(modal, risk_pct, entry, stop_loss)
    if result is None:
        return await update.message.reply_text("❌ Periksa input: ENTRY tidak boleh sama dengan CUTLOSS, MODAL dan RISIKO% harus lebih besar dari 0.")

    if result["warning"]:
        return await update.message.reply_text(f"⚠️ *POSITION SIZE*\n\n{result['warning']}", parse_mode='Markdown')

    msg = f"""
💰 *POSITION SIZE CALCULATOR*
{'='*35}

Modal: Rp{modal:,.0f}
Risiko: {risk_pct}% = Rp{modal * risk_pct / 100:,.0f}
Entry: Rp{entry:,.0f}
Cut loss: Rp{stop_loss:,.0f}

📊 *HASIL*
├─ Jumlah: *{result['n_lots']} lot* ({result['actual_shares']:,} lembar)
├─ Nilai posisi: Rp{result['actual_value']:,.0f}
├─ Risiko sesungguhnya: Rp{result['actual_risk_amount']:,.0f} ({result['actual_risk_pct']}% dari modal)
└─ (Dibulatkan ke bawah ke kelipatan 1 lot/100 lembar sesuai aturan BEI)

💡 Risiko sesungguhnya ({result['actual_risk_pct']}%) sedikit di bawah target ({risk_pct}%) karena pembulatan ke bawah -- ini DISENGAJA supaya risiko tidak pernah melebihi yang kamu rencanakan.
"""
    await update.message.reply_text(msg, parse_mode='Markdown')
