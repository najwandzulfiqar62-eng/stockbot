# =========================
# HANDLER: COMPARE SAHAM
# =========================
# REDESIGN (Juni 2026). Sebelumnya compare_cmd ada di
# handlers/trading_plan_handlers.py (tercampur dengan handler tidak
# terkait) memakai scoring lama yang sederhana (0-4, 4 kondisi) tanpa
# visual. Dipindah ke file sendiri + scoring REUSE dari AI Score
# (core/ai_score.py, supaya konsisten dengan /aiscore) + chart visual
# perbandingan (core/charts/compare_chart.py). Lihat catatan metodologi
# lengkap di core/compare.py.

import asyncio
import os

from core.async_yf import async_download
from core.stock_data import fix_yf_columns
from core.compare import analyze_for_compare, format_compare_message, calculate_relative_performance
from core.charts.compare_chart import generate_compare_chart


async def _download_and_clean(ticker: str, period: str = "6mo"):
    """Download dengan retry untuk mengatasi rate-limit Yahoo Finance
    (lihat catatan di handlers/stock_menu_handlers.py)."""
    import pandas as pd
    for attempt in range(3):
        try:
            df = await async_download(ticker, period=period, interval="1d", progress=False)
            if df is not None and not df.empty:
                df = fix_yf_columns(df)
                df = df.apply(pd.to_numeric, errors="coerce")
                df = df.dropna()
                if not df.empty:
                    return df
        except Exception:
            pass
        if attempt < 2:
            await asyncio.sleep(1.5 * (attempt + 1))

    return pd.DataFrame()


async def compare_cmd(update, context):
    """/compare KODE1 KODE2 - Bandingkan dua saham (AI Score + chart visual)."""
    if len(context.args) < 2:
        return await update.message.reply_text(
            "Usage: /compare BBCA BBRI\n\n"
            "Membandingkan dua saham: AI Score, RSI, volume, dan performa "
            "20 hari terakhir, dilengkapi chart visual."
        )

    stock1 = context.args[0].upper() + ".JK"
    stock2 = context.args[1].upper() + ".JK"
    name1 = stock1.replace(".JK", "")
    name2 = stock2.replace(".JK", "")

    await update.message.reply_text(f"📊 Membandingkan {name1} vs {name2}...")

    df1, df2 = await asyncio.gather(
        _download_and_clean(stock1),
        _download_and_clean(stock2),
    )

    s1 = analyze_for_compare(df1) if len(df1) >= 50 else None
    s2 = analyze_for_compare(df2) if len(df2) >= 50 else None

    if s1 is None or s2 is None:
        missing = name1 if s1 is None else name2
        return await update.message.reply_text(
            f"❌ Data {missing} tidak cukup untuk analisis (minimal ~50 hari histori). "
            "Coba saham lain atau pastikan kode saham benar."
        )

    rel_perf = calculate_relative_performance(df1, df2, period_days=20)

    chart_file = await asyncio.to_thread(
        generate_compare_chart, df1, df2, name1, name2, s1, s2
    )
    if chart_file and os.path.exists(chart_file):
        with open(chart_file, "rb") as f:
            await update.message.reply_photo(
                f, caption=f"📊 {name1} vs {name2} — Comparison Chart"
            )
        os.remove(chart_file)

    msg = format_compare_message(stock1, stock2, s1, s2, rel_perf)
    await update.message.reply_text(msg, parse_mode='Markdown')
