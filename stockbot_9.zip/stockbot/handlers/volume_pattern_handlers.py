# =========================
# HANDLERS: VOLUME PATTERNS
# =========================
# FITUR BARU. /volumespike, /adline -- lihat catatan lengkap soal
# keputusan penamaan ulang & konsolidasi 6 command institusional jadi
# 2 command jujur di core/volume_patterns.py.

from core.async_yf import async_download
from core.stock_data import fix_yf_columns
from core.volume_patterns import detect_volume_spikes, calculate_ad_line

VOLUME_DISCLAIMER = (
    "\n\n⚠️ _Ini pola volume & harga dari data publik, BUKAN data transaksi institusi/bandar "
    "sungguhan -- tidak ada cara memverifikasi siapa yang benar-benar bertransaksi di balik volume ini._"
)


async def _download_and_clean(ticker: str, period: str = "3mo"):
    import pandas as pd
    df = await async_download(ticker, period=period, interval="1d", progress=False)
    df = fix_yf_columns(df)
    df = df.apply(pd.to_numeric, errors="coerce")
    df = df.dropna()
    return df


def format_volumespike_message(ticker_name: str, result: dict) -> str:
    if not result["spikes"]:
        return (
            f"📊 *VOLUME SPIKE* - {ticker_name}\n\n"
            f"Tidak ada lonjakan volume signifikan (>2x rata-rata 20 hari) dalam 10 hari terakhir."
        ) + VOLUME_DISCLAIMER

    msg = f"📊 *VOLUME SPIKE* - {ticker_name}\n{'='*35}\n\n"
    msg += f"Rata-rata volume 20 hari: {result['avg_volume_20']:,.0f}\n\n"
    for s in result["spikes"]:
        date_str = s['date'].strftime('%Y-%m-%d') if hasattr(s['date'], 'strftime') else str(s['date'])
        msg += (
            f"📅 {date_str}\n"
            f"   Volume: {s['volume']:,.0f} ({s['vol_ratio']}x rata-rata)\n"
            f"   Perubahan harga: {s['price_change_pct']:+.2f}%\n"
            f"   {s['arah']}\n\n"
        )

    msg += "💡 Volume tinggi + harga naik = minat beli kuat. Volume tinggi + harga turun = minat jual kuat. Volume tinggi + harga flat = ada aktivitas besar tapi belum jelas arahnya."
    return msg + VOLUME_DISCLAIMER


def format_adline_message(ticker_name: str, result: dict) -> str:
    return f"""
📈 *ACCUMULATION/DISTRIBUTION LINE* - {ticker_name}
{'='*35}

A/D Line trend ({result['lookback_days']} hari): {result['ad_trend_pct']:+.1f}%
Harga trend ({result['lookback_days']} hari): {result['price_trend_pct']:+.1f}%

CLV candle terakhir: {result['last_clv']} ({result['clv_label']})

{result['sinyal']}

💡 Chaikin A/D Line: indikator klasik yang menggabungkan posisi close dalam range candle (CLV) dengan volume. Divergensi antara harga dan A/D Line sering dipakai sebagai sinyal peringatan dini sebelum reversal.
""" + VOLUME_DISCLAIMER


async def volumespike_cmd(update, context):
    """/volumespike KODE - Histori lonjakan volume vs rata-rata."""
    if not context.args:
        return await update.message.reply_text("Usage: /volumespike BBCA")

    ticker = context.args[0].upper() + ".JK"
    ticker_name = ticker.replace(".JK", "")
    df = await _download_and_clean(ticker, period="3mo")

    if len(df) < 20:
        return await update.message.reply_text(f"❌ Data {ticker_name} tidak cukup (minimal ~20 hari).")

    result = detect_volume_spikes(df, lookback_days=10, threshold_multiplier=2.0)
    msg = format_volumespike_message(ticker_name, result)
    await update.message.reply_text(msg, parse_mode='Markdown')


async def adline_cmd(update, context):
    """/adline KODE - Chaikin Accumulation/Distribution Line."""
    if not context.args:
        return await update.message.reply_text("Usage: /adline BBCA")

    ticker = context.args[0].upper() + ".JK"
    ticker_name = ticker.replace(".JK", "")
    df = await _download_and_clean(ticker, period="3mo")

    result = calculate_ad_line(df, lookback_days=20)
    if result is None:
        return await update.message.reply_text(f"❌ Data {ticker_name} tidak cukup (minimal ~25 hari).")

    msg = format_adline_message(ticker_name, result)
    await update.message.reply_text(msg, parse_mode='Markdown')
