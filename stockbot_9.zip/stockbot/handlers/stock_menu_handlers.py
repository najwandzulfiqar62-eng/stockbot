# =========================
# HANDLERS: MENU SAHAM (KETIK LANGSUNG + TOMBOL INLINE)
# =========================
# PERUBAHAN dari main.py lama:
# - stock_menu_callback DULU DIDEFINISIKAN DUA KALI (baris 5338 dan 5492
#   di main.py lama). Definisi pertama menangani action: plan, chart, snr,
#   ml, wl_add, wl_check, info. Definisi kedua (yang menang, karena
#   didefinisikan belakangan menimpa nama fungsi yang sama) menangani
#   SEMUA action dari definisi pertama PLUS ranah, aiscore, airank_menu.
#   Jadi definisi pertama adalah kode mati sepenuhnya redundan -- tidak
#   ada action unik yang hilang akibat duplikasi ini (sudah diverifikasi
#   dengan membaca kedua definisi lengkap). Dikonsolidasikan jadi SATU
#   fungsi di sini yang mencakup semua action.
# - Setiap action (plan, chart, snr, ml, info) dulu memanggil fungsi
#   sinkron yang download+proses sekaligus. Sekarang dipisah: download
#   via async_download (non-blocking), kalkulasi/chart via modul
#   core/* yang sudah diverifikasi numerik sebelumnya.

import os
import asyncio

from telegram import InlineKeyboardButton, InlineKeyboardMarkup

from core.database import (
    get_user_watchlist_db, get_fixed_entries_db, add_to_watchlist_db,
)
from core.async_yf import async_download
from core.stock_data import fix_yf_columns, load_tickers
from core.indicators import calculate_rsi
from core.trading_plan import calculate_fixed_entry_levels_from_df
from core.charts.advanced_chart import generate_advanced_chart
from core.charts.snr_chart import generate_snr
from core.charts.ta_chart import generate_ta_chart
from core.messages import split_long_message

from datetime import datetime


async def _download_and_clean(ticker: str, period: str = "6mo"):
    """Download dengan retry untuk mengatasi rate-limit Yahoo Finance
    (error 'Expecting value: line 1 column 1' adalah isu umum yfinance
    saat rate-limited, bukan bug spesifik bot ini -- lihat GitHub
    ranaroussi/yfinance issue #2179/#2520/#2521)."""
    import asyncio as _asyncio
    import pandas as pd

    for attempt in range(3):
        try:
            df = await async_download(ticker, period=period, interval="1d", progress=False)
            if df is not None and not df.empty:
                df = fix_yf_columns(df)
                df = df.apply(pd.to_numeric, errors="coerce")
                df = df.dropna()
                if not df.empty:
                    return df
        except Exception:
            pass
        if attempt < 2:
            await _asyncio.sleep(1.5 * (attempt + 1))

    return pd.DataFrame()  # kosong setelah semua percobaan gagal


async def show_stock_menu(message, stock: str, price_info: str = ""):
    """Menampilkan menu untuk saham tertentu (tidak mengedit pesan yang sama)."""
    keyboard = [
        [
            InlineKeyboardButton("🧠 RANAH AI", callback_data=f"ranah_{stock}"),
            InlineKeyboardButton("📈 TRADING PLAN", callback_data=f"plan_{stock}"),
        ],
        [
            InlineKeyboardButton("📊 ADVANCED CHART", callback_data=f"chart_{stock}"),
            InlineKeyboardButton("📉 SNR CHART", callback_data=f"snr_{stock}"),
        ],
        [
            InlineKeyboardButton("📊 TA CHART", callback_data=f"ml_{stock}"),
            InlineKeyboardButton("⭐ ADD TO WATCHLIST", callback_data=f"wl_add_{stock}"),
        ],
        [
            InlineKeyboardButton("📋 CHECK STATUS", callback_data=f"wl_check_{stock}"),
            InlineKeyboardButton("📊 QUICK INFO", callback_data=f"info_{stock}"),
        ],
        [
            InlineKeyboardButton("🎯 AI SCORE BREAKDOWN", callback_data=f"aiscore_{stock}"),
            InlineKeyboardButton("🏆 AI RANKING", callback_data="airankmenu"),
        ],
        [
            InlineKeyboardButton("📊 BACKTEST SINYAL", callback_data=f"backtest_{stock}"),
            InlineKeyboardButton("💪 RELATIVE STRENGTH", callback_data=f"rs_{stock}"),
        ],
        [
            InlineKeyboardButton("📐 BOS", callback_data=f"bos_{stock}"),
            InlineKeyboardButton("🔄 CHOCH", callback_data=f"choch_{stock}"),
        ],
        [
            InlineKeyboardButton("🟦 ORDER BLOCK", callback_data=f"orderblock_{stock}"),
            InlineKeyboardButton("📏 FVG", callback_data=f"fvg_{stock}"),
        ],
        [
            InlineKeyboardButton("💧 LIQUIDITY POOL", callback_data=f"liquidity_{stock}"),
        ],
        [
            InlineKeyboardButton("🎯 TARGET HARGA", callback_data=f"target_{stock}"),
            InlineKeyboardButton("🛑 AREA CUT LOSS", callback_data=f"cutloss_{stock}"),
        ],
        [
            InlineKeyboardButton("📈 BETA vs IHSG", callback_data=f"beta_{stock}"),
        ],
        [
            InlineKeyboardButton("📊 VOLUME SPIKE", callback_data=f"volumespike_{stock}"),
            InlineKeyboardButton("📈 A/D LINE", callback_data=f"adline_{stock}"),
        ],
        [
            InlineKeyboardButton("📰 BERITA", callback_data=f"news_{stock}"),
            InlineKeyboardButton("📊 FUNDAMENTAL", callback_data=f"fundamental_{stock}"),
        ],
        [
            InlineKeyboardButton("🧩 INSIGHT", callback_data=f"insight_{stock}"),
            InlineKeyboardButton("📄 LAPORAN PDF", callback_data=f"laporan_{stock}"),
        ],
    ]

    caption = f"📌 *{stock}*\n{price_info}\n\n👇 *PILIH MENU:*"
    await message.reply_text(caption, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown')


async def stock_direct_handler(update, context):
    """Menangkap input user yang bukan command (langsung ketik kode saham).
    Contoh: user ketik "BBCA" maka akan muncul menu untuk BBCA."""
    text = update.message.text.strip().upper()

    if not text.isalpha() or len(text) < 2 or len(text) > 4:
        return  # Bukan kode saham, abaikan

    tickers = load_tickers()
    stock_codes = [t.replace(".JK", "") for t in tickers]

    if text not in stock_codes:
        matches = [s for s in stock_codes if s.startswith(text) or text in s]
        if len(matches) == 1:
            text = matches[0]
        elif len(matches) > 1:
            return await update.message.reply_text(
                f"🔍 *Banyak saham dengan kode '{text}':*\n"
                f"{', '.join(matches[:10])}\n\n"
                f"Ketik kode lengkapnya."
            )
        else:
            return  # Saham tidak ditemukan

    price_info = ""
    try:
        df = await _download_and_clean(text + ".JK", period="2d")
        if len(df) >= 2:
            price = float(df["Close"].iloc[-1])
            prev = float(df["Close"].iloc[-2])
            change = ((price / prev) - 1) * 100
            emoji = "🟢" if change >= 0 else "🔴"
            price_info = f"💰 Harga: Rp{price:,.0f} {emoji} ({change:+.2f}%)"
    except Exception:
        pass

    await show_stock_menu(update.message, text, price_info)


async def stock_menu_callback(update, context):
    """Handle tombol dari menu saham. Konsolidasi dari 2 definisi
    duplikat di main.py lama (lihat catatan di atas file ini)."""
    query = update.callback_query

    # query.answer() CUMA acknowledgment UI (menghilangkan loading
    # spinner di tombol Telegram) -- BUKAN bagian penting dari logic
    # fungsional handler ini. BUG NYATA ditemukan & diperbaiki (Juni
    # 2026): sebelumnya TIDAK dibungkus try/except -- kalau koneksi
    # user ke server Telegram lagi tidak stabil (httpx.ConnectTimeout
    # -> telegram.error.TimedOut, dikonfirmasi dari traceback user),
    # SELURUH handler langsung crash di baris ini SEBELUM sempat
    # melakukan pekerjaan sesungguhnya (download data, hitung skor,
    # dst) -- user cuma dapat pesan error generic tanpa tahu kenapa,
    # padahal masalahnya cuma di acknowledgment UI yang non-esensial.
    # Sekarang: kalau answer() gagal, tetap lanjut proses tombolnya --
    # efek sampingnya PALING BURUK cuma loading spinner di tombol
    # Telegram user sedikit lebih lama, BUKAN seluruh aksi gagal.
    try:
        await query.answer()
    except Exception as e:
        print(f"⚠️ query.answer() gagal (lanjut proses tombol seperti biasa): {e}")

    data = query.data
    parts = data.split("_", 1)
    action = parts[0]
    user_id = str(query.from_user.id)

    # ===== RANAH AI =====
    if action == "ranah":
        stock = parts[1]
        from handlers.ai_score_handlers import _run_ranah_analysis

        # query.message punya interface .reply_text()/.reply_photo()
        # yang SAMA dengan update.message -- aman dipakai langsung
        # (REFACTOR Juni 2026, sebelumnya logic ini diduplikasi penuh
        # di sini, termasuk bug "/signal" framing yang menyesatkan --
        # lihat catatan lengkap di handlers/ai_score_handlers.py).
        await _run_ranah_analysis(query, stock)
        await query.message.reply_text(f"💡 Ketik *{stock}* lagi untuk kembali ke menu", parse_mode='Markdown')

    # ===== AI SCORE BREAKDOWN =====
    elif action == "aiscore":
        stock = parts[1]
        from handlers.ai_score_handlers import _run_aiscore_breakdown

        await _run_aiscore_breakdown(query, stock)
        await query.message.reply_text(f"💡 Ketik *{stock}* lagi untuk kembali ke menu", parse_mode='Markdown')

    # ===== AI RANKING MENU =====
    # CATATAN BUG NYATA DITEMUKAN & DIPERBAIKI (Juni 2026): callback_data
    # SEBELUMNYA "airank_menu" (dengan underscore) -- tapi parsing di
    # atas (`data.split("_", 1)`) didesain untuk pola "action_ticker"
    # (SATU underscore pemisah), jadi "airank_menu".split("_", 1)
    # menghasilkan action="airank" (BUKAN "airank_menu")! Kondisi
    # `elif action == "airank_menu"` di bawah ini TIDAK PERNAH match --
    # tombol "AI RANKING" di menu SUDAH LAMA TIDAK BERFUNGSI (klik
    # tombolnya jatuh tanpa match ke elif manapun, silent no-op).
    # DIPERBAIKI dengan mengganti callback_data jadi "airankmenu" (TANPA
    # underscore) supaya tidak ambigu dengan skema parsing "action_ticker".
    elif action == "airankmenu":
        from handlers.ai_score_handlers import airank_cmd

        # airank_cmd(update, context) TIDAK memakai context.args sama
        # sekali (ranking seluruh universe saham, bukan per-ticker) --
        # aman dipanggil langsung dengan query sebagai pengganti update
        # (REFACTOR Juni 2026, menghilangkan duplikasi logic + bug
        # "/signal" framing yang sebelumnya ada di sini).
        await airank_cmd(query, context)

    # ===== TRADING PLAN + CHART =====
    elif action == "plan":
        stock = parts[1]
        await query.message.reply_text(f"📈 *Membuat Trading Plan + Chart untuk {stock}...*", parse_mode='Markdown')

        from core.trading_plan import calculate_advanced_plan_from_df
        from core.charts.trading_plan_chart import generate_trading_plan_chart
        from handlers.trading_plan_handlers import _format_advanced_plan_message

        df = await _download_and_clean(stock + ".JK")
        plan = calculate_advanced_plan_from_df(df, stock + ".JK")

        if plan is None:
            return await query.message.reply_text(f"❌ Data tidak cukup untuk analisis akurat {stock}")

        entry_levels = {k: v["entry"] for k, v in plan["scenarios"].items()}
        sl_levels = {k: v["sl"] for k, v in plan["scenarios"].items()}
        tp_levels = {k: {"tp1": v["tp"]["tp1"], "tp2": v["tp"]["tp2"], "tp3": v["tp"]["tp3"],
                          "rr1": v["tp"]["rr1"], "rr2": v["tp"]["rr2"], "rr3": v["tp"]["rr3"]}
                     for k, v in plan["scenarios"].items()}

        chart_file = await asyncio.to_thread(
            generate_trading_plan_chart, df, stock + ".JK", plan["sr"], plan["current_price"],
            plan["atr"], entry_levels, tp_levels, sl_levels,
        )

        if chart_file and os.path.exists(chart_file):
            with open(chart_file, "rb") as f:
                await query.message.reply_photo(
                    f,
                    caption=f"📊 *{stock} - Trading Plan Chart*\n"
                            f"🟢 Area biru = Zona Akumulasi (Support)\n"
                            f"🔴 Area merah = Zona Distribusi (Resistance)\n"
                            f"💡 Harga di S1-S2 = area beli yang aman",
                    parse_mode='Markdown'
                )
            os.remove(chart_file)
        else:
            await query.message.reply_text("⚠️ Gagal membuat chart, tapi trading plan tetap tersedia")

        msg = _format_advanced_plan_message(plan)
        for chunk in split_long_message(msg):
            await query.message.reply_text(chunk)

        await query.message.reply_text(f"💡 Ketik *{stock}* lagi untuk kembali ke menu", parse_mode='Markdown')

    # ===== ADVANCED CHART =====
    elif action == "chart":
        stock = parts[1]
        await query.message.reply_text(f"📊 *Membuat Advanced Chart untuk {stock}...*", parse_mode='Markdown')

        df = await _download_and_clean(stock + ".JK", period="3mo")
        file = await asyncio.to_thread(generate_advanced_chart, df, stock + ".JK")

        if file and os.path.exists(file):
            with open(file, "rb") as f:
                await query.message.reply_photo(f)
            os.remove(file)
        else:
            await query.message.reply_text(f"❌ Gagal membuat chart untuk {stock}")

    # ===== SNR CHART =====
    elif action == "snr":
        stock = parts[1]
        await query.message.reply_text(f"📉 *Membuat SNR Chart untuk {stock}...*", parse_mode='Markdown')

        df = await _download_and_clean(stock + ".JK", period="6mo")
        file = await asyncio.to_thread(generate_snr, df, stock + ".JK")

        if file and os.path.exists(file):
            with open(file, "rb") as f:
                await query.message.reply_photo(f)
            os.remove(file)
        else:
            await query.message.reply_text(f"❌ Gagal membuat SNR chart untuk {stock}")

    # ===== TA CHART (dulu "ML CHART", diganti -- lihat catatan di
    # handlers/chart_handlers.py & core/charts/ta_chart.py. callback_data
    # tetap "ml_" demi konsistensi internal, cuma label tombol & isi
    # chart-nya yang berubah) =====
    elif action == "ml":
        stock = parts[1]
        await query.message.reply_text(f"📊 *Membuat TA Chart untuk {stock}...*", parse_mode='Markdown')

        df = await _download_and_clean(stock + ".JK", period="1y")
        file = await asyncio.to_thread(generate_ta_chart, df, stock + ".JK")

        if file and os.path.exists(file):
            with open(file, "rb") as f:
                await query.message.reply_photo(f)
            os.remove(file)
        else:
            await query.message.reply_text(f"❌ Gagal membuat TA chart untuk {stock}")

    # ===== ADD TO WATCHLIST =====
    elif action == "wl_add":
        stock = parts[1]
        await query.message.reply_text(f"⭐ *Menambahkan {stock} ke watchlist...*", parse_mode='Markdown')

        df = await _download_and_clean(stock + ".JK")
        created_date_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        fixed_levels = calculate_fixed_entry_levels_from_df(df, created_date_str)

        if fixed_levels:
            add_to_watchlist_db(user_id, stock, fixed_levels)
            sc = fixed_levels['scenarios']
            confirm_msg = (
                f"✅ *{stock}* berhasil ditambahkan ke watchlist!\n\n"
                f"📊 Entry Levels:\n"
                f"├─ NORMAL: Rp{sc['normal']['entry']:,.0f}\n"
                f"├─ PULLBACK: Rp{sc['pullback']['entry']:,.0f}\n"
                f"├─ DEEP: Rp{sc['deep']['entry']:,.0f}\n"
                f"└─ BREAKOUT: Rp{sc['breakout']['entry']:,.0f}\n\n"
                f"Gunakan /wlstatus untuk cek status harian"
            )
            await query.message.reply_text(confirm_msg, parse_mode='Markdown')
        else:
            await query.message.reply_text(f"❌ Gagal menambahkan {stock} ke watchlist (data tidak cukup)")

    # ===== CHECK WATCHLIST STATUS =====
    elif action == "wl_check":
        stock = parts[1]
        watchlist = get_user_watchlist_db(user_id)
        if stock in [w['ticker'] for w in watchlist]:
            entries = get_fixed_entries_db(user_id, stock)
            if entries:
                msg = f"⭐ *{stock}* ✅ SUDAH ada di watchlist Anda\n\n"
                msg += f"📅 Ditambahkan: {entries.get('created_date', '-')}\n"
                msg += f"💰 Harga add: Rp{entries.get('price_at_create', 0):,.0f}\n\n"
                msg += "🎯 *ENTRY LEVELS:*\n"
                for key, sc in entries['scenarios'].items():
                    msg += f"• {sc['display_name']}: Rp{sc['entry']:,.0f} (SL: Rp{sc['sl']:,.0f})\n"
                await query.message.reply_text(msg, parse_mode='Markdown')
            else:
                await query.message.reply_text(f"⭐ *{stock}* ✅ SUDAH ada di watchlist Anda", parse_mode='Markdown')
        else:
            await query.message.reply_text(
                f"📭 *{stock}* ❌ BELUM ada di watchlist Anda\n\nGunakan 'ADD TO WATCHLIST' untuk menambah",
                parse_mode='Markdown'
            )

    # ===== QUICK INFO =====
    elif action == "info":
        stock = parts[1]
        try:
            df = await _download_and_clean(stock + ".JK", period="5d")

            if len(df) >= 2:
                price = float(df["Close"].iloc[-1])
                prev = float(df["Close"].iloc[-2])
                change = ((price / prev) - 1) * 100
                volume = int(df["Volume"].iloc[-1])
                high = float(df["High"].iloc[-1])
                low = float(df["Low"].iloc[-1])

                ma5 = df["Close"].rolling(5).mean().iloc[-1]
                ma20 = df["Close"].rolling(20).mean().iloc[-1] if len(df) >= 20 else 0
                last_rsi = round(float(calculate_rsi(df["Close"]).iloc[-1]), 2) if len(df) > 0 else 50

                info_msg = (
                    f"📊 *{stock} - QUICK INFO*\n\n"
                    f"💰 Harga: Rp{price:,.0f}\n"
                    f"📈 Perubahan: {change:+.2f}%\n"
                    f"📊 Volume: {volume:,}\n"
                    f"📈 High: Rp{high:,.0f}\n"
                    f"📉 Low: Rp{low:,.0f}\n"
                    f"📊 MA5: Rp{ma5:,.0f}\n"
                    f"📊 MA20: Rp{ma20:,.0f}\n"
                    f"📊 RSI(14): {last_rsi}\n\n"
                    f"💡 Gunakan 'RANAH AI' untuk analisis lengkap!"
                )
                await query.message.reply_text(info_msg, parse_mode='Markdown')
            else:
                await query.message.reply_text(f"❌ Data tidak cukup untuk {stock}")
        except Exception as e:
            await query.message.reply_text(f"❌ Gagal mengambil data {stock}: {str(e)}")

    # ===== BACKTEST SINYAL (BARU) =====
    elif action == "backtest":
        stock = parts[1]
        from core.backtest import backtest_condition, format_backtest_result, CONDITION_REGISTRY

        await query.message.reply_text(f"📊 Menjalankan backtest untuk {stock} (kondisi default: MA cross + volume)...")

        df = await _download_and_clean(stock + ".JK", period="1y")

        if len(df) < 50:
            return await query.message.reply_text(f"❌ Data historis {stock} tidak cukup untuk backtest.")

        condition_label, condition_fn = CONDITION_REGISTRY["ma_cross_volume"]
        result = backtest_condition(df, condition_fn, forward_days=5)
        msg = format_backtest_result(stock, condition_label, result)
        await query.message.reply_text(msg, parse_mode='Markdown')
        await query.message.reply_text(
            f"💡 Coba kondisi lain: `/backtest {stock} rsi_oversold` atau `/backtest {stock} golden_cross`",
            parse_mode='Markdown'
        )

    # ===== RELATIVE STRENGTH (BARU) =====
    elif action == "rs":
        stock = parts[1]
        from core.relative_strength import (
            calculate_relative_strength, find_sector_for_ticker, format_relative_strength_message,
        )
        from handlers.relative_strength_handlers import _calculate_sector_average_df
        from core.market import SECTOR_MAP

        await query.message.reply_text(f"📊 Menghitung relative strength {stock} vs IHSG/sektor...")

        ticker_full = stock + ".JK"
        sector_name = find_sector_for_ticker(ticker_full)

        stock_df = await _download_and_clean(ticker_full, period="2mo")
        ihsg_df = await _download_and_clean("^JKSE", period="2mo")

        sector_df = None
        if sector_name:
            sector_tickers = [t for t in SECTOR_MAP[sector_name] if t != ticker_full]
            if sector_tickers:
                sector_df = await _calculate_sector_average_df(sector_tickers)

        rs_vs_ihsg = calculate_relative_strength(stock_df, ihsg_df, period_days=20)
        rs_vs_sector = calculate_relative_strength(stock_df, sector_df, period_days=20) if sector_df is not None else None

        msg = format_relative_strength_message(stock, rs_vs_ihsg, sector_name, rs_vs_sector)
        await query.message.reply_text(msg, parse_mode='Markdown')

    # ===== MARKET STRUCTURE / SMART MONEY CONCEPTS (BARU) =====
    elif action == "bos":
        stock = parts[1]
        import asyncio as _asyncio
        from core.smc import detect_bos_choch
        from handlers.smc_handlers import format_bos_message
        from core.charts.smc_chart import generate_bos_chart

        df = await _download_and_clean(stock + ".JK", period="6mo")
        if len(df) < 30:
            return await query.message.reply_text(f"❌ Data historis {stock} tidak cukup (minimal ~30 hari).")

        events = detect_bos_choch(df, left_bars=5, right_bars=5)
        chart_file = await _asyncio.to_thread(generate_bos_chart, df, stock, events)
        if chart_file and os.path.exists(chart_file):
            with open(chart_file, "rb") as f:
                await query.message.reply_photo(f, caption=f"📊 {stock} — Break of Structure (BOS)")
            os.remove(chart_file)
        msg = format_bos_message(stock, df, events)
        await query.message.reply_text(msg, parse_mode='Markdown')

    elif action == "choch":
        stock = parts[1]
        import asyncio as _asyncio
        from core.smc import detect_bos_choch
        from handlers.smc_handlers import format_choch_message
        from core.charts.smc_chart import generate_choch_chart

        df = await _download_and_clean(stock + ".JK", period="6mo")
        if len(df) < 30:
            return await query.message.reply_text(f"❌ Data historis {stock} tidak cukup (minimal ~30 hari).")

        events = detect_bos_choch(df, left_bars=5, right_bars=5)
        chart_file = await _asyncio.to_thread(generate_choch_chart, df, stock, events)
        if chart_file and os.path.exists(chart_file):
            with open(chart_file, "rb") as f:
                await query.message.reply_photo(f, caption=f"📊 {stock} — Change of Character (CHoCH)")
            os.remove(chart_file)
        msg = format_choch_message(stock, df, events)
        await query.message.reply_text(msg, parse_mode='Markdown')

    elif action == "orderblock":
        stock = parts[1]
        import asyncio as _asyncio
        from core.smc import detect_order_blocks
        from handlers.smc_handlers import format_orderblock_message
        from core.charts.smc_chart import generate_orderblock_chart

        df = await _download_and_clean(stock + ".JK", period="6mo")
        if len(df) < 30:
            return await query.message.reply_text(f"❌ Data historis {stock} tidak cukup (minimal ~30 hari).")

        obs = detect_order_blocks(df, left_bars=5, right_bars=5, max_blocks=3)
        chart_file = await _asyncio.to_thread(generate_orderblock_chart, df, stock, obs)
        if chart_file and os.path.exists(chart_file):
            with open(chart_file, "rb") as f:
                await query.message.reply_photo(f, caption=f"📊 {stock} — Order Blocks")
            os.remove(chart_file)
        msg = format_orderblock_message(stock, df, obs)
        await query.message.reply_text(msg, parse_mode='Markdown')

    elif action == "fvg":
        stock = parts[1]
        import asyncio as _asyncio
        from core.smc import detect_fvg
        from handlers.smc_handlers import format_fvg_message
        from core.charts.smc_chart import generate_fvg_chart

        df = await _download_and_clean(stock + ".JK", period="3mo")
        if len(df) < 10:
            return await query.message.reply_text(f"❌ Data historis {stock} tidak cukup (minimal ~10 hari).")

        gaps = detect_fvg(df, max_gaps=3, only_unfilled=True)
        chart_file = await _asyncio.to_thread(generate_fvg_chart, df, stock, gaps)
        if chart_file and os.path.exists(chart_file):
            with open(chart_file, "rb") as f:
                await query.message.reply_photo(f, caption=f"📊 {stock} — Fair Value Gap (FVG)")
            os.remove(chart_file)
        msg = format_fvg_message(stock, df, gaps)
        await query.message.reply_text(msg, parse_mode='Markdown')

    elif action == "liquidity":
        stock = parts[1]
        import asyncio as _asyncio
        from core.smc import detect_liquidity_pools
        from handlers.smc_handlers import format_liquidity_message
        from core.charts.smc_chart import generate_liquidity_chart

        df = await _download_and_clean(stock + ".JK", period="6mo")
        if len(df) < 30:
            return await query.message.reply_text(f"❌ Data historis {stock} tidak cukup (minimal ~30 hari).")

        pools = detect_liquidity_pools(df, left_bars=5, right_bars=5, max_pools=3)
        chart_file = await _asyncio.to_thread(generate_liquidity_chart, df, stock, pools)
        if chart_file and os.path.exists(chart_file):
            with open(chart_file, "rb") as f:
                await query.message.reply_photo(f, caption=f"📊 {stock} — Liquidity Pools")
            os.remove(chart_file)
        msg = format_liquidity_message(stock, df, pools)
        await query.message.reply_text(msg, parse_mode='Markdown')

    # ===== RISK MANAGEMENT (BARU) =====
    elif action == "target":
        stock = parts[1]
        from core.risk_management import calculate_target_levels
        from handlers.risk_handlers import format_target_message

        df = await _download_and_clean(stock + ".JK", period="6mo")
        if len(df) < 20:
            return await query.message.reply_text(f"❌ Data historis {stock} tidak cukup (minimal ~20 hari).")

        t = calculate_target_levels(df)
        msg = format_target_message(stock, t)
        await query.message.reply_text(msg, parse_mode='Markdown')

    elif action == "cutloss":
        stock = parts[1]
        from core.risk_management import calculate_cutloss_levels
        from handlers.risk_handlers import format_cutloss_message

        df = await _download_and_clean(stock + ".JK", period="6mo")
        if len(df) < 20:
            return await query.message.reply_text(f"❌ Data historis {stock} tidak cukup (minimal ~20 hari).")

        c = calculate_cutloss_levels(df)
        msg = format_cutloss_message(stock, c)
        await query.message.reply_text(msg, parse_mode='Markdown')

    # ===== SEKTOR & ROTASI (BARU) =====
    elif action == "beta":
        stock = parts[1]
        from core.sector_rotation import calculate_beta
        from handlers.sector_rotation_handlers import format_beta_message

        await query.message.reply_text(f"📊 Menghitung beta {stock} vs IHSG...")

        stock_df = await _download_and_clean(stock + ".JK", period="6mo")
        ihsg_df = await _download_and_clean("^JKSE", period="6mo")

        if len(stock_df) < 30 or len(ihsg_df) < 30:
            return await query.message.reply_text(f"❌ Data {stock} atau IHSG tidak cukup (minimal ~30 hari).")

        result = calculate_beta(stock_df, ihsg_df)
        if result is None:
            return await query.message.reply_text(f"❌ Tidak bisa menghitung beta {stock} (data tidak bisa disejajarkan dengan IHSG).")

        msg = format_beta_message(stock, result)
        await query.message.reply_text(msg, parse_mode='Markdown')

    # ===== VOLUME PATTERNS (BARU) =====
    elif action == "volumespike":
        stock = parts[1]
        from core.volume_patterns import detect_volume_spikes
        from handlers.volume_pattern_handlers import format_volumespike_message

        df = await _download_and_clean(stock + ".JK", period="3mo")
        if len(df) < 20:
            return await query.message.reply_text(f"❌ Data historis {stock} tidak cukup (minimal ~20 hari).")

        result = detect_volume_spikes(df, lookback_days=10, threshold_multiplier=2.0)
        msg = format_volumespike_message(stock, result)
        await query.message.reply_text(msg, parse_mode='Markdown')

    elif action == "adline":
        stock = parts[1]
        from core.volume_patterns import calculate_ad_line
        from handlers.volume_pattern_handlers import format_adline_message

        df = await _download_and_clean(stock + ".JK", period="3mo")
        result = calculate_ad_line(df, lookback_days=20)
        if result is None:
            return await query.message.reply_text(f"❌ Data historis {stock} tidak cukup (minimal ~25 hari).")

        msg = format_adline_message(stock, result)
        await query.message.reply_text(msg, parse_mode='Markdown')

    # ===== BERITA (BARU) =====
    elif action == "news":
        stock = parts[1]
        from core.news import fetch_news
        from core.news_signal import enrich_news_with_signals
        from handlers.news_handlers import format_news_message

        await query.message.reply_text(f"📰 Mengambil berita {stock}...")

        items = await fetch_news(keyword=stock, limit=8)

        if items is None:
            return await query.message.reply_text(
                "❌ Gagal mengambil berita saat ini. Sumber berita mungkin sedang tidak bisa diakses. Coba lagi dalam 1-2 menit."
            )

        # Rangkai sinyal teknikal ke emiten yang disebut (sama dengan
        # /news KODE). Best-effort: kalau skoring gagal, berita tetap tampil.
        if items:
            try:
                items = await enrich_news_with_signals(items)
            except Exception as e:
                print(f"⚠️ menu news {stock}: enrich sinyal dilewati: {e}")

        msg = format_news_message(items, stock)
        await query.message.reply_text(msg, parse_mode='Markdown', disable_web_page_preview=True)

    # ===== FUNDAMENTAL (BARU) =====
    elif action == "fundamental":
        stock = parts[1]
        from core.fundamental import fetch_fundamental
        from handlers.fundamental_handlers import format_fundamental_message

        await query.message.reply_text(f"📊 Mengambil data fundamental {stock}...")

        data = await fetch_fundamental(stock + ".JK")

        if data is None:
            return await query.message.reply_text(
                f"❌ Gagal mengambil data fundamental {stock}. Yahoo Finance mungkin tidak punya data untuk saham ini, atau sedang bermasalah."
            )

        msg = format_fundamental_message(data)
        await query.message.reply_text(msg, parse_mode='Markdown')

    # ===== INSIGHT (BARU) =====
    elif action == "insight":
        stock = parts[1]
        from handlers.insight_handlers import _run_stock_insight

        # query.message punya interface .reply_text() yang SAMA dengan
        # update.message -- aman dipakai langsung sebagai pengganti
        # parameter "update" di _run_stock_insight(), menghindari
        # duplikasi logic antara handler command langsung dan action
        # menu (REFACTOR Juni 2026, sebelumnya logic ini diduplikasi
        # penuh di sini).
        await _run_stock_insight(query, stock)

    # ===== LAPORAN PDF (BARU) =====
    elif action == "laporan":
        stock = parts[1]
        from handlers.report_handlers import _laporan_saham

        # query.message punya interface .reply_text()/.reply_document()
        # yang SAMA dengan update.message, jadi query bisa dipakai langsung
        # sebagai pengganti "update" -- _laporan_saham hanya mengakses
        # .message. Menghindari duplikasi logic generate laporan PDF.
        await _laporan_saham(query, stock)

    # ===== LAPORAN PDF IHSG (BARU) =====
    elif action == "laporanihsg":
        from handlers.report_handlers import _laporan_ihsg
        await _laporan_ihsg(query)
