# =========================
# HANDLERS: IHSG ANALYSIS
# =========================
# Menggabungkan core/ihsg/ihsg_analysis.py, ihsg_strategy.py, ihsg_chart.py
# yang sudah dimigrasikan & diverifikasi numerik sebelumnya.
#
# PERUBAHAN dari main.py lama: analyze_ihsg_advanced() dulu download 3
# timeframe (daily, hourly, weekly) SENDIRI secara sinkron di dalam
# fungsinya -- termasuk download hourly yang TIDAK PERNAH DIPAKAI di
# logic manapun (dikonfirmasi saat migrasi ke core/ihsg/ihsg_analysis.py).
# Sekarang: download daily & weekly PARALEL via asyncio.gather (hourly
# dihapus karena memang tidak terpakai), baru kalkulasi dipisah dari I/O.
#
# PERBAIKAN AKURASI (BARU): field "accuracy_estimate" yang dulu
# ditampilkan sebagai "Akurasi estimasi: X%" itu rumus arbitrer
# (50 + jumlah_indikator_searah*5, dibatasi maks 85) -- TAMPAK seperti
# hasil pengukuran tapi sebenarnya formula buatan, sama bermasalahnya
# dengan target_move yang dulu random.uniform(). Sekarang diganti
# dengan win-rate SUNGGUHAN dari backtest_condition() pada histori IHSG
# 2 tahun (lihat core/ihsg/ihsg_analysis.py: analyze_ihsg_with_backtest,
# dan core/backtest.py: condition_ihsg_bullish_strong/bearish_strong).

import os
import asyncio
import logging
from datetime import datetime

from core.async_yf import async_download
from core.stock_data import fix_yf_columns
from core.ihsg.ihsg_analysis import analyze_ihsg_with_backtest
from core.ihsg.ihsg_strategy import get_ihsg_strategy_advanced
from core.ihsg.ihsg_chart import generate_ihsg_advanced_chart
from core.messages import split_long_message

logger = logging.getLogger(__name__)


def _format_backtest_section(backtest_result: dict | None, prediction: str) -> str:
    """Format bagian akurasi di pesan IHSG, berdasarkan backtest_result
    sungguhan (BUKAN rumus arbitrer seperti accuracy_estimate lama)."""
    if backtest_result is None:
        return (
            "├─ Akurasi historis: tidak tersedia\n"
            "└─ (kondisi serupa terlalu jarang muncul di histori 2 tahun, "
            "atau prediksi saat ini SIDEWAYS/MIXED sehingga tidak ada kondisi yang relevan dibacktest)"
        )

    win_rate = backtest_result["win_rate"]
    n = backtest_result["n"]
    avg_return = backtest_result["avg_return"]
    base_rate = backtest_result.get("base_rate")
    edge = backtest_result.get("edge")

    arah = "naik" if "BULLISH" in prediction else "turun" if "BEARISH" in prediction else "bergerak sesuai arah"

    lines = [
        f"├─ Akurasi historis: *{win_rate}%* (dari {n}x kejadian serupa, 2 tahun terakhir)",
    ]
    if base_rate is not None:
        # Edge = keunggulan dibanding peluang naik tanpa syarat. INI yang
        # benar-benar bermakna; win rate telanjang gampang menyesatkan.
        if edge is not None and edge > 1:
            edge_txt = f"unggul *{edge:+.1f} poin* dari baseline ({base_rate}%) ✅"
        elif edge is not None and edge < -1:
            edge_txt = f"*di bawah* baseline ({base_rate}%) sebesar {edge:+.1f} poin ⚠️"
        else:
            edge_txt = f"~setara baseline ({base_rate}%) — nyaris tanpa keunggulan ⚠️"
        lines.append(f"├─ Edge vs baseline: {edge_txt}")
    lines.append(f"├─ Rata-rata gerak: {avg_return:+.2f}% dalam 5 hari saat kondisi serupa muncul")
    lines.append(f"└─ Catatan: statistik historis in-sample, bukan jaminan masa depan")
    return "\n".join(lines)


async def _download_with_retry(ticker: str, period: str, interval: str,
                                  max_retries: int = 3, base_delay: float = 1.5):
    """Download dengan retry + backoff untuk mengatasi rate-limit Yahoo
    Finance (error 'Expecting value: line 1 column 1' adalah isu umum
    yfinance saat rate-limited, dikonfirmasi di GitHub ranaroussi/yfinance
    issue #2179/#2520/#2521 -- bukan bug spesifik bot ini)."""
    import pandas as pd
    for attempt in range(max_retries):
        try:
            raw = await async_download(ticker, period=period, interval=interval, progress=False)
            if raw is not None and not raw.empty:
                return raw
        except Exception as e:
            if attempt == max_retries - 1:
                logger.error(f"/ihsg: {ticker} ({interval}) gagal setelah {max_retries}x: {e}")
        if attempt < max_retries - 1:
            await asyncio.sleep(base_delay * (attempt + 1))
    return pd.DataFrame()


async def ihsg_advanced_cmd(update, context):
    """/ihsg - Analisis IHSG yang lebih akurat."""
    await update.message.reply_text(
        "📊 *Menganalisis IHSG dengan metode advanced...*\n"
        "⏳ Menggunakan Multiple Timeframe + Fibonacci + Volume Profile + Divergence\n\n"
        "Fitur analisis:\n"
        "• Elliott Wave & Fibonacci\n"
        "• RSI Divergence Detection\n"
        "• Volume Profile (POC)\n"
        "• Bollinger Band Squeeze\n"
        "• Candlestick Pattern Scoring\n"
        "• Multiple Timeframe Confluence\n"
        "• Validasi Akurasi via Backtest Historis",
        parse_mode='Markdown'
    )

    try:
        # Download SEQUENTIAL (bukan paralel) dengan jeda kecil antar
        # request -- 3 request paralel sekaligus ke ^JKSE lebih rawan
        # kena rate-limit Yahoo Finance dibanding sequential dengan jeda.
        df_daily_raw = await _download_with_retry("^JKSE", period="3mo", interval="1d")
        await asyncio.sleep(0.5)
        df_weekly_raw = await _download_with_retry("^JKSE", period="1y", interval="1wk")
        await asyncio.sleep(0.5)
        df_longer_raw = await _download_with_retry("^JKSE", period="2y", interval="1d")

        import pandas as pd
        df_daily = fix_yf_columns(df_daily_raw).apply(pd.to_numeric, errors="coerce").dropna()
        df_weekly = fix_yf_columns(df_weekly_raw).apply(pd.to_numeric, errors="coerce").dropna()
        df_longer = fix_yf_columns(df_longer_raw).apply(pd.to_numeric, errors="coerce").dropna()

        if len(df_daily) < 50:
            return await update.message.reply_text(
                "❌ Data IHSG tidak cukup untuk analisis (minimal 50 hari).\n"
                f"Baris data yang diterima: {len(df_daily)}\n\n"
                "Ini biasanya terjadi karena Yahoo Finance sedang membatasi "
                "(rate-limit) request dari koneksi kamu setelah banyak command "
                "dijalankan beruntun. Tunggu 1-2 menit lalu coba lagi."
            )

        analysis = analyze_ihsg_with_backtest(df_daily, df_weekly, df_longer)

        if not analysis:
            return await update.message.reply_text("❌ Gagal menganalisis IHSG. Data tidak mencukupi.")

        chart_file = await asyncio.to_thread(generate_ihsg_advanced_chart, df_daily)

        backtest_section = _format_backtest_section(analysis["backtest_result"], analysis["prediction"])

        msg = f"""
📊 *ANALISIS IHSG ADVANCED*
📅 {datetime.now().strftime('%A, %d %B %Y')}
{'='*45}

💰 *HARGA TERKINI*
├─ Close: Rp{analysis['current_price']:,.0f}
└─ Change: {analysis['daily_change']:+.2f}%

{'='*45}
🎯 *PREDIKSI & REKOMENDASI*

├─ Prediksi: {analysis['prediction']}
├─ Keyakinan: {analysis['confidence']}
{backtest_section}
├─ Score: 🟢 {analysis['bullish_score']}% vs 🔴 {analysis['bearish_score']}%
└─ Target pergerakan: {analysis['target_move']}

💡 *{analysis['action']}*

{'='*45}
📈 *INDIKATOR TEKNIKAL*

🔹 *TREND (Multiple Timeframe)*
├─ Daily Trend: {analysis['ma_trend']}
├─ MA20: Rp{analysis['ma20']:,.0f}
├─ MA50: Rp{analysis['ma50']:,.0f}
└─ BB Squeeze: {'✅ AKTIF (siap breakout!)' if analysis['bb_squeeze'] else '❌ Tidak aktif'}

🔹 *MOMENTUM & DIVERGENCE*
├─ RSI(14): {analysis['rsi']}
├─ Divergence: {analysis['rsi_divergence']}
├─ MACD: {analysis['macd_signal']}
└─ BB Position: {analysis['bb_position']}%

🔹 *VOLUME PROFILE*
├─ POC (Point of Control): Rp{analysis['poc']:,.0f}
├─ Volume Trend: {analysis['volume_trend']}
└─ Volume Ratio: {analysis['volume_ratio']}x

{'='*45}
📐 *FIBONACCI LEVELS (50 hari)*

├─ Fib 61.8%: Rp{analysis['fib_618']:,.0f}
├─ Fib 50%: Rp{analysis['fib_500']:,.0f}
├─ Fib 38.2%: Rp{analysis['fib_382']:,.0f}
└─ Posisi: {analysis['fib_position']}

{'='*45}
🛡️ *SUPPORT & RESISTANCE*

🔹 SUPPORT
├─ S1: Rp{analysis['support_1']:,.0f}
└─ S2: Rp{analysis['support_2']:,.0f}

🔹 RESISTANCE
├─ R1: Rp{analysis['resistance_1']:,.0f}
└─ R2: Rp{analysis['resistance_2']:,.0f}

{'='*45}
🕯️ *CANDLESTICK PATTERNS*
"""

        if analysis['candle_patterns']:
            for pattern, score in analysis['candle_patterns']:
                emoji = "🟢" if score > 0 else "🔴" if score < 0 else "⚪"
                msg += f"├─ {emoji} {pattern}: {'Bullish' if score > 0 else 'Bearish' if score < 0 else 'Neutral'}\n"
        else:
            msg += "├─ ⚪ No significant pattern\n"

        msg += f"""
{'='*45}
📋 *STRATEGI TRADING*

{get_ihsg_strategy_advanced(analysis)}

{'='*45}
⚠️ *DISCLAIMER*
Analisis berbasis data historis dan probabilitas.
Akurasi historis di atas diukur dari kejadian masa lalu (in-sample), BUKAN garansi hasil masa depan.
Selalu gunakan money management dan stop loss!
"""

        if chart_file and os.path.exists(chart_file):
            with open(chart_file, "rb") as f:
                caption_accuracy = (
                    f"{analysis['backtest_result']['win_rate']}% akurasi historis"
                    if analysis['backtest_result'] else "akurasi historis tidak tersedia"
                )
                caption_text = f"📊 *IHSG - Advanced Analysis*\nPrediksi: {analysis['prediction']} | {caption_accuracy}"
                try:
                    await update.message.reply_photo(f, caption=caption_text, parse_mode='Markdown')
                except Exception:
                    # Fallback: kalau Markdown caption gagal parse (karakter
                    # spesial tak terduga), kirim ulang TANPA parse_mode
                    # supaya foto tetap terkirim, bukan gagal total
                    f.seek(0)
                    await update.message.reply_photo(f, caption=caption_text)
            os.remove(chart_file)

        for chunk in split_long_message(msg):
            try:
                await update.message.reply_text(chunk, parse_mode='Markdown')
            except Exception:
                # Fallback yang sama untuk body pesan -- lapisan pertahanan
                # KEDUA di luar perbaikan sumber masalah (lihat catatan di
                # core/ihsg/ihsg_analysis.py soal fib_position & candle
                # pattern names yang sudah diperbaiki tidak pakai underscore
                # lagi). Ini jaring pengaman kalau ada karakter rawan lain
                # yang terlewat di masa depan -- pesan tetap terkirim
                # (tanpa formatting) daripada user dapat error generic.
                await update.message.reply_text(chunk)

        # Tombol cepat untuk generate laporan PDF IHSG lengkap (callback
        # "laporanihsg" -- TANPA underscore supaya tidak ketukar skema
        # parsing "action_ticker" di stock_menu_callback).
        try:
            from telegram import InlineKeyboardButton, InlineKeyboardMarkup
            kb = InlineKeyboardMarkup([[
                InlineKeyboardButton("📄 Laporan PDF IHSG", callback_data="laporanihsg")
            ]])
            await update.message.reply_text("Mau laporan lengkap dalam PDF?", reply_markup=kb)
        except Exception as e:
            print(f"⚠️ /ihsg: gagal menambah tombol laporan PDF: {e}")

    except Exception as e:
        import traceback
        error_detail = str(e)[:200]
        logger.error(f"Error di /ihsg: {traceback.format_exc()}")
        await update.message.reply_text(
            f"❌ *Error saat analisis IHSG*\n\n"
            f"Detail: `{error_detail}`\n\n"
            "Kemungkinan penyebab:\n"
            "• Data Yahoo Finance tidak tersedia saat ini\n"
            "• Koneksi internet terputus sementara\n\n"
            "Coba lagi dalam 1-2 menit.",
            parse_mode='Markdown'
        )
