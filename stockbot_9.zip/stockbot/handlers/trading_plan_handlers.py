# =========================
# HANDLERS: TRADING PLAN
# =========================
# PERUBAHAN dari main.py lama:
# - plan_cmd: advanced_trading_plan() lama melakukan download + kalkulasi
#   + generate chart sekaligus secara sinkron. Sekarang dipecah: download
#   via async_download (non-blocking), kalkulasi via
#   calculate_advanced_plan_from_df (core/trading_plan.py), chart via
#   generate_trading_plan_chart (core/charts/trading_plan_chart.py).
# - bsjp_top_plan_cmd: dulu generate trading plan untuk top-2 saham
#   SEQUENTIAL. Sekarang tetap sequential secara tampilan (supaya urutan
#   pesan ke user tetap "Stock 1, lalu Stock 2"), tapi proses kalkulasinya
#   sendiri sudah non-blocking di level bawah.
#
# CATATAN PEMINDAHAN (Juni 2026): compare_cmd yang DULU ada di file ini
# sudah DIPINDAH ke handlers/compare_handlers.py -- redesign total
# (scoring REUSE dari AI Score + chart visual baru), dipisah ke file
# sendiri supaya tidak tercampur dengan handler trading plan yang tidak
# terkait. Lihat catatan lengkap di core/compare.py.

import asyncio
import os

from core.async_yf import async_download
from core.stock_data import fix_yf_columns, load_tickers
from core.trading_plan import calculate_advanced_plan_from_df, calculate_bsjp_plan_from_df
from core.charts.trading_plan_chart import generate_trading_plan_chart
from core.screener import run_bsjp_screener
from core.messages import split_long_message

SCREENING_TICKER_LIMIT = 200


def _format_advanced_plan_message(plan: dict) -> str:
    """Format dict hasil calculate_advanced_plan_from_df() jadi pesan teks
    lengkap, identik dengan format pesan di main.py lama."""
    ticker_name = plan["ticker_symbol"].replace(".JK", "")
    sr = plan["sr"]
    sc = plan["scenarios"]

    msg = f"""
📈 TRADING PLAN - RISK 3% PER TRADE (LONG ONLY)
{ticker_name}
{'='*70}

📊 DATA MARKET:
• Harga saat ini: Rp{plan['current_price']:,.0f}
• Perubahan: {plan['daily_change_pct']:+.2f}%
• ATR (14): Rp{plan['atr']:,.0f}
• RSI (14): {plan['rsi']} ({plan['rsi_status']})
• Trend: {plan['trend']}
• Volume: {plan['volume']:,} ({plan['vol_ratio']:.1f}x) {plan['vol_status']}

🚀 STATUS BREAKOUT:
• Resistance R1: Rp{sr['R1']:,.0f}
• Resistance R2: Rp{sr['R2']:,.0f}
• Status: {plan['breakout_status']}

{'='*70}
🎯 SKENARIO 1: ENTRY NORMAL
━━━━━━━━━━━━━━━━━━━━
💰 Entry: Rp{sc['normal']['entry']:,.0f}
🛑 Stop Loss: Rp{sc['normal']['sl']:,.0f}
⚠️ Risk: {sc['normal']['risk_pct']:.1f}% (Rp{sc['normal']['risk_abs']:,.0f}/saham)
📦 Posisi: {sc['normal']['position_size']:,} lembar (Rp{sc['normal']['position_value']:,.0f})

🎯 TAKE PROFIT (3 LEVEL):
• TP1: Rp{sc['normal']['tp']['tp1']:,.0f} (+{sc['normal']['tp']['tp1_pct']:.1f}%) | R:R 1:{sc['normal']['tp']['rr1']}
• TP2: Rp{sc['normal']['tp']['tp2']:,.0f} (+{sc['normal']['tp']['tp2_pct']:.1f}%) | R:R 1:{sc['normal']['tp']['rr2']}
• TP3: Rp{sc['normal']['tp']['tp3']:,.0f} (+{sc['normal']['tp']['tp3_pct']:.1f}%) | R:R 1:{sc['normal']['tp']['rr3']}

━━━━━━━━━━━━━━━━━━━━
🎯 SKENARIO 2: ENTRY PULLBACK
━━━━━━━━━━━━━━━━━━━━
💰 Entry: Rp{sc['pullback']['entry']:,.0f}
🛑 Stop Loss: Rp{sc['pullback']['sl']:,.0f}
⚠️ Risk: {sc['pullback']['risk_pct']:.1f}% (Rp{sc['pullback']['risk_abs']:,.0f}/saham)
📦 Posisi: {sc['pullback']['position_size']:,} lembar (Rp{sc['pullback']['position_value']:,.0f})

🎯 TAKE PROFIT (3 LEVEL):
• TP1: Rp{sc['pullback']['tp']['tp1']:,.0f} (+{sc['pullback']['tp']['tp1_pct']:.1f}%) | R:R 1:{sc['pullback']['tp']['rr1']}
• TP2: Rp{sc['pullback']['tp']['tp2']:,.0f} (+{sc['pullback']['tp']['tp2_pct']:.1f}%) | R:R 1:{sc['pullback']['tp']['rr2']}
• TP3: Rp{sc['pullback']['tp']['tp3']:,.0f} (+{sc['pullback']['tp']['tp3_pct']:.1f}%) | R:R 1:{sc['pullback']['tp']['rr3']}

━━━━━━━━━━━━━━━━━━━━
🎯 SKENARIO 3: ENTRY DEEP
━━━━━━━━━━━━━━━━━━━━
💰 Entry: Rp{sc['deep']['entry']:,.0f}
🛑 Stop Loss: Rp{sc['deep']['sl']:,.0f}
⚠️ Risk: {sc['deep']['risk_pct']:.1f}% (Rp{sc['deep']['risk_abs']:,.0f}/saham)
📦 Posisi: {sc['deep']['position_size']:,} lembar (Rp{sc['deep']['position_value']:,.0f})

🎯 TAKE PROFIT (3 LEVEL):
• TP1: Rp{sc['deep']['tp']['tp1']:,.0f} (+{sc['deep']['tp']['tp1_pct']:.1f}%) | R:R 1:{sc['deep']['tp']['rr1']}
• TP2: Rp{sc['deep']['tp']['tp2']:,.0f} (+{sc['deep']['tp']['tp2_pct']:.1f}%) | R:R 1:{sc['deep']['tp']['rr2']}
• TP3: Rp{sc['deep']['tp']['tp3']:,.0f} (+{sc['deep']['tp']['tp3_pct']:.1f}%) | R:R 1:{sc['deep']['tp']['rr3']}

━━━━━━━━━━━━━━━━━━━━
🚀 SKENARIO 4: ENTRY BREAKOUT
━━━━━━━━━━━━━━━━━━━━
💰 Entry: Rp{sc['breakout']['entry']:,.0f}
📌 Breakout Level: Rp{sr['R1']:,.0f}
🛑 Stop Loss: Rp{sc['breakout']['sl']:,.0f}
⚠️ Risk: {sc['breakout']['risk_pct']:.1f}% (Rp{sc['breakout']['risk_abs']:,.0f}/saham)
📦 Posisi: {sc['breakout']['position_size']:,} lembar (Rp{sc['breakout']['position_value']:,.0f})

🎯 TAKE PROFIT (3 LEVEL):
• TP1: Rp{sc['breakout']['tp']['tp1']:,.0f} (+{sc['breakout']['tp']['tp1_pct']:.1f}%) | R:R 1:{sc['breakout']['tp']['rr1']}
• TP2: Rp{sc['breakout']['tp']['tp2']:,.0f} (+{sc['breakout']['tp']['tp2_pct']:.1f}%) | R:R 1:{sc['breakout']['tp']['rr2']}
• TP3: Rp{sc['breakout']['tp']['tp3']:,.0f} (+{sc['breakout']['tp']['tp3_pct']:.1f}%) | R:R 1:{sc['breakout']['tp']['rr3']}

⚠️ SYARAT BREAKOUT:
• Harga > R1 ({sr['R1']:,.0f})
• Volume > 1.3x rata-rata
• Candlestick bullish

{'='*70}
📐 LEVEL SUPPORT & RESISTANCE:

SUPPORT (di bawah):              RESISTANCE (di atas):
S1: Rp{sr['S1']:,.0f}            R1: Rp{sr['R1']:,.0f}
S2: Rp{sr['S2']:,.0f}            R2: Rp{sr['R2']:,.0f}
S3: Rp{sr['S3']:,.0f}            R3: Rp{sr['R3']:,.0f}
S4: Rp{sr['S4']:,.0f}            R4: Rp{sr['R4']:,.0f}
                                 R5: Rp{sr['R5']:,.0f}

{'='*70}
⭐ CONFIDENCE SCORE: {plan['confidence']}/100
"""
    if plan['confidence'] >= 70:
        msg += "✅ HIGH CONFIDENCE - Cocok untuk entry\n"
    elif plan['confidence'] >= 50:
        msg += "⚠️ MEDIUM CONFIDENCE - Entry dengan scaling\n"
    else:
        msg += "❌ LOW CONFIDENCE - Sebaiknya tunggu koreksi\n"

    pv1 = sc['normal']['position_value']
    tp1_pct = sc['normal']['tp']['tp1_pct']
    tp2_pct = sc['normal']['tp']['tp2_pct']
    tp3_pct = sc['normal']['tp']['tp3_pct']

    msg += f"""
{'='*70}
💼 MANAJEMEN MODAL (Rp{plan['account_size']:,.0f}):

• Risk per trade: {plan['target_risk_pct']}% (Rp{plan['max_risk_amount']:,.0f})
• Max kerugian per trade: Rp{plan['max_risk_amount']:,.0f}
• Max 5 posisi bersamaan (total risk 15%)
• Gunakan STOP LOSS wajib!

{'='*70}
📋 STRATEGI SCALING OUT (3 LEVEL):
━━━━━━━━━━━━━━━━━━━━
🎯 TP1 → Jual 40% | Move SL ke Break Even
🎯 TP2 → Jual 35% | Move SL ke +1.5%
🎯 TP3 → Jual 25% | Full Exit / Trail SL
━━━━━━━━━━━━━━━━━━━━

{'='*70}
💰 SIMULASI PROFIT (Skenario 1 - Normal Entry):

Entry: Rp{sc['normal']['entry']:,.0f} ({sc['normal']['position_size']:,} lembar = Rp{pv1:,.0f})
Risk: 3% = Rp{plan['max_risk_amount']:,.0f}

Jika mencapai:
• TP1 ({tp1_pct:.1f}%): Jual 40% → Profit Rp{pv1 * (tp1_pct/100) * 0.4:,.0f}
• TP2 ({tp2_pct:.1f}%): Jual 35% → Profit Rp{pv1 * (tp2_pct/100) * 0.35:,.0f}
• TP3 ({tp3_pct:.1f}%): Jual 25% → Profit Rp{pv1 * (tp3_pct/100) * 0.25:,.0f}

TOTAL PROFIT: Rp{(pv1 * (tp1_pct/100*0.4 + tp2_pct/100*0.35 + tp3_pct/100*0.25)):,.0f}
({(tp1_pct*0.4 + tp2_pct*0.35 + tp3_pct*0.25):.1f}% dari modal)

{'='*70}
✅ RULES WAJIB:
1. RISK 3% SUDAH DITENTUKAN
2. STOP LOSS DI BAWAH SUPPORT
3. SCALING OUT WAJIB DI SETIAP TP
4. JANGAN AVERAGING DOWN
5. HORMATI STOP LOSS!

💡 REKOMENDASI SKENARIO:
• Skenario 1: Trader agresif
• Skenario 2: Paling aman (pullback)
• Skenario 3: Entry kedua/avg
• 🚀 Skenario 4: Breakout trader

⚠️ DISCLAIMER: Bukan ajakan beli/jual. DYOR!
"""
    return msg


def _format_bsjp_plan_message(plan: dict) -> str:
    """Format dict hasil calculate_bsjp_plan_from_df() jadi pesan teks,
    identik dengan format pesan bsjp_trading_plan() di main.py lama."""
    ticker_name = plan["ticker_symbol"].replace(".JK", "")
    r = plan["rules"]

    msg = f"""
🚀 BSJP TRADING PLAN (LONG/BUY): {ticker_name}
{'='*55}

📊 HASIL SCREENING BSJP:
{'✅' if r['rule_1'] else '❌'} Rule 1: Harga ≥ 5% ({plan['daily_change_pct']:+.1f}%)
{'✅' if r['rule_2'] else '❌'} Rule 2: Harga ≥ MA5
{'✅' if r['rule_3'] else '❌'} Rule 3: Volume ≥ 1.2x ({plan['current_volume']/plan['prev_volume']:.1f}x)
{'✅' if r['rule_4'] else '❌'} Rule 4: Nilai ≥ 5B ({plan['current_value']/1e9:.1f}B)

STATUS: {plan['rules_passed']}/4 LOLOS
MOMENTUM: {plan['daily_change_pct']:+.1f}%

{'='*55}
🎯 LEVEL ENTRY (BELI):

1. ENTRY AGGRESSIF: {plan['entry_aggressive']:,.0f}
   → Setelah ada konfirmasi candlestick

2. ENTRY KONSERVATIF: {plan['entry_conservative']:,.0f}
   → Tunggu pullback ke support S1
   → Lebih aman untuk BSJP

3. ENTRY BREAKOUT: DI ATAS {plan['r1']:,.0f}
   → Jika tembus resistance

{'='*55}
🛑 STOP LOSS (CUT LOSS) - BSJP STYLE:

• Harga Stop Loss: {plan['stop_loss']:,.0f}
• Kerugian per saham: {plan['risk_per_share']:,.0f}
• Persen Risiko: {plan['risk_pct']:.1f}%
• Metode: 2.5x ATR + Support

⚠️ Catatan: Stop loss lebih lebar karena
volatilitas saham BSJP lebih tinggi

{'='*55}
🎯 TARGET PROFIT (TAKE PROFIT):

• TP1: {plan['tp1']:,.0f} | R:R 1:{((plan['tp1']-plan['current_price'])/plan['risk_per_share']):.1f}
• TP2: {plan['tp2']:,.0f} | R:R 1:{((plan['tp2']-plan['current_price'])/plan['risk_per_share']):.1f}
• TP3: {plan['tp3']:,.0f} | R:R 1:{((plan['tp3']-plan['current_price'])/plan['risk_per_share']):.1f}

📐 LEVEL RESISTANCE BSJP:
• R1: {plan['r1']:,.0f}
• R2: {plan['r2']:,.0f}

{'='*55}
💼 MANAJEMEN MODAL (Modal Rp 100jt):

• Risk per trade: {plan['risk_per_trade_pct']}%
• Maksimal kerugian: Rp {plan['adjusted_risk']:,.0f}
• Jumlah saham: {plan['position_size']:,} lembar
• Nilai posisi: Rp {plan['position_value']:,.0f}

{'='*55}
⭐ KONFIDENSI BSJP: {plan['confidence']}/100
"""
    if plan['confidence'] >= 70:
        msg += "✅ HIGH - Saham layak beli, BSJP qualified\n"
    elif plan['confidence'] >= 50:
        msg += "⚠️ MEDIUM - Bisa beli dengan scaling\n"
    else:
        msg += "❌ LOW - Belum qualified, tunggu signal lebih kuat\n"

    msg += f"""
{'='*55}
📋 LANGKAH EKSEKUSI BSJP (LONG ONLY)

TAHAP 1 - PERSIAPAN:
☐ Pastikan 4 rules BSJP terpenuhi minimal 3
☐ Cek volume > 200.000 lot/transaksi
☐ Pastikan tidak ada berita negatif

TAHAP 2 - EKSEKUSI:
☐ Entry {plan['rules_passed'] * 15}% dari modal di harga entry
☐ Gunakan LIMIT ORDER, jangan market order
☐ Pasang stop loss setelah entry

TAHAP 3 - MONITORING:
☐ Jika harga turun 3% dari entry, evaluasi ulang
☐ Jika harga naik ke TP1 → take profit 50%
☐ Naikkan stop loss ke harga modal

TAHAP 4 - EXIT:
☐ Jika momentum melemah, exit lebih awal
☐ Jangan serakah, profit adalah profit

⚠️ RISIKO KHUSUS BSJP:
• Volatilitas tinggi (bisa gap up/down)
• Likuiditas bisa kering saat jam makan siang
• Slippage saat entry/exit
• Harga mudah dipengaruhi berita

💡 TIPS BSJP:
• Waktu terbaik entry: 09:30-11:00
• Hindari entry jam 11:30-13:30
• Catat level psikologis: kelipatan 50
• Jangan trading jika volume < 100.000
• Cut loss lebih cepat jika melanggar rule 1
"""
    return msg


async def _download_and_clean(ticker: str, period: str = "6mo"):
    """Helper: download + bersihkan data untuk satu ticker."""
    import pandas as pd
    df = await async_download(ticker, period=period, interval="1d", progress=False)
    df = fix_yf_columns(df)
    df = df.apply(pd.to_numeric, errors="coerce")
    df = df.dropna()
    return df


async def plan_cmd(update, context):
    if not context.args:
        return await update.message.reply_text(
            "📈 ADVANCED TRADING PLAN + CHART\n\n"
            "Usage: /plan BBCA\n\n"
            "Features:\n"
            "• ATR-based stop loss\n"
            "• Multiple R:R targets\n"
            "• Position sizing\n"
            "• Confidence scoring\n"
            "• 📊 Trading Plan Chart (S/R + Entry Levels)"
        )
    ticker = context.args[0].upper() + ".JK"

    await update.message.reply_text(f"🔍 Generating advanced trading plan + chart untuk {ticker}...")

    df = await _download_and_clean(ticker)
    plan = calculate_advanced_plan_from_df(df, ticker)

    if plan is None:
        return await update.message.reply_text(f"❌ Data tidak cukup untuk analisis akurat {ticker}")

    entry_levels = {k: v["entry"] for k, v in plan["scenarios"].items()}
    sl_levels = {k: v["sl"] for k, v in plan["scenarios"].items()}
    tp_levels = {k: {"tp1": v["tp"]["tp1"], "tp2": v["tp"]["tp2"], "tp3": v["tp"]["tp3"],
                      "rr1": v["tp"]["rr1"], "rr2": v["tp"]["rr2"], "rr3": v["tp"]["rr3"]}
                 for k, v in plan["scenarios"].items()}

    chart_file = await asyncio.to_thread(
        generate_trading_plan_chart, df, ticker, plan["sr"], plan["current_price"], plan["atr"],
        entry_levels, tp_levels, sl_levels,
    )

    if chart_file and os.path.exists(chart_file):
        with open(chart_file, "rb") as f:
            await update.message.reply_photo(
                f,
                caption=f"📊 *{ticker.replace('.JK', '')} - Trading Plan Chart*\n"
                        f"🟢 Area biru = Zona Akumulasi (Support)\n"
                        f"🔴 Area merah = Zona Distribusi (Resistance)\n"
                        f"💡 Harga di S1-S2 = area beli yang aman",
                parse_mode="Markdown",
            )
        os.remove(chart_file)
    else:
        await update.message.reply_text("⚠️ Gagal membuat chart, tapi trading plan tetap tersedia")

    msg = _format_advanced_plan_message(plan)
    for chunk in split_long_message(msg):
        await update.message.reply_text(chunk)


async def bsjp_plan_cmd(update, context):
    if not context.args:
        return await update.message.reply_text(
            "📈 BSJP TRADING PLAN\n\n"
            "Usage: /bsjpplan BBCA\n\n"
            "BSJP Rules:\n"
            "• Price ≥ 5% dari previous\n"
            "• Price ≥ MA5\n"
            "• Volume ≥ 1.2x previous\n"
            "• Value ≥ 5 Miliar"
        )
    ticker = context.args[0].upper() + ".JK"
    await update.message.reply_text(f"🔍 Generating BSJP trading plan untuk {ticker}...")

    df = await _download_and_clean(ticker, period="3mo")
    plan = calculate_bsjp_plan_from_df(df, ticker)

    if plan is None:
        return await update.message.reply_text("❌ Data tidak cukup untuk analisis BSJP")

    msg = _format_bsjp_plan_message(plan)
    for chunk in split_long_message(msg):
        await update.message.reply_text(chunk)


async def bsjp_top_plan_cmd(update, context):
    await update.message.reply_text("🔍 Screening BSJP stocks...")
    tickers = load_tickers(limit=SCREENING_TICKER_LIMIT)
    screener_results = await run_bsjp_screener(tickers)

    top_tickers = [r["ticker"] for r in screener_results[:2]]

    if not top_tickers:
        return await update.message.reply_text("❌ No BSJP qualified stocks found\n\nCoba: /bsjp")

    await update.message.reply_text(f"🎯 TOP {len(top_tickers)} BSJP STOCKS\nGenerating trading plans...\n\n")

    for i, ticker in enumerate(top_tickers):
        full_ticker = ticker + ".JK"
        df = await _download_and_clean(full_ticker, period="3mo")
        plan = calculate_bsjp_plan_from_df(df, full_ticker)

        if plan is None:
            await update.message.reply_text(f"❌ Gagal membuat plan untuk {ticker}")
            continue

        msg = _format_bsjp_plan_message(plan)
        for chunk in split_long_message(msg):
            await update.message.reply_text(chunk)

        if i < len(top_tickers) - 1:
            await update.message.reply_text("--- Next Stock ---")
