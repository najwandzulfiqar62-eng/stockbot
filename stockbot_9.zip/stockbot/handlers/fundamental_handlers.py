# =========================
# HANDLER: FUNDAMENTAL
# =========================
# /fundamental KODE -- data fundamental saham (PE, PBV, ROE, DER,
# Dividend Yield, EPS, dst). Lihat catatan sumber, bukti, dan
# keterbatasan format data lengkap di core/fundamental.py.

from core.fundamental import fetch_fundamental
from core.messages import sanitize_for_markdown


def _fmt_num(val, suffix: str = "", decimals: int = 2) -> str:
    """Format angka untuk display, atau 'N/A' kalau None -- dipisah
    jadi helper supaya tidak mengulang pengecekan None di setiap baris."""
    if val is None:
        return "N/A"
    return f"{val:,.{decimals}f}{suffix}"


def _fmt_market_cap(val) -> str:
    """Format market cap ke satuan T (triliun) atau M (miliar) Rupiah
    supaya lebih mudah dibaca daripada angka mentah belasan digit."""
    if val is None:
        return "N/A"
    if val >= 1e12:
        return f"Rp{val/1e12:,.1f} T"
    if val >= 1e9:
        return f"Rp{val/1e9:,.1f} M"
    return f"Rp{val:,.0f}"


def format_fundamental_message(data: dict) -> str:
    """Format hasil fetch_fundamental() jadi pesan Telegram. Dipisah
    dari handler supaya bisa ditest tanpa mock network.

    PENTING: nama_perusahaan/sektor/industri SUMBER EKSTERNAL (Yahoo
    Finance, tidak dikontrol bot ini) -- disanitasi via
    sanitize_for_markdown() sebelum masuk pesan Markdown (lihat catatan
    lengkap soal bug ini di core/messages.py)."""
    ticker = data["ticker"]
    nama = sanitize_for_markdown(data["nama_perusahaan"])
    sektor = sanitize_for_markdown(data.get("sektor")) or "N/A"
    industri = sanitize_for_markdown(data.get("industri")) or "N/A"

    msg = f"""
📊 *DATA FUNDAMENTAL* - {ticker}
{'='*35}

🏢 *{nama}*
Sektor: {sektor} | Industri: {industri}
Market Cap: {_fmt_market_cap(data.get('market_cap'))}

{'='*35}
💰 *VALUASI*
├─ PE Ratio (Trailing): {_fmt_num(data.get('pe_trailing'), 'x')}
├─ PE Ratio (Forward): {_fmt_num(data.get('pe_forward'), 'x')}
├─ PBV: {_fmt_num(data.get('pbv'), 'x')}
├─ PS Ratio: {_fmt_num(data.get('ps_ratio'), 'x')}
└─ EV/EBITDA: {_fmt_num(data.get('ev_ebitda'), 'x')}

{'='*35}
📈 *PROFITABILITAS*
├─ ROE: {_fmt_num(data.get('roe_pct'), '%')} _(estimasi, lihat catatan)_
├─ ROA: {_fmt_num(data.get('roa_pct'), '%')} _(estimasi, lihat catatan)_
└─ Net Margin: {_fmt_num(data.get('net_margin_pct'), '%')} _(estimasi, lihat catatan)_

{'='*35}
💵 *DIVIDEN*
├─ Dividend Yield: {_fmt_num(data.get('dividend_yield_pct'), '%')} _(estimasi, lihat catatan)_
└─ Payout Ratio: {_fmt_num(data.get('payout_ratio_pct'), '%')} _(estimasi, lihat catatan)_

{'='*35}
🏦 *LEVERAGE & LIKUIDITAS*
├─ DER (raw, asumsi sudah %): {_fmt_num(data.get('der_raw'), '%')}
└─ Current Ratio: {_fmt_num(data.get('current_ratio'), 'x')}

{'='*35}
📊 *PERTUMBUHAN (YoY)*
├─ Revenue Growth: {_fmt_num(data.get('revenue_growth_pct'), '%')}
└─ Earnings Growth: {_fmt_num(data.get('earnings_growth_pct'), '%')}

{'='*35}
📐 *PER SAHAM*
├─ EPS (Trailing): {_fmt_num(data.get('eps_trailing'), '', 0)}
├─ EPS (Forward): {_fmt_num(data.get('eps_forward'), '', 0)}
└─ Book Value/Share: {_fmt_num(data.get('book_value_per_share'), '', 0)}

{'='*35}
⚠️ *CATATAN PENTING*
• Data dari Yahoo Finance (yfinance), BUKAN diverifikasi langsung dari laporan keuangan resmi BEI/perusahaan.
• Field bertanda _(estimasi, lihat catatan)_ memakai heuristik untuk mendeteksi format angka (desimal vs persen) karena sumber datanya sendiri tidak konsisten -- BUKAN kesalahan kalkulasi, tapi ketidakpastian dari sumber.
• Saham dengan likuiditas rendah sering punya data tidak lengkap (N/A) di Yahoo Finance.
• SELALU cross-check ke laporan keuangan resmi sebelum mengambil keputusan investasi.
"""
    return msg


async def fundamental_cmd(update, context):
    """/fundamental KODE - Data fundamental saham (PE, PBV, ROE, dst)."""
    if not context.args:
        return await update.message.reply_text(
            "Usage: /fundamental BBCA\n\n"
            "Menampilkan data fundamental: PE Ratio, PBV, ROE, DER, "
            "Dividend Yield, EPS, dan pertumbuhan YoY."
        )

    ticker = context.args[0].upper() + ".JK"
    ticker_name = ticker.replace(".JK", "")

    await update.message.reply_text(f"📊 Mengambil data fundamental {ticker_name}...")

    data = await fetch_fundamental(ticker)

    if data is None:
        return await update.message.reply_text(
            f"❌ Gagal mengambil data fundamental {ticker_name}.\n\n"
            "Kemungkinan penyebab:\n"
            "• Kode saham tidak valid\n"
            "• Yahoo Finance tidak punya data fundamental untuk saham ini "
            "(umum terjadi untuk saham dengan likuiditas sangat rendah)\n"
            "• Koneksi/rate-limit Yahoo Finance sedang bermasalah\n\n"
            "Coba lagi dalam 1-2 menit, atau cek kode saham."
        )

    msg = format_fundamental_message(data)
    await update.message.reply_text(msg, parse_mode='Markdown')
