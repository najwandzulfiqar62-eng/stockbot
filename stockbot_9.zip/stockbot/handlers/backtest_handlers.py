# =========================
# HANDLER: BACKTEST SINYAL
# =========================
# FITUR BARU -- lihat catatan lengkap di core/backtest.py untuk
# keterbatasan dan disclaimer yang wajib disertakan.

from core.async_yf import async_download
from core.stock_data import fix_yf_columns
from core.backtest import backtest_condition, format_backtest_result, CONDITION_REGISTRY


async def _download_and_clean(ticker: str, period: str = "1y"):
    import pandas as pd
    df = await async_download(ticker, period=period, interval="1d", progress=False)
    df = fix_yf_columns(df)
    df = df.apply(pd.to_numeric, errors="coerce")
    df = df.dropna()
    return df


async def backtest_cmd(update, context):
    """/backtest BBCA [kondisi] [hari] - Validasi statistik historis
    untuk suatu kondisi sinyal.

    Contoh:
    /backtest BBCA -> pakai kondisi default (ma_cross_volume), 5 hari forward
    /backtest BBCA rsi_oversold -> kondisi RSI oversold
    /backtest BBCA golden_cross 10 -> golden cross, forward 10 hari
    """
    if not context.args:
        condition_list = "\n".join(f"• `{key}` — {label}" for key, (label, _) in CONDITION_REGISTRY.items())
        return await update.message.reply_text(
            "📊 *BACKTEST SINYAL*\n\n"
            "Usage: /backtest BBCA [kondisi] [hari]\n\n"
            "Kondisi yang tersedia:\n"
            f"{condition_list}\n\n"
            "Contoh:\n"
            "`/backtest BBCA` (default: ma_cross_volume, 5 hari)\n"
            "`/backtest BBCA rsi_oversold 10`\n\n"
            "⚠️ Ini validasi historis pada data yang sama, BUKAN bukti hasil masa depan. Selalu DYOR!",
            parse_mode='Markdown'
        )

    ticker = context.args[0].upper() + ".JK"
    ticker_name = ticker.replace(".JK", "")

    condition_key = context.args[1].lower() if len(context.args) >= 2 else "ma_cross_volume"
    if condition_key not in CONDITION_REGISTRY:
        valid_keys = ", ".join(CONDITION_REGISTRY.keys())
        return await update.message.reply_text(f"❌ Kondisi tidak dikenal. Pilihan: {valid_keys}")

    try:
        forward_days = int(context.args[2]) if len(context.args) >= 3 else 5
        forward_days = max(1, min(forward_days, 30))  # batasi 1-30 hari, jaga kewajaran
    except ValueError:
        forward_days = 5

    condition_label, condition_fn = CONDITION_REGISTRY[condition_key]

    await update.message.reply_text(f"📊 Menjalankan backtest *{condition_label}* untuk {ticker_name}...", parse_mode='Markdown')

    df = await _download_and_clean(ticker, period="1y")

    if len(df) < 50:
        return await update.message.reply_text(f"❌ Data historis {ticker_name} tidak cukup untuk backtest (minimal ~50 hari).")

    result = backtest_condition(df, condition_fn, forward_days=forward_days)
    msg = format_backtest_result(ticker_name, condition_label, result)
    await update.message.reply_text(msg, parse_mode='Markdown')
