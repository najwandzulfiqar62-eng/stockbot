# =========================
# HANDLERS: SCREENING PREMIUM
# =========================
# 6 command premium: /screenerpro, /multitimeframe, /patternscan,
# /correlation, /confluence, /backtestpro -- semua berbasis riset
# akademik dan praktis IDX, bukan ML. Lihat catatan metodologi
# lengkap di core/screening_pro.py.

import pandas as pd

from core.async_yf import async_download
from core.stock_data import fix_yf_columns, load_tickers
from core.screening_pro import (
    run_screenerpro, analyze_multitimeframe,
    detect_patterns, calculate_correlation,
    calculate_confluence, run_backtestpro,
)

SCREENING_TICKER_LIMIT = 200


async def _download_and_clean(ticker: str, period: str = "1y", interval: str = "1d"):
    import pandas as pd
    df = await async_download(ticker, period=period, interval=interval, progress=False)
    df = fix_yf_columns(df)
    df = df.apply(pd.to_numeric, errors="coerce").dropna()
    return df


# ──────────────────────────────────────────────
# /screenerpro MODE - scan seluruh 200 ticker
# ──────────────────────────────────────────────

SCREENERPRO_HELP = (
    "📊 *SCREENER PRO — Minervini Trend Template*\n\n"
    "Usage: `/screenerpro`\n\n"
    "Algoritma tunggal terbukti dari riset:\n"
    "• Minervini 8 Kriteria Teknikal (Stage 2 uptrend)\n"
    "• Konfirmasi MACD + RSI (73% win rate backtest)\n"
    "• Volume confirmation\n\n"
    "Hasil: saham dengan skor ≥65/100 = kandidat terkuat hari ini.\n"
    "⚠️ Berbasis data harga publik. Bukan rekomendasi investasi. DYOR!"
)


async def screenerpro_cmd(update, context):
    """/screenerpro - Screening Minervini Trend Template + MACD/RSI confirmation."""
    await update.message.reply_text(
        "🔍 *SCREENER PRO berjalan...*\n"
        "Algoritma: Minervini Trend Template + MACD/RSI\n"
        "Scanning 200 saham IDX, mohon tunggu ~30-60 detik.",
        parse_mode='Markdown'
    )

    # Download IHSG sebagai benchmark untuk RS calculation
    try:
        ihsg_raw = await async_download("^JKSE", period="1y", interval="1d", progress=False)
        ihsg_df = fix_yf_columns(ihsg_raw).apply(pd.to_numeric, errors="coerce").dropna()
        market_close = ihsg_df["Close"] if "Close" in ihsg_df.columns else None
    except Exception:
        market_close = None

    tickers = load_tickers(limit=SCREENING_TICKER_LIMIT)
    results = await run_screenerpro(tickers, market_close=market_close)

    if not results:
        return await update.message.reply_text(
            "❌ Tidak ada saham yang lolos kriteria Minervini hari ini.\n\n"
            "Ini normal di kondisi pasar bearish/sideways -- "
            "Minervini Trend Template hanya lolos saat ada Stage 2 uptrend yang jelas.\n"
            "Coba lagi besok atau di kondisi pasar yang lebih bullish."
        )

    msg = (
        f"🏆 *SCREENER PRO — MINERVINI TREND TEMPLATE*\n"
        f"{'='*40}\n\n"
        f"Ditemukan *{len(results)} saham* yang lolos dari 200 yang discan.\n\n"
    )

    for i, r in enumerate(results[:10], 1):
        criteria_bar = "✅" * r["criteria_met"] + "⬜" * (8 - r["criteria_met"])
        msg += (
            f"*{i}. {r['ticker']}* | Rp{r['harga']:,.0f} | Skor: *{r['skor']}/100*\n"
            f"   Minervini: {criteria_bar} ({r['criteria_met']}/8 kriteria)\n"
            f"   RS vs IHSG: {r['rs_score']:.0f} | RSI: {r['rsi']} | "
            f"Vol: {r['vol_ratio']}x | MACD: {'✅' if r['macd_bullish'] else '❌'}\n"
            f"   52W: {r['pct_from_52w_low']:+.0f}% dari low, {r['pct_from_52w_high']:.0f}% dari high\n\n"
        )

    if results:
        # Tampilkan top 1 dengan detail lengkap
        top = results[0]
        msg += f"{'='*40}\n"
        msg += f"📋 *DETAIL {top['ticker']}* (skor tertinggi):\n"
        if top["kriteria_lolos"]:
            msg += "✅ Lolos: " + ", ".join(top["kriteria_lolos"][:4]) + "\n"
        if top["kriteria_gagal"]:
            msg += "❌ Gagal: " + ", ".join(top["kriteria_gagal"][:3]) + "\n"

    msg += (
        f"\n{'='*40}\n"
        f"📚 *Metodologi*: Minervini SEPA Trend Template 8 kriteria "
        f"+ konfirmasi MACD+RSI (backtest 73% win rate, QuantifiedStrategies 2026) "
        f"+ volume. Threshold: skor ≥65/100.\n\n"
        f"⚠️ *DISCLAIMER*: Hasil ini adalah filter teknikal, bukan rekomendasi beli/jual. "
        f"Selalu lakukan analisis sendiri sebelum investasi."
    )

    await update.message.reply_text(msg, parse_mode='Markdown')


# ──────────────────────────────────────────────
# /multitimeframe KODE
# ──────────────────────────────────────────────

async def multitimeframe_cmd(update, context):
    """/multitimeframe BBCA - Analisis sinyal teknikal di 3 timeframe."""
    if not context.args:
        return await update.message.reply_text(
            "Usage: /multitimeframe BBCA\n\n"
            "Menganalisis sinyal RSI + MACD + MA20 di 3 timeframe: 1D, 1W, 1M.\n"
            "Alignment = semua timeframe searah (paling kuat untuk entry)."
        )

    ticker = context.args[0].upper()
    await update.message.reply_text(f"📊 Analisis multi-timeframe {ticker}...")

    result = await analyze_multitimeframe(ticker)
    if not result:
        return await update.message.reply_text(
            f"❌ Data {ticker} tidak cukup untuk analisis multi-timeframe (minimal ~1 tahun)."
        )

    msg = f"📊 *MULTI-TIMEFRAME* - {ticker}\n{'='*35}\n\n"
    for tf_label, tf_data in result["timeframes"].items():
        msg += f"*{tf_label}*\n"
        msg += f"  Sinyal: {tf_data['sinyal']}\n"
        msg += f"  RSI: {tf_data['rsi']} | "
        msg += f"MACD: {'✅' if tf_data['macd_bullish'] else '❌'} | "
        msg += f"MA20: {'✅' if tf_data['above_ma20'] else '❌'}\n\n"

    msg += f"*KESIMPULAN:*\n{result['alignment']}\n\n"
    msg += "⚠️ Multi-timeframe alignment bukan garansi arah harga. Selalu DYOR!"
    await update.message.reply_text(msg, parse_mode='Markdown')


# ──────────────────────────────────────────────
# /patternscan KODE
# ──────────────────────────────────────────────

async def patternscan_cmd(update, context):
    """/patternscan BBCA - Deteksi pola chart klasik (double top/bottom, HH/LL)."""
    if not context.args:
        return await update.message.reply_text(
            "Usage: /patternscan BBCA\n\n"
            "Mendeteksi pola chart berbasis swing points:\n"
            "• Double Top (bearish reversal)\n"
            "• Double Bottom (bullish reversal)\n"
            "• Higher Highs/Lower Lows (konfirmasi tren)\n\n"
            "Non-repainting: hanya menggunakan bar yang sudah terkonfirmasi."
        )

    ticker = context.args[0].upper()
    df = await _download_and_clean(ticker + ".JK", period="1y")

    if len(df) < 60:
        return await update.message.reply_text(
            f"❌ Data {ticker} tidak cukup (minimal ~60 hari)."
        )

    result = detect_patterns(df, ticker)
    msg = f"🔍 *PATTERN SCAN* - {ticker}\n{'='*35}\n\n"
    msg += f"Harga saat ini: Rp{result['harga']:,.0f}\n\n"

    if not result["patterns"]:
        msg += "Tidak ada pola chart yang terdeteksi dengan jelas saat ini.\n"
    else:
        for p in result["patterns"]:
            msg += f"{p['emoji']} *{p['nama']}* ({p['bias']})\n"
            msg += f"  └ {p['desc']}\n\n"

    msg += "⚠️ Pola chart bersifat subjektif dan sering gagal. Konfirmasi dengan indikator lain."
    await update.message.reply_text(msg, parse_mode='Markdown')


# ──────────────────────────────────────────────
# /correlation KODE1 KODE2
# ──────────────────────────────────────────────

async def correlation_cmd(update, context):
    """/correlation BBCA IHSG - Korelasi Pearson rolling 60 hari antar dua aset."""
    if len(context.args) < 2:
        return await update.message.reply_text(
            "Usage: /correlation BBCA IHSG\n"
            "       /correlation BBCA BBRI\n\n"
            "Hitung korelasi Pearson rolling 60 hari antara dua saham, "
            "atau saham vs IHSG. Pakai 'IHSG' untuk benchmark pasar."
        )

    ticker_a = context.args[0].upper()
    ticker_b = context.args[1].upper()
    await update.message.reply_text(f"📊 Menghitung korelasi {ticker_a} vs {ticker_b}...")

    result = await calculate_correlation(ticker_a, ticker_b)
    if not result:
        return await update.message.reply_text(
            f"❌ Gagal menghitung korelasi {ticker_a} vs {ticker_b}. "
            "Data tidak cukup (minimal ~60 hari data bersama)."
        )

    corr_emoji = "🔴" if result["corr_now"] < 0 else "🟢" if result["corr_now"] > 0.5 else "🟡"
    msg = (
        f"📊 *KORELASI* - {result['ticker_a']} vs {result['ticker_b']}\n"
        f"{'='*35}\n\n"
        f"Korelasi saat ini (60 hari): {corr_emoji} *{result['corr_now']:+.3f}*\n"
        f"Rata-rata historis (1 tahun): {result['corr_avg']:+.3f}\n\n"
        f"📖 {result['interpretasi']}\n\n"
        f"📈 {result['perubahan']}\n\n"
        f"_(Berdasarkan {result['n_observations']} hari observasi bersama)_\n\n"
        f"⚠️ Korelasi historis bisa berubah sewaktu-waktu, terutama di kondisi pasar ekstrem."
    )
    await update.message.reply_text(msg, parse_mode='Markdown')


# ──────────────────────────────────────────────
# /confluence KODE
# ──────────────────────────────────────────────

async def confluence_cmd(update, context):
    """/confluence BBCA - Cek alignment 6 indikator teknikal sekaligus."""
    if not context.args:
        return await update.message.reply_text(
            "Usage: /confluence BBCA\n\n"
            "Mengecek alignment 6 indikator: RSI, MACD, MA20, Bollinger Band, "
            "StochRSI, Volume. Makin banyak yang searah, makin kuat konfluensi sinyal."
        )

    ticker = context.args[0].upper()
    df = await _download_and_clean(ticker + ".JK", period="6mo")

    if len(df) < 30:
        return await update.message.reply_text(
            f"❌ Data {ticker} tidak cukup (minimal ~30 hari)."
        )

    result = calculate_confluence(df, ticker)
    msg = (
        f"🔀 *CONFLUENCE* - {ticker}\n"
        f"{'='*35}\n\n"
        f"Harga: Rp{result['harga']:,.0f}\n\n"
    )

    emoji_map = {"BULLISH": "🟢", "BEARISH": "🔴", "NETRAL": "⚪"}
    for ind_name, (signal, desc) in result["indicators"].items():
        msg += f"{emoji_map[signal]} *{ind_name}*: {desc}\n"

    msg += (
        f"\n*Ringkasan:* {result['bullish']} bullish | {result['bearish']} bearish | "
        f"{result['netral']} netral\n\n"
        f"*{result['kesimpulan']}*\n\n"
        f"⚠️ Confluence tinggi mengurangi false positive, tapi tidak menghilangkan risiko. DYOR!"
    )
    await update.message.reply_text(msg, parse_mode='Markdown')


# ──────────────────────────────────────────────
# /backtestpro KODE [mode] [windows]
# ──────────────────────────────────────────────

async def backtestpro_cmd(update, context):
    """/backtestpro BBCA [mode] - Walk-forward validation kondisi teknikal."""
    if not context.args:
        return await update.message.reply_text(
            "Usage: /backtestpro BBCA [mode] [windows]\n\n"
            "Mode: `momentum` | `breakout` | `quality` (default: momentum)\n"
            "Windows: 2-6 periode walk-forward (default: 4)\n\n"
            "Contoh:\n"
            "`/backtestpro BBCA`\n"
            "`/backtestpro BBCA breakout 4`\n\n"
            "Walk-forward lebih rigorous dari backtest biasa karena setiap "
            "window test-nya out-of-sample relatif terhadap window sebelumnya.\n\n"
            "⚠️ Hasil historis BUKAN garansi performa masa depan. DYOR!"
        )

    ticker = context.args[0].upper()
    mode = context.args[1].lower() if len(context.args) >= 2 else "momentum"
    if mode not in ("momentum", "breakout", "quality"):
        return await update.message.reply_text(
            f"❌ Mode tidak dikenal: `{mode}`. Pilihan: momentum | breakout | quality",
            parse_mode='Markdown'
        )

    try:
        n_windows = int(context.args[2]) if len(context.args) >= 3 else 4
        n_windows = max(2, min(n_windows, 6))
    except ValueError:
        n_windows = 4

    await update.message.reply_text(
        f"📊 Walk-forward backtest *{ticker}* mode *{mode}* ({n_windows} windows)...",
        parse_mode='Markdown'
    )

    df = await _download_and_clean(ticker + ".JK", period="2y")
    if len(df) < 120:
        return await update.message.reply_text(
            f"❌ Data {ticker} tidak cukup (minimal ~120 hari, idealnya 2 tahun)."
        )

    result = run_backtestpro(df, ticker, mode=mode, n_windows=n_windows)
    if not result:
        return await update.message.reply_text(
            f"❌ Tidak ada sinyal `{mode}` yang cukup di data historis {ticker} "
            f"untuk walk-forward backtest (minimal 5 sinyal per window). "
            "Coba mode lain atau saham lain.",
            parse_mode='Markdown'
        )

    msg = (
        f"📊 *BACKTEST PRO (WALK-FORWARD)* - {ticker}\n"
        f"{'='*35}\n\n"
        f"Mode: *{mode}* | {result['n_windows']} windows\n"
        f"Total sinyal: {result['total_n']}\n\n"
        f"Win Rate (weighted): *{result['weighted_win_rate']}%*\n"
        f"Avg Return per sinyal: {result['avg_return']:+.2f}%\n"
        f"Konsistensi: {result['konsistensi']}\n\n"
        "*Rincian per window:*\n"
    )
    for w in result["window_details"]:
        msg += (
            f"  Window {w['window']}: {w['n']} sinyal | "
            f"win {w['win_rate']}% | avg ret {w['avg_return']:+.2f}%\n"
        )

    msg += (
        "\n⚠️ *Penting:* win rate historis ≠ garansi masa depan. "
        "Hasil di bawah 55% tidak berbeda signifikan dari random. "
        "Selalu DYOR dan pakai manajemen risiko."
    )
    await update.message.reply_text(msg, parse_mode='Markdown')
