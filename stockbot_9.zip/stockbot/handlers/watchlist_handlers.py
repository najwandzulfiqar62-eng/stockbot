# =========================
# HANDLERS: WATCHLIST
# =========================
# PERUBAHAN dari main.py lama:
# - wlstatus_cmd, checkalerts_cmd, rekap_watchlist_cmd dulu masing-masing
#   loop SEQUENTIAL melalui setiap ticker di watchlist dengan yf.download
#   satu per satu. Untuk user dengan banyak saham di watchlist, ini
#   berarti waktu tunggu = jumlah_saham x waktu_download, dan memblokir
#   bot untuk user lain selama itu. Sekarang semua download untuk satu
#   watchlist dilakukan PARALEL via async_download_many(), jadi totalnya
#   ~waktu download 1 saham saja (untuk watchlist berukuran wajar),
#   bukan dikali jumlah saham.
# - watchlist_cmd "add"/"update" dulu memanggil calculate_fixed_entry_
#   levels(ticker) yang download+kalkulasi sekaligus secara sinkron.
#   Sekarang dipisah: download via async_download (non-blocking), lalu
#   calculate_fixed_entry_levels_from_df() (core/trading_plan.py, sudah
#   diverifikasi numerik match 100% dengan versi lama).

import os
from datetime import datetime

import pandas as pd

from core.database import (
    save_user_to_db, get_user_watchlist_db, get_fixed_entries_db,
    get_all_fixed_entries_for_user, add_to_watchlist_db, remove_from_watchlist_db,
    check_alert_sent_db, save_alert_history_db, set_user_subscription,
)
from core.async_yf import async_download, async_download_many
from core.stock_data import fix_yf_columns
from core.trading_plan import calculate_fixed_entry_levels_from_df, get_hit_scenarios


async def _download_and_clean(ticker: str, period: str = "6mo"):
    df = await async_download(ticker, period=period, interval="1d", progress=False)
    df = fix_yf_columns(df)
    df = df.apply(pd.to_numeric, errors="coerce")
    df = df.dropna()
    return df


async def watchlist_cmd(update, context):
    """Kelola watchlist dengan entry level FIX (tidak berubah)."""
    user_id = str(update.effective_user.id)
    username = update.effective_user.username or ""
    save_user_to_db(user_id, username)

    if not context.args:
        return await update.message.reply_text(
            "⭐ WATCHLIST COMMAND\n\n"
            "/watchlist add BBCA - Tambah saham (entry level dihitung SEKALI & FIX)\n"
            "/watchlist remove BBCA - Hapus saham\n"
            "/watchlist show - Lihat watchlist\n"
            "/watchlist update BBCA - Update entry level\n"
            "/rekapwl - Lihat rekap performa\n\n"
            "💡 Entry level TIDAK AKAN BERUBAH meskipun harga saham bergerak!"
        )

    action = context.args[0].lower()

    # ---- SHOW ----
    if action == "show":
        watchlist = get_user_watchlist_db(user_id)
        if not watchlist:
            return await update.message.reply_text("📭 Watchlist kosong")

        msg = "⭐ *WATCHLIST (ENTRY LEVEL FIX/TIDAK BERUBAH)*\n" + "=" * 50 + "\n\n"
        for w in watchlist:
            ticker = w['ticker']
            entries = get_fixed_entries_db(user_id, ticker)
            if entries:
                sc = entries['scenarios']
                msg += f"📌 *{ticker}*\n"
                msg += f"   📅 Tanggal add: {entries.get('created_date', '-')}\n"
                msg += f"   💰 Harga saat add: Rp{w['price_at_add']:,}\n"
                msg += "\n   🎯 *LEVEL ENTRY (FIX/TIDAK BERUBAH):*\n"
                msg += f"   ├─ 📊 NORMAL    : Rp{sc['normal']['entry']:,}\n"
                msg += f"   ├─ 📉 PULLBACK  : Rp{sc['pullback']['entry']:,}\n"
                msg += f"   ├─ 🔻 DEEP      : Rp{sc['deep']['entry']:,}\n"
                msg += f"   └─ 🚀 BREAKOUT  : Rp{sc['breakout']['entry']:,}\n"
                msg += "\n   🎯 *TP/SL (FIX/TIDAK BERUBAH):*\n"
                msg += f"   ├─ TP1: +{sc['normal']['tp1_pct']}% → Rp{sc['normal']['tp1']:,}\n"
                msg += f"   ├─ TP2: +{sc['normal']['tp2_pct']}% → Rp{sc['normal']['tp2']:,}\n"
                msg += f"   ├─ TP3: +{sc['normal']['tp3_pct']}% → Rp{sc['normal']['tp3']:,}\n"
                msg += f"   └─ SL : -{sc['normal']['risk_pct']}% → Rp{sc['normal']['sl']:,}\n\n"
            else:
                msg += f"⚠️ {ticker} (belum ada entry level, gunakan /watchlist update {ticker})\n\n"

        return await update.message.reply_text(msg, parse_mode='Markdown')

    # ---- ADD ----
    if action == "add":
        if len(context.args) < 2:
            return await update.message.reply_text("Contoh: /watchlist add BBCA")

        stock = context.args[1].upper()
        watchlist = get_user_watchlist_db(user_id)

        if stock in [w['ticker'] for w in watchlist]:
            return await update.message.reply_text(f"⚠️ {stock} sudah ada di watchlist")

        await update.message.reply_text(
            f"📊 Menghitung entry level untuk {stock} (SEKALI & TIDAK AKAN BERUBAH)..."
        )

        df = await _download_and_clean(stock + ".JK")
        created_date_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        fixed_levels = calculate_fixed_entry_levels_from_df(df, created_date_str)

        if fixed_levels:
            add_to_watchlist_db(user_id, stock, fixed_levels)
            sc = fixed_levels['scenarios']
            msg = (
                f"✅ *{stock} BERHASIL DITAMBAHKAN!*\n\n"
                f"📅 Tanggal entry: {fixed_levels['created_date']}\n"
                f"💰 Harga saat add: Rp{fixed_levels['price_at_create']:,.0f}\n\n"
                f"📊 *LEVEL ENTRY (FIX/TIDAK AKAN BERUBAH):*\n"
                f"├─ 📊 NORMAL    : Rp{sc['normal']['entry']:,.0f}\n"
                f"├─ 📉 PULLBACK  : Rp{sc['pullback']['entry']:,.0f}\n"
                f"├─ 🔻 DEEP      : Rp{sc['deep']['entry']:,.0f}\n"
                f"└─ 🚀 BREAKOUT  : Rp{sc['breakout']['entry']:,.0f}\n\n"
                f"🎯 *TP/SL (FIX/TIDAK AKAN BERUBAH):*\n"
                f"├─ TP1: +{sc['normal']['tp1_pct']}% → Rp{sc['normal']['tp1']:,.0f}\n"
                f"├─ TP2: +{sc['normal']['tp2_pct']}% → Rp{sc['normal']['tp2']:,.0f}\n"
                f"├─ TP3: +{sc['normal']['tp3_pct']}% → Rp{sc['normal']['tp3']:,.0f}\n"
                f"└─ SL : -{sc['normal']['risk_pct']}% → Rp{sc['normal']['sl']:,.0f}\n\n"
                f"💡 Entry level ini TIDAK AKAN PERNAH BERUBAH!\n"
                f"📊 Jalankan /rekapwl untuk update status (RUNNING/TP1/TP2/TP3/SL)"
            )
            await update.message.reply_text(msg, parse_mode='Markdown')
        else:
            return await update.message.reply_text(
                f"❌ Gagal menghitung entry level untuk {stock}. Data tidak cukup."
            )
        return

    # ---- UPDATE ----
    if action == "update":
        if len(context.args) < 2:
            return await update.message.reply_text("Contoh: /watchlist update BBCA")

        stock = context.args[1].upper()
        watchlist = get_user_watchlist_db(user_id)
        if stock not in [w['ticker'] for w in watchlist]:
            return await update.message.reply_text(f"⚠️ {stock} tidak ada di watchlist")

        await update.message.reply_text(f"📊 Update entry level untuk {stock}...")

        df = await _download_and_clean(stock + ".JK")
        created_date_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        fixed_levels = calculate_fixed_entry_levels_from_df(df, created_date_str)

        if fixed_levels:
            add_to_watchlist_db(user_id, stock, fixed_levels)
            await update.message.reply_text(
                f"✅ Entry level untuk {stock} berhasil diupdate!\n"
                f"📅 Tanggal update: {fixed_levels['created_date']}"
            )
        else:
            return await update.message.reply_text(f"❌ Gagal update entry level untuk {stock}.")
        return

    # ---- REMOVE ----
    if action == "remove":
        if len(context.args) < 2:
            return await update.message.reply_text("Contoh: /watchlist remove BBCA")
        stock = context.args[1].upper()
        remove_from_watchlist_db(user_id, stock)
        return await update.message.reply_text(f"❌ {stock} dihapus dari watchlist")

    await update.message.reply_text("❌ Command tidak dikenal. Gunakan: add, remove, show, update")


async def wlstatus_cmd(update, context):
    """Status cepat watchlist — entry yang kena sesuai High/Low hari ini."""
    user_id = str(update.effective_user.id)
    watchlist = get_user_watchlist_db(user_id)

    if not watchlist:
        return await update.message.reply_text("📭 Watchlist kosong")

    await update.message.reply_text(f"📊 Cek status {len(watchlist)} saham...")

    tickers = [item['ticker'] + ".JK" for item in watchlist]
    data_by_ticker = await async_download_many(tickers, period="2d", interval="1d")

    msg = (
        f"📊 *WATCHLIST STATUS*\n"
        f"{datetime.now().strftime('%d %B %Y, %H:%M')}\n"
        f"{'='*35}\n\n"
    )

    for item in watchlist:
        ticker = item['ticker']
        full_ticker = ticker + ".JK"
        try:
            df = data_by_ticker.get(full_ticker)
            if df is None:
                msg += f"❌ *{ticker}*: No data\n\n"
                continue
            df = fix_yf_columns(df).dropna()

            if df.empty:
                msg += f"❌ *{ticker}*: No data\n\n"
                continue

            current_price = float(df["Close"].iloc[-1])
            low_today = float(df["Low"].iloc[-1])
            high_today = float(df["High"].iloc[-1])
            prev_close = float(df["Close"].iloc[-2]) if len(df) >= 2 else current_price
            daily_change = ((current_price / prev_close) - 1) * 100
            emoji = "🟢" if daily_change >= 0 else "🔴"

            fixed = get_fixed_entries_db(user_id, ticker)
            if not fixed:
                msg += f"{emoji} *{ticker}*: Rp{current_price:,.0f} | {daily_change:+.2f}%\n"
                msg += "   ⚠️ Belum ada entry level\n\n"
                continue

            scenarios = fixed['scenarios']
            hit_scenarios = get_hit_scenarios(scenarios, low_today, high_today)

            msg += f"{emoji} *{ticker}*\n"
            msg += f"   💰 Close : Rp{current_price:,.0f} ({daily_change:+.2f}%)\n"
            msg += f"   📊 Range : Rp{low_today:,.0f} – Rp{high_today:,.0f}\n"

            if hit_scenarios:
                for h in hit_scenarios:
                    sc = h["scenario"]
                    ep = h["entry_price"]
                    pct_now = ((current_price - ep) / ep) * 100

                    if current_price >= sc["tp3"]:
                        trade_status = f"🏆 TP3 HIT (+{sc['tp3_pct']}%)"
                    elif current_price >= sc["tp2"]:
                        trade_status = f"🥈 TP2 HIT (+{sc['tp2_pct']}%)"
                    elif current_price >= sc["tp1"]:
                        trade_status = f"🥉 TP1 HIT (+{sc['tp1_pct']}%)"
                    elif current_price <= sc["sl"]:
                        trade_status = f"💀 SL HIT (-{sc['risk_pct']}%)"
                    elif pct_now >= 0:
                        trade_status = f"🟢 RUNNING (+{pct_now:.1f}%)"
                    else:
                        trade_status = f"🔴 RUNNING ({pct_now:.1f}%)"

                    msg += (
                        f"   🎯 *KENA: {sc['display_name']}*\n"
                        f"   ├─ Entry  : Rp{ep:,.0f}\n"
                        f"   ├─ TP1    : Rp{sc['tp1']:,.0f} (+{sc['tp1_pct']}%)\n"
                        f"   ├─ TP2    : Rp{sc['tp2']:,.0f} (+{sc['tp2_pct']}%)\n"
                        f"   ├─ TP3    : Rp{sc['tp3']:,.0f} (+{sc['tp3_pct']}%)\n"
                        f"   ├─ SL     : Rp{sc['sl']:,.0f} (-{sc['risk_pct']}%)\n"
                        f"   └─ Status : {trade_status}\n"
                    )
            else:
                all_sc = [(k, s) for k, s in scenarios.items()]
                above = [(k, s) for k, s in all_sc if s["entry"] > high_today]
                below = [(k, s) for k, s in all_sc if s["entry"] < low_today]

                msg += "   ⏳ Belum ada entry kena hari ini\n"

                if above:
                    na = min(above, key=lambda x: x[1]["entry"] - high_today)
                    gap = ((na[1]["entry"] - current_price) / current_price) * 100
                    msg += (
                        f"   ⬆️ Terdekat atas: {na[1]['display_name']} "
                        f"Rp{na[1]['entry']:,.0f} (+{gap:.1f}%)\n"
                    )
                if below:
                    nb = max(below, key=lambda x: x[1]["entry"])
                    gap = ((current_price - nb[1]["entry"]) / current_price) * 100
                    msg += (
                        f"   ⬇️ Terdekat bawah: {nb[1]['display_name']} "
                        f"Rp{nb[1]['entry']:,.0f} (-{gap:.1f}%)\n"
                    )

            msg += "\n"

        except Exception as e:
            print(f"Error wlstatus {ticker}: {e}")
            msg += f"❌ *{ticker}*: Error\n\n"

    msg += "💡 /checkalerts untuk alert detail\n📌 /rekapwl untuk rekap Excel"
    await update.message.reply_text(msg, parse_mode='Markdown')


async def checkalerts_cmd(update, context):
    """Manual check alerts untuk semua saham di watchlist."""
    user_id = str(update.effective_user.id)
    watchlist = get_user_watchlist_db(user_id)
    fixed_entries = get_all_fixed_entries_for_user(user_id)

    if not watchlist:
        return await update.message.reply_text("📭 Watchlist kosong")

    await update.message.reply_text(f"🔍 Mengecek {len(watchlist)} saham...")

    today = datetime.now().strftime("%Y-%m-%d")
    alerts_found = []

    relevant_tickers = [item['ticker'] for item in watchlist if item['ticker'] in fixed_entries]
    full_tickers = [t + ".JK" for t in relevant_tickers]
    data_by_ticker = await async_download_many(full_tickers, period="2d", interval="1d")

    for ticker in relevant_tickers:
        full_ticker = ticker + ".JK"
        try:
            df = data_by_ticker.get(full_ticker)
            if df is None:
                continue
            df = fix_yf_columns(df).dropna()

            if df.empty or len(df) < 2:
                continue

            low_today = float(df["Low"].iloc[-1])
            high_today = float(df["High"].iloc[-1])
            current_price = float(df["Close"].iloc[-1])

            for key, scenario in fixed_entries[ticker]["scenarios"].items():
                entry_price = scenario["entry"]
                if low_today <= entry_price <= high_today:
                    if not check_alert_sent_db(user_id, ticker, key, today):
                        save_alert_history_db(user_id, ticker, key, today, "MANUAL_CHECK")
                        msg = (
                            f"🎯 *ALERT: {ticker}*\n\n"
                            f"✅ *{scenario['display_name']}* TERKENA!\n\n"
                            f"📊 Entry: Rp{entry_price:,.0f}\n"
                            f"💰 Harga sekarang: Rp{current_price:,.0f}\n"
                            f"🎯 TP1: Rp{scenario['tp1']:,.0f} (+{scenario['tp1_pct']}%)\n"
                            f"🛑 SL: Rp{scenario['sl']:,.0f} (-{scenario['risk_pct']}%)\n\n"
                            f"💡 Rekomendasi entry di Rp{entry_price:,.0f}\n"
                            f"⚠️ DYOR!"
                        )
                        alerts_found.append(msg)
                        break

        except Exception as e:
            print(f"Error checking {ticker}: {e}")
            continue

    if alerts_found:
        for alert in alerts_found:
            await update.message.reply_text(alert, parse_mode='Markdown')
        await update.message.reply_text(f"✅ Total {len(alerts_found)} alert ditemukan!")
    else:
        await update.message.reply_text("✅ Tidak ada alert baru hari ini.")


async def rekap_watchlist_cmd(update, context):
    """Rekap watchlist ke Excel: Sheet 1 (plan terbaik per saham), Sheet 2
    (detail semua 4 skenario)."""
    user_id = str(update.effective_user.id)

    watchlist = get_user_watchlist_db(user_id)
    fixed_entries = get_all_fixed_entries_for_user(user_id)

    if not watchlist:
        return await update.message.reply_text(
            "📭 Watchlist kosong!\n\nTambahkan saham dulu:\n/watchlist add BBCA"
        )

    await update.message.reply_text(
        f"📊 Merekap {len(watchlist)} saham...\n"
        "✅ Entry dipilih berdasarkan Low/High hari ini"
    )

    relevant_tickers = [item['ticker'] for item in watchlist if item['ticker'] in fixed_entries]
    full_tickers = [t + ".JK" for t in relevant_tickers]
    data_by_ticker = await async_download_many(full_tickers, period="5d", interval="1d", auto_adjust=False)

    sheet1_results = []
    sheet2_raw = []

    for item in watchlist:
        ticker = item['ticker']
        try:
            if ticker not in fixed_entries:
                continue

            full_ticker = ticker + ".JK"
            df = data_by_ticker.get(full_ticker)
            if df is None:
                continue
            df = fix_yf_columns(df)
            df = df.apply(pd.to_numeric, errors='coerce')
            df = df.dropna()

            if df.empty:
                continue

            low_today = float(df["Low"].iloc[-1])
            high_today = float(df["High"].iloc[-1])
            open_price = float(df["Open"].iloc[-1])
            close_price = float(df["Close"].iloc[-1])
            prev_close = float(df["Close"].iloc[-2]) if len(df) >= 2 else close_price
            daily_change = ((close_price / prev_close) - 1) * 100

            fixed = fixed_entries[ticker]
            scenarios = fixed["scenarios"]
            created_date = fixed.get("created_date", "-")
            price_at_add = item.get("price_at_add", 0)

            hit_list = get_hit_scenarios(scenarios, low_today, high_today)
            hit_keys = {h["key"] for h in hit_list}

            for key, sc in scenarios.items():
                sheet2_raw.append({
                    "Saham": ticker,
                    "Skenario": sc["display_name"],
                    "Status": "✅ KENA" if key in hit_keys else "❌ TIDAK KENA",
                    "Entry (FIX)": f"Rp{sc['entry']:,.0f}",
                    "SL (FIX)": f"Rp{sc['sl']:,.0f}",
                    "Risk %": f"{sc['risk_pct']}%",
                    "TP1 %": f"+{sc['tp1_pct']}%",
                    "TP1 (FIX)": f"Rp{sc['tp1']:,.0f}",
                    "TP2 %": f"+{sc['tp2_pct']}%",
                    "TP2 (FIX)": f"Rp{sc['tp2']:,.0f}",
                    "TP3 %": f"+{sc['tp3_pct']}%",
                    "TP3 (FIX)": f"Rp{sc['tp3']:,.0f}",
                })

            if hit_list:
                best = hit_list[0]
                sc = best["scenario"]
                hit_entry = best["entry_price"]
                pct_entry = ((close_price - hit_entry) / hit_entry) * 100

                if close_price >= sc["tp3"]:
                    tp_status = f"🏆 TP3 HIT (+{sc['tp3_pct']}%)"
                elif close_price >= sc["tp2"]:
                    tp_status = f"🥈 TP2 HIT (+{sc['tp2_pct']}%)"
                elif close_price >= sc["tp1"]:
                    tp_status = f"🥉 TP1 HIT (+{sc['tp1_pct']}%)"
                elif close_price <= sc["sl"]:
                    tp_status = f"💀 STOP LOSS (-{sc['risk_pct']}%)"
                elif pct_entry >= 0:
                    tp_status = f"🟢 RUNNING (+{pct_entry:.1f}%)"
                else:
                    tp_status = f"🔴 RUNNING ({pct_entry:.1f}%)"

                other_hits = ", ".join(
                    h["scenario"]["display_name"] for h in hit_list[1:]
                ) if len(hit_list) > 1 else "-"

                sheet1_results.append({
                    "ticker": ticker, "created_date": created_date, "price_at_add": price_at_add,
                    "open": open_price, "low": low_today, "high": high_today, "close": close_price,
                    "daily_change": daily_change, "skenario_kena": sc["display_name"],
                    "entry": hit_entry, "pct_entry": pct_entry, "status": tp_status,
                    "tp1_pct": sc["tp1_pct"], "tp1": sc["tp1"],
                    "tp2_pct": sc["tp2_pct"], "tp2": sc["tp2"],
                    "tp3_pct": sc["tp3_pct"], "tp3": sc["tp3"],
                    "sl": sc["sl"], "risk_pct": sc["risk_pct"], "other_hits": other_hits,
                })
            else:
                sheet1_results.append({
                    "ticker": ticker, "created_date": created_date, "price_at_add": price_at_add,
                    "open": open_price, "low": low_today, "high": high_today, "close": close_price,
                    "daily_change": daily_change, "skenario_kena": "BELUM KENA",
                    "entry": None, "pct_entry": None, "status": "-",
                    "tp1_pct": "-", "tp1": "-", "tp2_pct": "-", "tp2": "-", "tp3_pct": "-", "tp3": "-",
                    "sl": "-", "risk_pct": "-", "other_hits": "-",
                })

        except Exception as e:
            print(f"Error rekap {ticker}: {e}")
            continue

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    excel_file = f"watchlist_rekap_{timestamp}.xlsx"

    with pd.ExcelWriter(excel_file, engine='openpyxl') as writer:
        s1_data = []
        for r in sheet1_results:
            def fp(v):
                return f"Rp{v:,.0f}" if v is not None and v != "-" else "-"

            def fpc(v):
                return f"{v:+.2f}%" if v is not None and v != "-" else "-"

            def ftp(pct, price):
                return f"+{pct}% → {fp(price)}" if price != "-" else "-"

            s1_data.append({
                "Saham": r["ticker"], "Tanggal Add": r["created_date"], "Harga Add": fp(r["price_at_add"]),
                "Open": fp(r["open"]), "Low": fp(r["low"]), "High": fp(r["high"]), "Close": fp(r["close"]),
                "Daily %": fpc(r["daily_change"]), "SKENARIO KENA": r["skenario_kena"],
                "Entry Price": fp(r["entry"]), "P&L dari Entry": fpc(r["pct_entry"]), "STATUS": r["status"],
                "TP1": ftp(r["tp1_pct"], r["tp1"]), "TP2": ftp(r["tp2_pct"], r["tp2"]),
                "TP3": ftp(r["tp3_pct"], r["tp3"]),
                "SL": f"-{r['risk_pct']}% → {fp(r['sl'])}" if r["sl"] != "-" else "-",
                "Skenario Lain Kena": r["other_hits"],
            })

        pd.DataFrame(s1_data).to_excel(writer, sheet_name="REKAP_WATCHLIST", index=False)
        pd.DataFrame(sheet2_raw).to_excel(writer, sheet_name="DETAIL_SKENARIO", index=False)

    kena_count = sum(1 for r in sheet1_results if r["skenario_kena"] != "BELUM KENA")

    with open(excel_file, "rb") as f:
        await update.message.reply_document(
            f,
            caption=(
                f"📊 *WATCHLIST REKAP*\n"
                f"{datetime.now().strftime('%Y-%m-%d %H:%M')}\n"
                f"{'='*35}\n\n"
                f"📈 Total saham  : {len(sheet1_results)}\n"
                f"✅ Plan KENA    : {kena_count} saham\n"
                f"❌ Belum kena   : {len(sheet1_results) - kena_count} saham\n\n"
                f"📁 *Isi Excel:*\n"
                f"• REKAP\\_WATCHLIST  : 1 plan terbaik per saham\n"
                f"• DETAIL\\_SKENARIO  : Semua 4 skenario (✅/❌)\n\n"
                f"Logika: Deep jika Low sampai Deep, Pullback jika Low sampai S1,\n"
                f"Breakout jika High tembus breakout level, Normal jika hanya area Normal"
            ),
            parse_mode='Markdown'
        )
    os.remove(excel_file)


async def subscribe_cmd(update, context):
    """Subscribe daily summary."""
    user_id = str(update.effective_user.id)
    username = update.effective_user.username or ""
    save_user_to_db(user_id, username)
    set_user_subscription(user_id, True)
    await update.message.reply_text(
        "✅ *Berlangganan Daily Summary!*\n\n"
        "Anda akan menerima:\n"
        "🌅 Morning Summary (08:30 WIB)\n"
        "🌙 Evening Summary (16:30 WIB)\n"
        "🔔 Auto-alert jika harga saham watchlist menyentuh entry level\n\n"
        "Untuk berhenti: /unsubscribe",
        parse_mode='Markdown'
    )


async def unsubscribe_cmd(update, context):
    """Unsubscribe daily summary."""
    user_id = str(update.effective_user.id)
    set_user_subscription(user_id, False)
    await update.message.reply_text(
        "❌ Anda telah berhenti dari daily summary & auto-alert.\n\n"
        "Untuk berlangganan lagi: /subscribe"
    )
