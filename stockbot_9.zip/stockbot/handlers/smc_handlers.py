# =========================
# HANDLERS: SMART MONEY CONCEPTS (SMC)
# =========================
# FITUR BARU. /bos, /choch, /orderblock, /fvg, /liquidity -- semuanya
# memakai core/smc.py (lihat catatan metodologi & disclaimer LENGKAP
# di file itu -- termasuk soal "marketing narrative" yang dikonfirmasi
# dari riset AlgoStorm). Kelima command berbagi pola: download data,
# jalankan fungsi deteksi terkait, format hasil PALING BARU/relevan
# dengan disclaimer yang konsisten.
#
# CATATAN soal /bos vs /choch: detect_bos_choch() di core/smc.py
# mengembalikan SATU list gabungan (event BOS dan CHOCH bercampur,
# urut kronologis) -- karena keduanya memang dideteksi dari logic yang
# sama (breakout swing level, beda label berdasarkan trend konteks).
# Handler /bos memfilter list ini untuk event type=='BOS' paling baru,
# /choch untuk type=='CHOCH' paling baru. Kalau salah satu jenis tidak
# ditemukan di window data, handler bilang jujur "tidak ditemukan",
# BUKAN menampilkan event jenis lain sebagai gantinya.
#
# DESAIN: logic format pesan diekstrak jadi fungsi PURE (format_*)
# yang menerima df + hasil deteksi, mengembalikan string -- supaya
# command handler (bos_cmd dkk) dan menu callback (stock_menu_handlers.
# py: action bos/choch/orderblock/fvg/liquidity) bisa memanggil fungsi
# format yang SAMA tanpa duplikasi logic. Satu sumber kebenaran untuk
# format pesan; kalau nanti diperbaiki, otomatis konsisten di kedua
# tempat pemanggilan.

import os
import asyncio
import pandas as pd

from core.async_yf import async_download
from core.stock_data import fix_yf_columns
from core.smc import detect_bos_choch, detect_order_blocks, detect_fvg, detect_liquidity_pools
from core.charts.smc_chart import (
    generate_bos_chart, generate_choch_chart, generate_orderblock_chart,
    generate_fvg_chart, generate_liquidity_chart,
)

SMC_DISCLAIMER = (
    "\n\n⚠️ _SMC membaca pola harga (struktur, gap, swing point), BUKAN data transaksi "
    "institusi sungguhan -- tidak ada cara memverifikasi siapa yang benar-benar "
    "bertransaksi di zona ini. Gunakan sebagai salah satu konteks, bukan sinyal tunggal._"
)


async def _download_and_clean(ticker: str, period: str = "3mo"):
    """Download dengan retry untuk mengatasi rate-limit Yahoo Finance
    (lihat catatan di handlers/stock_menu_handlers.py)."""
    for attempt in range(3):
        try:
            df = await async_download(ticker, period=period, interval="1d", progress=False)
            if df is not None and not df.empty:
                df = fix_yf_columns(df)
                df = df.apply(pd.to_numeric, errors="coerce")
                df = df.dropna()
                if not df.empty:
                    return df
        except Exception:
            pass
        if attempt < 2:
            await asyncio.sleep(1.5 * (attempt + 1))

    return pd.DataFrame()


def _get_ticker_arg(context):
    if not context.args:
        return None
    return context.args[0].upper() + ".JK"


# ===== FUNGSI FORMAT PESAN (PURE, dipakai bersama command handler & menu callback) =====

def format_bos_message(ticker_name: str, df, events: list[dict]) -> str:
    bos_events = [e for e in events if e["type"] == "BOS"]

    if not bos_events:
        return (
            f"📐 *BOS (BREAK OF STRUCTURE)* - {ticker_name}\n\n"
            f"Tidak ditemukan BOS yang jelas dalam {len(df)} hari terakhir. "
            f"Kemungkinan harga masih dalam fase konsolidasi/sideways tanpa trend kuat."
        ) + SMC_DISCLAIMER

    last_bos = bos_events[-1]
    arah = "🟢 BULLISH (trend naik berlanjut)" if last_bos["direction"] == "bullish" else "🔴 BEARISH (trend turun berlanjut)"
    candle_ago = len(df) - 1 - last_bos["index"]

    msg = f"""
📐 *BOS (BREAK OF STRUCTURE)* - {ticker_name}
{'='*35}

Arah: {arah}
Level ditembus: Rp{last_bos['broken_level']:,.0f}
Harga close saat BOS: Rp{last_bos['price']:,.0f}
Terjadi: {candle_ago} candle yang lalu

💡 BOS mengonfirmasi trend yang SEDANG BERJALAN masih berlanjut, bukan sinyal baru untuk masuk posisi.
"""
    return msg + SMC_DISCLAIMER


def format_choch_message(ticker_name: str, df, events: list[dict]) -> str:
    choch_events = [e for e in events if e["type"] == "CHOCH"]

    if not choch_events:
        return (
            f"🔄 *CHOCH (CHANGE OF CHARACTER)* - {ticker_name}\n\n"
            f"Tidak ditemukan CHOCH dalam {len(df)} hari terakhir. "
            f"Trend yang sedang berjalan belum menunjukkan tanda-tanda pembalikan arah."
        ) + SMC_DISCLAIMER

    last_choch = choch_events[-1]
    arah = "🟢 BULLISH (kemungkinan downtrend mulai berbalik naik)" if last_choch["direction"] == "bullish" else "🔴 BEARISH (kemungkinan uptrend mulai berbalik turun)"
    candle_ago = len(df) - 1 - last_choch["index"]

    msg = f"""
🔄 *CHOCH (CHANGE OF CHARACTER)* - {ticker_name}
{'='*35}

Arah: {arah}
Level ditembus: Rp{last_choch['broken_level']:,.0f}
Harga close saat CHOCH: Rp{last_choch['price']:,.0f}
Terjadi: {candle_ago} candle yang lalu

💡 CHOCH adalah peringatan AWAL kemungkinan reversal, BUKAN konfirmasi. Trader SMC biasanya menunggu BOS di arah baru sebelum yakin trend benar-benar berbalik.
"""
    return msg + SMC_DISCLAIMER


def format_orderblock_message(ticker_name: str, df, obs: list[dict]) -> str:
    if not obs:
        return (
            f"🟦 *ORDER BLOCK* - {ticker_name}\n\n"
            f"Tidak ditemukan order block yang jelas dalam {len(df)} hari terakhir "
            f"(perlu displacement/gerakan kuat yang menembus structure)."
        ) + SMC_DISCLAIMER

    msg = f"🟦 *ORDER BLOCK* - {ticker_name}\n{'='*35}\n\n"
    for i, ob in enumerate(obs, 1):
        emoji = "🟢" if ob["type"] == "BULLISH" else "🔴"
        fresh_label = "✅ Fresh (belum disentuh ulang)" if ob["is_fresh"] else "⚠️ Sudah disentuh ulang (kekuatan menurun)"
        candle_ago = len(df) - 1 - ob["displacement_index"]
        msg += (
            f"{i}. {emoji} {ob['type']}\n"
            f"   Zona: Rp{ob['zone_low']:,.0f} - Rp{ob['zone_high']:,.0f}\n"
            f"   {fresh_label}\n"
            f"   Displacement: {candle_ago} candle yang lalu\n\n"
        )

    msg += "💡 Order block paling valid saat PERTAMA kali disentuh ulang harga -- yang sudah pernah disentuh kekuatannya berkurang."
    return msg + SMC_DISCLAIMER


def format_fvg_message(ticker_name: str, df, gaps: list[dict]) -> str:
    if not gaps:
        return (
            f"📏 *FAIR VALUE GAP* - {ticker_name}\n\n"
            f"Tidak ada FVG yang belum terisi dalam {len(df)} hari terakhir "
            f"(semua gap sebelumnya sudah ter-rebalance oleh harga, atau memang belum ada gap signifikan)."
        ) + SMC_DISCLAIMER

    last_close = float(df["Close"].iloc[-1])
    msg = f"📏 *FAIR VALUE GAP* - {ticker_name}\n{'='*35}\n\n"
    for i, fvg in enumerate(gaps, 1):
        emoji = "🟢" if fvg["type"] == "BULLISH" else "🔴"
        distance_pct = (fvg["zone_high"] / last_close - 1) * 100 if fvg["zone_high"] < last_close else (fvg["zone_low"] / last_close - 1) * 100
        msg += (
            f"{i}. {emoji} {fvg['type']} (belum terisi)\n"
            f"   Zona: Rp{fvg['zone_low']:,.0f} - Rp{fvg['zone_high']:,.0f}\n"
            f"   Jarak dari harga sekarang: {distance_pct:+.1f}%\n\n"
        )

    msg += "💡 FVG cenderung 'menarik' harga untuk mengisi gap sebelum lanjut ke arah aslinya -- tapi sebagian gap tidak pernah terisi sama sekali."
    return msg + SMC_DISCLAIMER


def format_liquidity_message(ticker_name: str, df, pools: list[dict]) -> str:
    if not pools:
        return (
            f"💧 *LIQUIDITY POOL* - {ticker_name}\n\n"
            f"Tidak ditemukan liquidity pool yang jelas dalam {len(df)} hari terakhir."
        ) + SMC_DISCLAIMER

    msg = f"💧 *LIQUIDITY POOL* - {ticker_name}\n{'='*35}\n\n"
    for i, pool in enumerate(pools, 1):
        posisi = "DI ATAS harga (resistance/sell-side)" if pool["type"] == "HIGH" else "DI BAWAH harga (support/buy-side)"
        emoji = "🔼" if pool["type"] == "HIGH" else "🔽"
        swept_label = "⚠️ Sudah pernah disapu" if pool["swept"] else "✅ Belum pernah disapu"
        msg += (
            f"{i}. {emoji} Rp{pool['price_level']:,.0f} ({posisi})\n"
            f"   Kekuatan: {pool['n_swings']}x swing point berkumpul di level ini\n"
            f"   Jarak dari harga sekarang: {pool['distance_pct']:+.1f}%\n"
            f"   {swept_label}\n\n"
        )

    msg += "💡 Liquidity pool yang belum disapu rawan jadi target 'stop hunt' sebelum harga benar-benar berbalik arah."
    return msg + SMC_DISCLAIMER


# ===== COMMAND HANDLERS =====

async def bos_cmd(update, context):
    """/bos KODE - Break of Structure (trend continuation) paling baru."""
    ticker = _get_ticker_arg(context)
    if not ticker:
        return await update.message.reply_text("Usage: /bos BBCA")

    ticker_name = ticker.replace(".JK", "")
    df = await _download_and_clean(ticker, period="6mo")
    if len(df) < 30:
        return await update.message.reply_text(f"❌ Data {ticker_name} tidak cukup (minimal ~30 hari).")

    events = detect_bos_choch(df, left_bars=5, right_bars=5)

    chart_file = await asyncio.to_thread(generate_bos_chart, df, ticker_name, events)
    if chart_file and os.path.exists(chart_file):
        with open(chart_file, "rb") as f:
            await update.message.reply_photo(f, caption=f"📊 {ticker_name} — Break of Structure (BOS)")
        os.remove(chart_file)

    msg = format_bos_message(ticker_name, df, events)
    await update.message.reply_text(msg, parse_mode='Markdown')


async def choch_cmd(update, context):
    """/choch KODE - Change of Character (sinyal awal reversal) paling baru."""
    ticker = _get_ticker_arg(context)
    if not ticker:
        return await update.message.reply_text("Usage: /choch BBCA")

    ticker_name = ticker.replace(".JK", "")
    df = await _download_and_clean(ticker, period="6mo")
    if len(df) < 30:
        return await update.message.reply_text(f"❌ Data {ticker_name} tidak cukup (minimal ~30 hari).")

    events = detect_bos_choch(df, left_bars=5, right_bars=5)

    chart_file = await asyncio.to_thread(generate_choch_chart, df, ticker_name, events)
    if chart_file and os.path.exists(chart_file):
        with open(chart_file, "rb") as f:
            await update.message.reply_photo(f, caption=f"📊 {ticker_name} — Change of Character (CHoCH)")
        os.remove(chart_file)

    msg = format_choch_message(ticker_name, df, events)
    await update.message.reply_text(msg, parse_mode='Markdown')


async def orderblock_cmd(update, context):
    """/orderblock KODE - Zona Order Block institusional (price-action read)."""
    ticker = _get_ticker_arg(context)
    if not ticker:
        return await update.message.reply_text("Usage: /orderblock BBCA")

    ticker_name = ticker.replace(".JK", "")
    df = await _download_and_clean(ticker, period="6mo")
    if len(df) < 30:
        return await update.message.reply_text(f"❌ Data {ticker_name} tidak cukup (minimal ~30 hari).")

    obs = detect_order_blocks(df, left_bars=5, right_bars=5, max_blocks=3)

    chart_file = await asyncio.to_thread(generate_orderblock_chart, df, ticker_name, obs)
    if chart_file and os.path.exists(chart_file):
        with open(chart_file, "rb") as f:
            await update.message.reply_photo(f, caption=f"📊 {ticker_name} — Order Blocks")
        os.remove(chart_file)

    msg = format_orderblock_message(ticker_name, df, obs)
    await update.message.reply_text(msg, parse_mode='Markdown')


async def fvg_cmd(update, context):
    """/fvg KODE - Fair Value Gap (price imbalance) yang belum terisi."""
    ticker = _get_ticker_arg(context)
    if not ticker:
        return await update.message.reply_text("Usage: /fvg BBCA")

    ticker_name = ticker.replace(".JK", "")
    df = await _download_and_clean(ticker, period="3mo")
    if len(df) < 10:
        return await update.message.reply_text(f"❌ Data {ticker_name} tidak cukup (minimal ~10 hari).")

    gaps = detect_fvg(df, max_gaps=3, only_unfilled=True)

    chart_file = await asyncio.to_thread(generate_fvg_chart, df, ticker_name, gaps)
    if chart_file and os.path.exists(chart_file):
        with open(chart_file, "rb") as f:
            await update.message.reply_photo(f, caption=f"📊 {ticker_name} — Fair Value Gap (FVG)")
        os.remove(chart_file)

    msg = format_fvg_message(ticker_name, df, gaps)
    await update.message.reply_text(msg, parse_mode='Markdown')


async def liquidity_cmd(update, context):
    """/liquidity KODE - Liquidity Pool (zona stop-loss terkumpul)."""
    ticker = _get_ticker_arg(context)
    if not ticker:
        return await update.message.reply_text("Usage: /liquidity BBCA")

    ticker_name = ticker.replace(".JK", "")
    df = await _download_and_clean(ticker, period="6mo")
    if len(df) < 30:
        return await update.message.reply_text(f"❌ Data {ticker_name} tidak cukup (minimal ~30 hari).")

    pools = detect_liquidity_pools(df, left_bars=5, right_bars=5, max_pools=3)

    chart_file = await asyncio.to_thread(generate_liquidity_chart, df, ticker_name, pools)
    if chart_file and os.path.exists(chart_file):
        with open(chart_file, "rb") as f:
            await update.message.reply_photo(f, caption=f"📊 {ticker_name} — Liquidity Pools")
        os.remove(chart_file)

    msg = format_liquidity_message(ticker_name, df, pools)
    await update.message.reply_text(msg, parse_mode='Markdown')
